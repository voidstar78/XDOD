# XDOD v0.39 — shield compatibility toggle

Reset emulator r49 and run XDOD.PRG. The program remains standalone and uses
native save schema 1; your existing and converted saves remain compatible.

## Opening commands

During PREPARE, XDOD drains KERNAL keyboard input into its existing command
queue. You can type `P R T`, `U R` and `P L SW`, pressing Return after each.
The commands run in that order when gameplay begins.

## Cassette sound

Successful ZSAVE and ZLOAD play about three seconds of quiet CoCo-style cassette
sound through VERA PCM while gameplay is paused. The alternating leader is
followed by 1,200 Hz and 2,400 Hz tones generated from the staged save bytes.
Both commands start with the saved RNG, player state and timers, then wrap to
the maze. A given save produces the same tones on write and read. Failed
operations report the file error immediately.

Add `F` after the optional slot to skip the sound and its delay. For example,
`ZLOAD 5 F` loads slot 5, and `ZSAVE F` writes the default save file.

## Flask use

Use `USE LEFT` or `USE RIGHT` with a held flask. THEWS adds 1,000 power,
HALE clears damage, and ABYE adds damage equal to floor(power × 102 / 128).
As on the cartridge, unrevealed flasks still take effect. A used flask stays
in hand as an EMPTY FLASK. Using an empty flask has no effect.

The obsolete unported-command message and stereo variables are removed.
Schema 1 reserves the old stereo byte. New saves write zero and legacy saves
with a value of one still load in mono.

## Wizard scenes from v0.34

Title, level-three wizard speech and victory text now leave the first parser
row blank. Their two text lines occupy rows two and three. Victory's second
line moves left one space, aligning the A in OF A NEW with the S in DESTINY.
The level-three speech begins with one space before ENOUGH and two before
PREPARE, matching the supplied original screenshots.

Victory clears both the private queue and KERNAL keyboard buffer before its
text appears. A fresh key returns to the normal title fade and attract cycle,
rather than immediately starting a new game. The rest of a queued key burst is
cleared on that return. This fresh-key exit is an intentional extension of the
cartridge's terminal victory loop.

The level-three wizard now fades out after level four has been generated, on
the white background, as in source PATTK/NEWLVL/WIZOUT. The speech is cleared
before the fade. Key presses cannot abort the cinematic and queued input is
discarded before revival. Gameplay controls, creatures and the heartbeat are
restored only after the transition completes. This also fixes the PREPARE
heartbeat guard previously remaining set after the fake-wizard transition.

No hit probabilities, weapon statistics, sound gains, demo commands or attract
scheduler budgets were changed. A native r49 final-command comparison against
v0.33 matches player position/facing/power/damage, RNG seed and every live
creature's type, position and damage. The known small first-corner difference
from the original demo remains.

## Remaining unbanked memory

The PRG is 38,618 bytes including its two-byte load address. Its loaded image
ends at $9ED8 inclusive. $9F00 begins the reserved hardware/KERNAL region.

| Kind of headroom | Bytes | Address range |
| --- | ---: | --- |
| Additional loaded code/data with the current startup layout | 39 | $9ED9–$9EFF |
| Contiguous runtime working-data gap below the save helper | 5,042 | $6C4E–$7FFF |

These are different budgets: startup-packed bytes overlap working RAM and are
consumed before that RAM is initialized. The runtime gap can hold additional
working data. The PRG still has the separate 39-byte load limit above.
The $8000 helper, $8D00 row tables, $8F00 save workspace and $9000 save staging
also reserve memory above this gap. More loaded code would eventually require
further packing or a deliberate runtime/bank layout change.

## Shields

A fresh PRG starts with the cartridge's original shield behavior. Type `BUG`
to make Leather and Bronze reduce physical damage instead of magic and show
`SHIELD BUG OFF`. Type `BUG` again to restore classic behavior and show
`SHIELD BUG ON`. Mithril still reduces both damage types.

The toggle patches the shield comparison and store operands in RAM. Attacks
run the same instructions in both modes. Returning to the title or loading
a save leaves the current mode in effect. Schema 1 stores no shield mode.

Shields held in either hand already participate in creature attacks through
the original CRETUR:SHIELD routine's translated logic. They reduce the damage
of a landed hit, not the immediate hit/miss probability. A revealed Mithril
Shield uses 64/128 factors for magic and physical damage (roughly half damage,
with the original integer rounding). Two shields do not stack: the original
comparison selects the better defense pair. The existing regression checks
the same landed spider attack at 32 damage unshielded and 16 with Mithril.

## Validation

Native r49 checks exercise an imported save-28 victory, old-buffer flushing,
a fresh-key return to the actual title, pixel positions, and all sixteen
white-background fake-wizard fade frames with an injected key. They also verify
that level-four controls and heartbeat resume, with no queued movement applied.
The full report and clean-build hash accompany the tested release.

## Controls

| Action | Commands |
| --- | --- |
| Ready sword and torch | P L SW, P R T, U R |
| Move / turn | M, M B, M L, M R; T L, T R, T A |
| Climb at an appropriate feature | C D, C U |
| Attack | A L, A R |
| Examine / look | E, L |
| Stow / get / reveal | S L; G L SW; R L, R R |
| Use held item | U L, U R |
| Incant a held ring | I ENERGY; I ICE; I FIRE; I FINAL (full magic word) |
| Display | COLOR or COLOR 0; COLOR 1; COLOR 2; COLOR 3 |
| Shield behavior | BUG |
| Save / load | ZSAVE, ZLOAD; optional one-to-eight-digit slot |

ZSAVE 54321 overwrites XDOD-54321.SAV; ZLOAD 54321 restores it. Bare commands
use XDOD.SAV. Leading zeroes are preserved. Files use device 8's current
directory; emulator HostFS uses its working directory or -fsroot / -startin.
Schema 1, checksums and object-pointer relocation remain compatible. Physical SD-card I/O remains untested. The separate offline WAV converter has decoded all 28 supplied recordings and validated their native imports. See SAVE-FORMAT.md.

New games contain the original sword and pine torch, with no injected SEER
SCROLL. LEVEL is removed. Other developer-only GRID/RNG/MAZE dispatch and
presentation diagnostics now compile only into test fixtures to preserve space.

## Intentional differences from the cartridge

- Selectable COLOR modes and chroma phase.
- Eight-second defeat-to-title hold.
- Numeric ZSAVE/ZLOAD slots and device-8 files instead of cassette audio.
- Original 6-bit DAC sounds adapted to VERA PCM, with the selected gain curve.

## Build and evidence

Use MSYS2 make with ca65/ld65 on PATH, or build.bat. Tests run with:

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/workflow.ps1 -Action Test

The release omits developer-only code; each regression fixture uses its own
linked symbols for emulator patches. Rendered native fixtures load their test
module after startup unpack. Headless audio fixtures keep their test module in
low memory. Neither extends startup data into KERNAL's $9F00 reserved page.
The release's test-report.json and clean-build.json give checks, size and hashes.




In addition to the differences above, v0.34 permits a fresh-key return from the victory screen to the title.

