# Supplied original-hardware playthrough references

Preserved unchanged from the user's eight supplied screenshots. Browser/video
overlays, mouse pointers and capture scaling are not part of the game image.

| File | Reference use |
| --- | --- |
| msedge_G1j1Q0g9Lz.png | Inverse-background corridor and creature |
| msedge_jh8pwQBAvc.png | Inventory; exact !CREATURE! warning; backpack and status |
| msedge_qc8hDaLRFM.jpg | Inventory columns, backpack, highlighted entry |
| msedge_rp9ZhrV0DV.jpg | Nearby creature over corridor, black background |
| msedge_z7VAuITu0d.jpg | Scroll-use maze display (user clarification) |
| msedge_PXSkzZisqU.png | Same corridor moment as first capture, overlay differs |
| msedge_xxCgW4ifac.png | Long corridor, distant geometry and door |
| msedge_rUTCfZCJdy.png | Black-background corridor with diminishing visibility |

User requirements: 24 logical text rows; four parser-console rows; first level
black background; torch fading changes visibility over time. Artifact-color
patterns must be static for a fixed scene and repeat when returning to the same
view. Moving creatures must not cycle the corridor's colors. Screenshots alone
do not establish exact torch depletion timings or original framebuffer bits.
