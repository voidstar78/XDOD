; DODSOUND v0.1: isolated calibration tester, no XDOD game state.
.setcpu "65C02"
GETIN=$ffe4
CHROUT=$ffd2
AUDIO_CTRL=$9f3b
AUDIO_RATE=$9f3c
AUDIO_DATA=$9f3d
.segment "ZEROPAGE"
src_ptr: .res 2
dst_ptr: .res 2
play_ptr: .res 2
vol_ptr: .res 2
text_ptr: .res 2
.segment "BSS"
selected: .res 1
play_rate: .res 1
number_temp: .res 1
distance: .res 1
saved_bank: .res 1
write_bank: .res 1
end_bank: .res 1
end_ptr: .res 2
play_bank: .res 1
playing: .res 1
run_count: .res 2
run_sample: .res 1
sample_count: .res 2
sample_sum: .res 2
sample_xor: .res 1
feed_count: .res 1
.segment "HEADER"
.word $0801
.segment "BASIC"
.word nextline
.word 10
.byte $9e,"2061",0
nextline: .word 0
.segment "CODE"
start:
 cld
 lda $00
 sta saved_bank
 clc
 lda #1 ; KERNAL 80x30 text mode
 jsr $ff5f
 stz selected
 lda #64
 sta play_rate
 stz distance
 stz playing
 jsr audio_stop
 jsr show_menu
main_loop:
 jsr pcm_feed
 jsr GETIN
 beq main_loop
 cmp #'Q'
 beq quit
 jsr tester_key
 bra main_loop
quit:
 jsr audio_stop
 lda saved_bank
 sta $00
 rts
; Input entry is separately testable, and uses actual KERNAL cursor key codes.
tester_key:
 cmp #157
 beq @slower
 cmp #29
 beq @faster
 cmp #'R'
 beq @normal
 cmp #145
 beq @closer
 cmp #17
 beq @farther
 cmp #'X'
 bne :+
 jmp audio_stop
:
 cmp #' '
 beq @replay
 cmp #'1'
 bcs :+
 rts
: cmp #'9'+1
 bcc @digit
 and #$df
 cmp #'A'
 bcs :+
 rts
: cmp #'D'
 bcc :+
 rts
: sec
 sbc #'A'-9
 bra @select
@digit:
 sec
 sbc #'1'
@select:
 sta selected
 bra @replay
@slower:
 lda play_rate
 cmp #16
 bne :+
 rts
: dec play_rate
 bra @replay
@faster:
 lda play_rate
 cmp #128
 bne :+
 rts
: inc play_rate
 bra @replay
@normal:
 lda #64
 sta play_rate
 bra @replay
@closer:
 lda distance
 bne :+
 rts
: dec distance
 bra @replay
@farther:
 lda distance
 cmp #8
 bcc :+
 rts
: inc distance
@replay:
 jsr audio_stop
 jsr show_menu
 jsr sound_expand
 lda #2
 sta play_bank
 lda #0
 sta play_ptr
 lda #$a0
 sta play_ptr+1
 lda #1
 sta playing
@prefill:
 jsr pcm_feed
 lda playing
 cmp #2
 beq @begin
 bit AUDIO_CTRL
 bpl @prefill
@begin:
 lda play_rate ; default 64 = 24414.0625Hz, 8-bit signed mono
 sta AUDIO_RATE
 rts
@stop:
 jsr audio_stop
@done:
 rts
audio_stop:
 stz AUDIO_RATE
 lda #$8f
 sta AUDIO_CTRL
 stz playing
 rts
next_byte:
 ldy #0
 lda (src_ptr),y
 inc src_ptr
 bne :+
 inc src_ptr+1
: rts
; Expand source sample/time runs into user banks 2 onward. Never writes bank 0.
sound_expand:
 stz sample_count
 stz sample_count+1
 stz sample_sum
 stz sample_sum+1
 stz sample_xor
 lda selected
 asl
 tax
 lda sound_table,x
 sta src_ptr
 lda sound_table+1,x
 sta src_ptr+1
 stz vol_ptr
 lda #>volume_tables
 clc
 adc distance
 sta vol_ptr+1
 lda #2
 sta write_bank
 sta $00
 stz dst_ptr
 lda #$a0
 sta dst_ptr+1
@event:
 jsr next_byte
 tay
 lda (vol_ptr),y
 sta run_sample
 jsr next_byte
 sta run_count
 stz run_count+1
 lda run_count
 bne @run
 jsr next_byte
 sta run_count
 jsr next_byte
 sta run_count+1
 ora run_count
 beq @complete
@run:
 ldy #0
 lda run_sample
 sta (dst_ptr),y
 clc
 adc sample_sum
 sta sample_sum
 bcc :+
 inc sample_sum+1
: lda run_sample
 eor sample_xor
 sta sample_xor
 inc sample_count
 bne :+
 inc sample_count+1
: inc dst_ptr
 bne @count
 inc dst_ptr+1
 lda dst_ptr+1
 cmp #$c0
 bne @count
 lda #$a0
 sta dst_ptr+1
 inc write_bank
 lda write_bank
 sta $00
@count:
 lda run_count
 bne :+
 dec run_count+1
: dec run_count
 lda run_count
 ora run_count+1
 bne @run
 jmp @event
@complete:
 lda dst_ptr
 sta end_ptr
 lda dst_ptr+1
 sta end_ptr+1
 lda write_bank
 sta end_bank
 lda saved_bank
 sta $00
 rts
; Foreground feeder returns every 256 bytes so GETIN stays responsive. This
; same bounded feeder can later run between gameplay tasks, or in AFLOW service.
pcm_feed:
 lda playing
 bne :+
 rts
: cmp #2
 beq @drain
 lda play_bank
 sta $00
 stz feed_count
@byte:
 lda play_bank
 cmp end_bank
 bne @space
 lda play_ptr
 cmp end_ptr
 bne @space
 lda play_ptr+1
 cmp end_ptr+1
 bne @space
 lda #2
 sta playing
 bra @restore
@space:
 bit AUDIO_CTRL
 bmi @restore
 ldy #0
 lda (play_ptr),y
 sta AUDIO_DATA
 inc play_ptr
 bne @next
 inc play_ptr+1
 lda play_ptr+1
 cmp #$c0
 bne @next
 lda #$a0
 sta play_ptr+1
 inc play_bank
 lda play_bank
 sta $00
@next:
 inc feed_count
 bne @byte
@restore:
 lda saved_bank
 sta $00
@done:
 rts
@drain:
 lda AUDIO_CTRL
 and #64
 bne :+
 rts
: stz AUDIO_RATE
 stz playing
 rts
print:
 sta text_ptr
 sty text_ptr+1
 ldy #0
@char:
 lda (text_ptr),y
 bne :+
 rts
: phy
 jsr CHROUT
 ply
 iny
 bne @char
 inc text_ptr+1
 bra @char
@done:
 rts
show_menu:
 lda #147
 jsr CHROUT
 lda #<menu
 ldy #>menu
 jsr print
 lda selected
 cmp #9
 bcs @letter
 clc
 adc #'1'
 bra @key
@letter:
 clc
 adc #'A'-9
@key:
 jsr CHROUT
 lda #<distance_text
 ldy #>distance_text
 jsr print
 lda distance
 clc
 adc #'0'
 jsr CHROUT
 lda #<rate_text
 ldy #>rate_text
 jsr print
 lda play_rate
 jsr print_number
 lda #<footer
 ldy #>footer
 jmp print
print_number:
 sta number_temp
 ldx #'0'
 cmp #100
 bcc :+
 sec
 sbc #100
 sta number_temp
 inx
: txa
 jsr CHROUT
 ldx #'0'
 lda number_temp
@ten:
 cmp #10
 bcc @digits
 sec
 sbc #10
 inx
 bra @ten
@digits:
 sta number_temp
 txa
 jsr CHROUT
 lda number_temp
 clc
 adc #'0'
 jmp CHROUT
.segment "RODATA"
menu: .byte "DODSOUND V0.1 - ORIGINAL DAC CALIBRATION",13,13,"1 SPIDER       2 VIPER        3 STONE GIANT 1",13,"4 BLOB         5 KNIGHT 1     6 STONE GIANT 2",13,"7 SCORPION     8 KNIGHT 2     9 WRAITH",13,"A BALROG       B PLAIN WIZARD C CRESCENT WIZARD",13,13,"UP: CLOSER/LOUDER   DOWN: FARTHER/QUIETER",13,"LEFT/RIGHT: SPEED   R: RESET SPEED",13,"SPACE: REPLAY   X: STOP   Q: RETURN TO BASIC",13,13,"SELECTED KEY: ",0
rate_text: .byte "   PCM RATE: ",0
distance_text: .byte "   DISTANCE (0-8): ",0
footer: .byte 13,13,"SOURCE ARITHMETIC / APPROXIMATE 6809 TIMING",13,"PLEASE COMPARE PITCH, DURATION, AND ENVELOPE.",13,"WIZARDS SHARE THEIR ORIGINAL SOUND ROUTINE.",13,0
.include "assets.inc"
