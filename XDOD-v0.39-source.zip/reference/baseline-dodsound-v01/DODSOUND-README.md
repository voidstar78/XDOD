# DODSOUND v0.1 — standalone creature-sound calibration

Reset r49 and load DODSOUND.PRG as a normal BASIC-loadable PRG, then RUN.
This is a separate tester; it does not replace or modify XDOD.PRG.
No external sound files are needed when running the PRG.

## Controls

| Key | Creature / action |
| --- | --- |
| 1 | Spider — SQUEAK |
| 2 | Viper — RATTLE |
| 3 | Stone giant 1 — GROWL |
| 4 | Blob — BEOOP |
| 5 | Knight 1 — KLANK |
| 6 | Stone giant 2 — GRAWL |
| 7 | Scorpion — PSSST |
| 8 | Knight 2 — KKLANK |
| 9 | Wraith — PSSHT |
| A | Balrog — SNARL |
| B | Plain wizard — BDLBDL |
| C | Crescent wizard — BDLBDL |
| Up / Down | Closer/louder / farther/quieter, distance 0..8 |
| Left / Right | Slower/lower / faster/higher playback; displayed PCM RATE |
| R | Restore default PCM RATE 064 |
| Space | Replay selected sound |
| X | Stop |
| Q | Return to BASIC |

A creature key plays immediately. Distance/speed changes restart the selected
sound, making comparisons repeatable. Both wizard slots deliberately share the
same source routine. The spider is a very brief rising chirp; use Space to repeat.

Start comparisons at distance 0 and rate 064. Useful feedback is, for example:
'1: too high/too short; rate 056 sounds closer', or '7: right rhythm but too harsh'.
Playback-rate changes affect both pitch and duration. They do not independently
adjust envelope shape, so report any remaining mismatch separately.

## Conversion and limits

The original cartridge does not hold digitized creature samples. SOUNDS.ASM
procedurally generates them. tools/sound/SoundTrace.cs transcribes the tone
sweeps, two-tone counters, noise recurrence and attack/decay envelopes, using
parameters from SOUNDS.ASM and SWCHAR.ASM. The noise starts from a fixed zero
seed for repeatable calibration. The wizard sequence includes its source noise
sweeps and THUDD-based double explosion.

The host generator records source-sample/time runs. The tester expands them to
8-bit signed mono PCM in user RAM banks 2 onward, then feeds VERA's FIFO in bounded
chunks, polling GETIN between chunks. System bank 0 and the game's framebuffer
bank 1 are untouched. The largest current decoded clip is about 41 KB.

Volume follows CRETUR:CWALK's SNVOL=255-31*distance for distances 0..8. Each event
uses the original multiply-high and AND $FC DAC quantization before PCM conversion.
The result is DC-centered for signed PCM. Six-bit amplitude steps are retained;
VERA's logarithmic volume register is held fixed rather than being used as a
substitute for the source scaling.

Default VERA AUDIO_RATE is 64 (24414.0625 input samples/sec); output is 8-bit mono.
See the official reference for FIFO/sample-format details:
https://github.com/X16Community/x16-docs/blob/master/X16%20Reference%20-%2009%20-%20VERA%20Programmer%27s%20Reference.md

Timing in v0.1 is an estimated 6809 control-path/cycle model using a nominal
894886.25-Hz NTSC CoCo clock. It is NOT a cycle-exact cartridge execution capture.
CoCo analog/RF audio filtering and speaker coloration are not yet modeled.
This is the baseline for listening feedback, not a claim of final audio fidelity.
The generated WAV files use the nearest integer WAV-header rate, 24414 Hz.

## Build and validation

From the XDOD project root:

powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/sound/build.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools/sound/test.ps1

Build uses the bundled host64 ca65/ld65 tools. Source assets and a manifest/WAVs
are regenerated from the C# model. The sound tester has its own linker config,
including the required page alignment for volume tables.

Eight automated checks pass: all 108 creature/distance vectors; byte-for-byte
banked PCM comparisons for spider, viper, wizard and distant giant; real rendered
r49 FIFO playback through to empty; bank-0/bank-1 preservation; and arrow bounds,
speed reset, wizard selection and stop controls. A recorded emulator WAV is
non-silent. These validate the conversion/player plumbing, not perceptual fidelity.

## Next integration work

The tester's feeder returns after at most 256 PCM bytes. Game integration can
use that same bounded playback contract, with refill work scheduled between game
tasks or through an audio-low-water service. Mixing, overlapping sounds and
procedural generation/storage strategy still need integration decisions after
calibration. The full test sound archive is not embedded into XDOD yet.

The XDOD requests remain queued separately: inventory/status flicker, white-level
faint/wake polarity, crowded-scene turn timing, the intro's two deliberate lines
and 'DYNA MICRO MCMLXXXII  X16 MMXXVI' status banner, then source-based combat.
The later five-second ZSAVE tape-sound homage also remains planned; saving is
not implemented by this tester.
