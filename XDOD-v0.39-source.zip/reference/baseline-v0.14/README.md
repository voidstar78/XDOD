# XDOD v0.14 — bounded diagnostics

Based on v0.13. The MAZE diagnostic now uses `M Z:` instead of `MAZE Z:` to fit inside the 40-column bitmap text area. `draw_char` also rejects characters at column 40 or beyond, preventing right-edge corruption when future output is too long. No changes to maze generation, RNG, or corridor graphics.

This is **not** the promised full four-row scrolling command console; the current bitmap geometry still needs restructuring for that. The existing bottom prompt remains on its own row.

Build: `make clean && make`. No assembler available here; compilation not verified.
