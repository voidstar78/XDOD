@echo off
if not exist build mkdir build
ca65 -g -l build\main.lst -o build\main.o src\main.s
if errorlevel 1 exit /b 1
ld65 -C cfg\x16.cfg -m build\XDOD.map -Ln build\XDOD.lbl -o XDOD.PRG build\main.o
if errorlevel 1 exit /b 1
echo Built XDOD.PRG
