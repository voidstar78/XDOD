; XDOD v0.12 - VERA bitmap graphics / command-shell proof of concept.
; NOT YET the original Daggorath renderer, heartbeat model, or parser.
.setcpu "65C02"
GETIN=$FFE4
IRQVEC=$0314
VERA_ADDR_L=$9F20
VERA_ADDR_M=$9F21
VERA_ADDR_H=$9F22
VERA_DATA0=$9F23
VERA_CTRL=$9F25
VERA_DC_VIDEO=$9F29
VERA_DC_HSCALE=$9F2A
VERA_DC_VSCALE=$9F2B
VERA_L0_CONFIG=$9F2D
VERA_L0_TILEBASE=$9F2F
.segment "ZEROPAGE"
input_len: .res 1
frame_count: .res 1
pending_ticks: .res 1
heart_state: .res 1
save_a: .res 1
rle_ptr: .res 2
rle_count: .res 1
rle_value: .res 1
font_ptr: .res 2
row_ptr: .res 2
char_x: .res 1 ; character column, 0..39 (not pixel X)
char_y: .res 1
char_code: .res 1
char_row: .res 1
str_ptr: .res 2
rng_seed: .res 3
rng_work: .res 1
rng_count: .res 1
rng_shift: .res 1
rng_carry: .res 1
maze_row: .res 1
maze_col: .res 1
maze_dir: .res 1
maze_dist: .res 1
maze_nextrow: .res 1
maze_nextcol: .res 1
maze_index: .res 2
maze_cells: .res 2
maze_ptr: .res 2
maze_counter: .res 2
maze_row_temp: .res 1
maze_col_temp: .res 1
maze_neighbor_value: .res 1
maze_sum_lo: .res 1
maze_sum_hi: .res 1
maze_pages: .res 1
maze_open_lo: .res 1
maze_open_hi: .res 1
maze_ff_lo: .res 1
maze_ff_hi: .res 1
maze_other_lo: .res 1
maze_other_hi: .res 1
hex_byte: .res 1
hex_digit: .res 1
.segment "BSS"
input_buf: .res 33
old_irq: .res 2
maze_map: .res 1024
.segment "HEADER"
.word $0801
.segment "BASIC"
.word nextline
.word 10
.byte $9e,"2061",0
nextline: .word 0
.segment "CODE"
start:
 sei
 stz input_len
 stz frame_count
 stz pending_ticks
 stz heart_state
 jsr rng_init_test
 jsr setup_vera
 jsr draw_background
 lda #5
 sta char_x
 lda #179
 sta char_y
 lda #<status_text
 ldy #>status_text
 jsr print_text
 jsr draw_prompt
 lda IRQVEC
 sta old_irq
 lda IRQVEC+1
 sta old_irq+1
 lda #<irq_handler
 sta IRQVEC
 lda #>irq_handler
 sta IRQVEC+1
 cli
main_loop:
 jsr GETIN
 beq check_ticks
 cmp #13
 beq enter_key
 cmp #20
 beq delete_key
 cmp #32
 bcc check_ticks
 ldx input_len
 cpx #27
 bcs check_ticks
 sta input_buf,x
 inc input_len
 jsr draw_prompt
 bra check_ticks
enter_key:
 jsr handle_command
 stz input_len
 jsr draw_prompt
 bra check_ticks
delete_key:
 lda input_len
 beq check_ticks
 dec input_len
 jsr draw_prompt
check_ticks:
 lda pending_ticks
 beq main_loop
 sei
 dec pending_ticks
 cli
 jsr heartbeat_tick
 bra main_loop
irq_handler:
 pha
 inc frame_count
 lda frame_count
 cmp #30
 bcc :+
 stz frame_count
 lda pending_ticks
 cmp #$ff
 beq :+
 inc pending_ticks
: pla
 jmp (old_irq)
heartbeat_tick:
 lda heart_state
 eor #1
 sta heart_state
 lda #20
 sta char_x
 lda #179
 sta char_y
 lda heart_state
 beq :+
 lda #'<'
 bra :++
: lda #'*'
: jsr draw_char
 rts
handle_command:
 ldx input_len
 stz input_buf,x
 ldx #0
@uppercase:
 cpx input_len
 bcs @test
 lda input_buf,x
 cmp #'a'
 bcc @next
 cmp #'z'+1
 bcs @next
 and #$df
 sta input_buf,x
@next:
 inx
 bra @uppercase
@test:
 lda input_len
 bne :+
 jmp @done
:
 lda input_buf
 cmp #'I'
 bne @test_grid
 lda input_buf+1
 bne @test_grid
 jsr show_inventory_test
 jmp @done
@test_grid:
 lda input_buf
 cmp #'G'
 bne @test_rng
 lda input_buf+1
 cmp #'R'
 bne @test_rng
 lda input_buf+2
 cmp #'I'
 bne @test_rng
 lda input_buf+3
 cmp #'D'
 bne @test_rng
 lda input_buf+4
 bne @test_rng
 jsr show_grid_test
 jmp @done
@test_rng:
 lda input_buf
 cmp #'R'
 bne @test_maze
 lda input_buf+1
 cmp #'N'
 bne @test_maze
 lda input_buf+2
 cmp #'G'
 bne @test_maze
 lda input_buf+3
 bne @test_maze
 jsr rng_selftest
 bcc @rng_fail
 lda #<rng_ok_text
 ldy #>rng_ok_text
 bra @message
@rng_fail:
 lda #<rng_fail_text
 ldy #>rng_fail_text
 bra @message
@test_maze:
 lda input_buf
 cmp #'M'
 bne @test_turn
 lda input_buf+1
 cmp #'A'
 bne @test_turn
 lda input_buf+2
 cmp #'Z'
 bne @test_turn
 lda input_buf+3
 cmp #'E'
 bne @test_turn
 lda input_buf+4
 bne @test_turn
 jsr maze_phase1
 jsr maze_checksum
 jsr maze_count_open
 jsr show_maze_checksum
 jmp @done
@test_turn:
 lda input_buf
 cmp #'T'
 bne @unknown
 lda input_buf+1
 cmp #' '
 bne @unknown
 lda input_buf+2
 cmp #'L'
 bne @unknown
 lda input_buf+3
 bne @unknown
 lda #<turn_text
 ldy #>turn_text
 bra @message
@unknown:
 lda #<unknown_text
 ldy #>unknown_text
@message:
 sta str_ptr
 sty str_ptr+1
 jsr clear_response
 lda #5
 sta char_x
 lda #200
 sta char_y
 lda str_ptr
 ldy str_ptr+1
 jsr print_text
@done:
 rts
; Diagnostic modes use original 32x24 logical text grid (256x192).
; No dungeon logic is implied by these display-only tests.
show_grid_test:
 jsr clear_game_view
 ldx #0
@line:
 phx
 txa
 asl
 asl
 asl
 clc
 adc #24             ; centered game top in 320x240 bitmap
 sta char_y
 lda #4              ; x=32 physical pixels
 sta char_x
 lda #<grid_line
 ldy #>grid_line
 jsr print_text
 plx
 inx
 cpx #24
 bcc @line
 rts
show_inventory_test:
 jsr clear_game_view
 lda #4
 sta char_x
 lda #24
 sta char_y
 lda #<inv_title
 ldy #>inv_title
 jsr print_text
 lda #4
 sta char_x
 lda #40
 sta char_y
 lda #<inv_line1
 ldy #>inv_line1
 jsr print_text
 lda #4
 sta char_x
 lda #48
 sta char_y
 lda #<inv_line2
 ldy #>inv_line2
 jsr print_text
 lda #4
 sta char_x
 lda #56
 sta char_y
 lda #<inv_line3
 ldy #>inv_line3
 jsr print_text
 lda #4
 sta char_x
 lda #72
 sta char_y
 lda #<inv_note
 ldy #>inv_note
 jsr print_text
 rts
; Clear 320x240 4bpp bitmap to palette index 0.
clear_game_view:
 stz VERA_ADDR_L
 stz VERA_ADDR_M
 lda #$10
 sta VERA_ADDR_H
 ldx #150
@page:
 ldy #0
@byte:
 stz VERA_DATA0
 iny
 bne @byte
 dex
 bne @page
 rts
clear_response:
 lda #5
 sta char_x
 lda #200
 sta char_y
 ldx #27
@loop:
 phx
 lda #' '
 jsr draw_char
 plx
 dex
 bne @loop
 rts
draw_prompt:
 lda #5
 sta char_x
 lda #208
 sta char_y
 lda #'.'
 jsr draw_char
 ldx #0
@loop:
 phx
 txa
 cmp input_len
 bcs @space
 lda input_buf,x
 bra @draw
@space:
 lda #' '
@draw:
 jsr draw_char
 plx
 inx
 cpx #27
 bcc @loop
 rts
; Print null-terminated string, A/Y pointer, advances char_x by 8
print_text:
 sta str_ptr
 sty str_ptr+1
 ldy #0
@loop:
 lda (str_ptr),y
 beq @done
 phy
 jsr draw_char
 ply
 iny
 bra @loop
@done: rts
; draw_char: A ASCII, char_x character column, char_y scanline.
; Writes 8x8 font, foreground palette index 1, background 0.
; Character X is bounded to 0..39; bitmap offset is column*4.
draw_char:
 cmp #32
 bcs :+
 lda #' '
: cmp #96
 bcc :+
 lda #'?'
: sec
 sbc #32
 sta char_code
 lda #<font_data
 sta font_ptr
 lda #>font_data
 sta font_ptr+1
 ; font_ptr = font_data + char_code * 32
 lda char_code
 asl
 asl
 asl
 asl
 asl
 clc
 adc font_ptr
 sta font_ptr
 php             ; preserve carry from low-byte addition
 lda char_code
 lsr
 lsr
 lsr
 plp
 adc font_ptr+1
 sta font_ptr+1
 ; Separate low/high lookup tables avoid 8-bit index wrap at row 128.
 ldy char_y
 lda row_table_lo,y
 sta row_ptr
 lda row_table_hi,y
 sta row_ptr+1
 lda char_x
 asl
 asl
 clc
 adc row_ptr
 sta row_ptr
 bcc :+
 inc row_ptr+1
: stz char_row
@row:
 lda row_ptr
 sta VERA_ADDR_L
 lda row_ptr+1
 sta VERA_ADDR_M
 lda #$10
 sta VERA_ADDR_H
 ldy #0
@byte:
 lda (font_ptr),y
 sta VERA_DATA0
 iny
 cpy #4
 bcc @byte
 clc
 lda font_ptr
 adc #4
 sta font_ptr
 bcc :+
 inc font_ptr+1
: clc
 lda row_ptr
 adc #160
 sta row_ptr
 lda row_ptr+1
 adc #0
 sta row_ptr+1
 inc char_row
 lda char_row
 cmp #8
 bcc @row
 clc
 lda char_x
 adc #1
 sta char_x
 rts
setup_vera:
 stz VERA_CTRL
 ; disable layers during initialization; leave VGA enabled
 lda #$01
 sta VERA_DC_VIDEO
 ; Scale 320x240 source bitmap to 640x480 output (64/128 per axis)
 lda #64
 sta VERA_DC_HSCALE
 sta VERA_DC_VSCALE
 ; 4bpp bitmap, 320 pixels wide, layer 0
 lda #$06
 sta VERA_L0_CONFIG
 stz VERA_L0_TILEBASE
 ; palette defaults: index 0 black, 1 white on standard VERA palette
 rts
draw_background:
 stz VERA_ADDR_L
 stz VERA_ADDR_M
 lda #$10
 sta VERA_ADDR_H
 lda #<screen_rle
 sta rle_ptr
 lda #>screen_rle
 sta rle_ptr+1
@pair:
 ldy #0
 lda (rle_ptr),y
 sta rle_count
 inc rle_ptr
 bne :+
 inc rle_ptr+1
: lda (rle_ptr),y
 sta rle_value
 inc rle_ptr
 bne :+
 inc rle_ptr+1
: ldx rle_count
@run:
 lda rle_value
 sta VERA_DATA0
 dex
 bne @run
 lda rle_ptr+1
 cmp #>screen_rle_end
 bcc @pair
 bne @done
 lda rle_ptr
 cmp #<screen_rle_end
 bcc @pair
@done:
 lda #$11 ; VGA + layer 0 enabled
 sta VERA_DC_VIDEO
 rts
 ; 6809 RANDOM.ASM RANDOX: polynomial feedback parity of SEED+2 & $E1.
; Eight 24-bit left shifts per output. Byte order exactly matches SEED,SEED+1,SEED+2.
; Input/output rng_seed (3 bytes); A returns original SEED first byte.
rng_init_test:
 lda #$12
 sta rng_seed
 lda #$34
 sta rng_seed+1
 lda #$56
 sta rng_seed+2
 rts
rng_next:
 lda #8
 sta rng_count
@outer:
 lda rng_seed+2
 and #$E1
 sta rng_work
 stz rng_carry
 lda #8
 sta rng_shift
@parity:
 asl rng_work
 bcc @no_bit
 lda rng_carry
 eor #1
 sta rng_carry
@no_bit:
 dec rng_shift
 bne @parity
 lda rng_carry
 lsr
 rol rng_seed
 rol rng_seed+1
 rol rng_seed+2
 dec rng_count
 bne @outer
 lda rng_seed
 rts
; Deterministic test vectors independently calculated from the 6809 algorithm.
; Carry set on pass, clear on failure. Resets seed to $12,$34,$56.
rng_selftest:
 jsr rng_init_test
 ldx #0
@loop:
 phx
 jsr rng_next
 plx
 cmp rng_expected,x
 bne @fail
 inx
 cpx #16
 bne @loop
 sec
 rts
@fail:
 clc
 rts
; DGNGEN.ASM Phase I translated: 500 accepted cells, random walks,
; rejection of 2x2 cleared squares. No walls or doors yet.
; The 6809 RNDCEL consumes column RNG first, then row RNG.
maze_phase1:
 lda #<maze_map
 sta maze_ptr
 lda #>maze_map
 sta maze_ptr+1
 ldx #4
@clear_page:
 ldy #0
 lda #$ff
@clear_byte:
 sta (maze_ptr),y
 iny
 bne @clear_byte
 inc maze_ptr+1
 dex
 bne @clear_page
 ; level 1 seed from LVLTAB: bytes at LEVEL=1
 lda #$c7
 sta rng_seed
 lda #$5d
 sta rng_seed+1
 lda #$97
 sta rng_seed+2
 lda #<500
 sta maze_cells
 lda #>500
 sta maze_cells+1
 jsr maze_random_cell
 sta maze_row
 stx maze_col
@new_direction:
 jsr rng_next
 and #3
 sta maze_dir
 jsr rng_next
 and #7
 inc a
 sta maze_dist
@step:
 lda maze_row
 sta maze_nextrow
 lda maze_col
 sta maze_nextcol
 lda maze_dir
 beq @north
 cmp #1
 beq @east
 cmp #2
 beq @south
 dec maze_nextcol
 bra @check
@north:
 dec maze_nextrow
 bra @check
@east:
 inc maze_nextcol
 bra @check
@south:
 inc maze_nextrow
@check:
 lda maze_nextrow
 cmp #32
 bcs @new_direction
 lda maze_nextcol
 cmp #32
 bcs @new_direction
 jsr maze_addr
 ldy #0
 lda (maze_ptr),y
 beq @advance
 ; Original FRIEND check rejects any new cell completing a 2x2 cleared block.
 ; Check four 2x2 squares around candidate, with out-of-bounds treated as walls.
 jsr maze_corner_check
 bcc @new_direction
 ldy #0
 lda #0
 sta (maze_ptr),y
 lda maze_cells
 bne :+
 dec maze_cells+1
: dec maze_cells
 lda maze_cells
 ora maze_cells+1
 beq @done
@advance:
 lda maze_nextrow
 sta maze_row
 lda maze_nextcol
 sta maze_col
 dec maze_dist
 beq @new_direction
 jmp @step
@done:
 rts
; random col then row; A=row X=col
maze_random_cell:
 jsr rng_next
 and #31
 tax
 phx
 jsr rng_next
 and #31
 plx
 rts
; ptr = maze_map + row*32 + col; valid coords 0..31
maze_addr:
 lda #<maze_map
 sta maze_ptr
 lda #>maze_map
 sta maze_ptr+1
 lda maze_nextrow
 asl
 asl
 asl
 asl
 asl
 sta maze_index
 lda maze_nextrow
 lsr
 lsr
 lsr
 sta maze_index+1
 clc
 lda maze_index
 adc maze_nextcol
 sta maze_index
 bcc :+
 inc maze_index+1
: clc
 lda #<maze_map
 adc maze_index
 sta maze_ptr
 lda #>maze_map
 adc maze_index+1
 sta maze_ptr+1
 rts
; Carry set when no 2x2 group around candidate is entirely clear.
maze_corner_check:
 ; each corner tests three neighbors, matching DGNGEN's sum==0 rejection
 lda #$ff
 sta maze_counter ; placeholder unused
 ldx #0
@corner:
 ; offsets (-1,-1),(-1,0),(0,-1) etc via table
 lda maze_nextrow
 clc
 adc corner_dr1,x
 sta maze_row_temp
 lda maze_nextcol
 clc
 adc corner_dc1,x
 sta maze_col_temp
 jsr maze_check_neighbor
 bne @next_corner
 lda maze_nextrow
 clc
 adc corner_dr2,x
 sta maze_row_temp
 lda maze_nextcol
 clc
 adc corner_dc2,x
 sta maze_col_temp
 jsr maze_check_neighbor
 bne @next_corner
 lda maze_nextrow
 clc
 adc corner_dr3,x
 sta maze_row_temp
 lda maze_nextcol
 clc
 adc corner_dc3,x
 sta maze_col_temp
 jsr maze_check_neighbor
 bne @next_corner
 clc
 rts
@next_corner:
 inx
 cpx #4
 bcc @corner
 sec
 rts
maze_check_neighbor:
 lda maze_row_temp
 cmp #32
 bcs @wall
 lda maze_col_temp
 cmp #32
 bcs @wall
 ; preserve candidate position while accessing neighbor
 lda maze_nextrow
 pha
 lda maze_nextcol
 pha
 lda maze_row_temp
 sta maze_nextrow
 lda maze_col_temp
 sta maze_nextcol
 phx
 jsr maze_addr
 ldy #0
 lda (maze_ptr),y
 sta maze_neighbor_value
 plx
 pla
 sta maze_nextcol
 pla
 sta maze_nextrow
 jsr maze_addr
 lda maze_neighbor_value
 rts
@wall:
 lda #$ff
 rts
.segment "RODATA"
maze_msg: .byte "MAZE 500 SUM:",0
maze_short_msg: .byte "MAZE Z:",0
maze_sum_msg: .byte " S:",0
maze_open_msg: .byte "Z:",0
maze_ff_msg: .byte " F:",0
maze_other_msg: .byte " X:",0
; Diagnostic additive checksum over all 1024 bytes of maze_map.
; This is NOT a CoCo reference checksum or proof of bit-exact generation.
maze_checksum:
 stz maze_sum_lo
 stz maze_sum_hi
 lda #<maze_map
 sta maze_ptr
 lda #>maze_map
 sta maze_ptr+1
 lda #4
 sta maze_pages
@page:
 ldy #0
@byte:
 clc
 lda maze_sum_lo
 adc (maze_ptr),y
 sta maze_sum_lo
 lda maze_sum_hi
 adc #0
 sta maze_sum_hi
 iny
 bne @byte
 inc maze_ptr+1
 dec maze_pages
 bne @page
 rts
; Independently count bytes that are exactly $00 after Phase I.
; The original Phase I should leave 500 zero cells and 524 $FF cells.
maze_count_open:
 stz maze_open_lo
 stz maze_open_hi
 stz maze_ff_lo
 stz maze_ff_hi
 stz maze_other_lo
 stz maze_other_hi
 lda #<maze_map
 sta maze_ptr
 lda #>maze_map
 sta maze_ptr+1
 lda #4
 sta maze_pages
@page:
 ldy #0
@byte:
 lda (maze_ptr),y
 beq @zero
 cmp #$ff
 beq @full
 inc maze_other_lo
 bne @next
 inc maze_other_hi
 bra @next
@zero:
 inc maze_open_lo
 bne @next
 inc maze_open_hi
 bra @next
@full:
 inc maze_ff_lo
 bne @next
 inc maze_ff_hi
@next:
 iny
 bne @byte
 inc maze_ptr+1
 dec maze_pages
 bne @page
 rts
show_maze_checksum:
 jsr clear_response
 lda #5
 sta char_x
 lda #200
 sta char_y
 lda #<maze_short_msg
 ldy #>maze_short_msg
 jsr print_text
 lda maze_open_hi
 jsr print_hex_byte
 lda maze_open_lo
 jsr print_hex_byte
 lda #<maze_ff_msg
 ldy #>maze_ff_msg
 jsr print_text
 lda maze_ff_hi
 jsr print_hex_byte
 lda maze_ff_lo
 jsr print_hex_byte
 lda #<maze_other_msg
 ldy #>maze_other_msg
 jsr print_text
 lda maze_other_hi
 jsr print_hex_byte
 lda maze_other_lo
 jsr print_hex_byte
 lda #<maze_sum_msg
 ldy #>maze_sum_msg
 jsr print_text
 lda maze_sum_hi
 jsr print_hex_byte
 lda maze_sum_lo
 jsr print_hex_byte
 rts

print_hex_byte:
 sta hex_byte
 lsr
 lsr
 lsr
 lsr
 jsr print_hex_digit
 lda hex_byte
 and #$0f
print_hex_digit:
 and #$0f
 cmp #10
 bcc @number
 clc
 adc #('A'-10)
 bra @emit
@number:
 clc
 adc #'0'
@emit:
 jsr draw_char
 rts
corner_dr1: .byte $ff,$ff,0,1
corner_dc1: .byte $ff,0,1,$ff
corner_dr2: .byte $ff,$ff,1,1
corner_dc2: .byte 0,1,1,0
corner_dr3: .byte 0,0,1,0
corner_dc3: .byte $ff,1,0,$ff
grid_line: .byte "0123456789ABCDEFGHIJKLMNOPQRSTUV",0
inv_title: .byte "INVENTORY (DISPLAY TEST)",0
inv_line1: .byte "PINE TORCH",0
inv_line2: .byte "WOODEN SWORD",0
inv_line3: .byte "VISION SCROLL",0
inv_note: .byte "NOT YET GAME INVENTORY",0
status_text: .byte "LEFT SWORD       RIGHT",0
turn_text: .byte "TURN LEFT: STUB",0
unknown_text: .byte "NOT IMPLEMENTED",0
rng_ok_text: .byte "RNG 16/16 PASS",0
rng_fail_text: .byte "RNG TEST FAILED",0
rng_expected: .byte $B8,$85,$21,$69,$0B,$52,$9A,$99,$F0,$89,$35,$97,$25,$43,$77,$5B

.include "screen.inc"
.include "font.inc"
row_table_lo:
.repeat 240,I
 .byte <(I*160)
.endrepeat
row_table_hi:
.repeat 240,I
 .byte >(I*160)
.endrepeat
