# XDOD — Dungeons of Daggorath on Commander X16

**Project handoff — November 8, 2026**  
**Latest supplied source:** `XDOD-v0.14-source.zip`  
**Status:** Early 65C02/VERA prototype with maze-generation phase-I diagnostics; **not yet a playable port**.

## 1. Project objective and decisions

- **Authentic port, not a lookalike replica.** Preserve the original game's mechanics, command vocabulary, dungeon layout, inventory, scroll behavior, creature behavior, and presentation wherever feasible. Temporary test commands and visual scaffolding are acceptable but should not become substitute game logic.
- **Target:** Commander X16, using 65C02 assembly (cc65 `ca65`/`ld65`) and VERA graphics. Develop in the X16 emulator, ultimately verify on physical hardware.
- **Original CoCo presentation:** aim for a logical **256×192** game area and **8×8 font / 32×24 text grid** where appropriate. The current prototype uses a 320×240 4-bpp VERA bitmap scaled to the emulator output, with the 256×192 mock game area centered. The screenshot's status strip and lower text window are not yet faithful.
- **Command UI:** original game has a **four-row scrolling command window**, a `.` prompt/prefix, and left/right equipment labels aligned to the edges. Keep command output and prompt from overwriting each other. Current implementation does not achieve full scrolling.
- **Dungeon rendering:** eventually draw actual wall geometry, side passages, doors, and creatures from maze/world data. A good solar torch can show approximately six or seven sectors down a long corridor; the player's current sector is also visible. Existing nested-rectangle corridor is static scaffolding.
- **Inventory:** implement an authentic inventory screen and creature warning (exact original wording still to be verified). A starting **VISION SCROLL** is acceptable for testing; alternatively provide an unrevealed scroll and implement `REVEAL` before use. The scroll/map is a test aid to compare dungeon layout.
- **Maze authenticity:** prioritize original maze arrangement. Prefer porting original algorithm and fixed seeds when practical; **storing original maze layouts as data is acceptable** if exact RNG/algorithm reproduction proves disproportionately difficult. Do not substitute a merely similar random maze without noting the deviation.
- **CoCo composite artifact colors:** investigate red/blue fringes on real X16 composite output later. The emulator may not emulate analog composite effects. A temporary `TEST` command for hardware color experiments is acceptable. Gameplay and maze mechanics take priority.

## 2. Current implementation (checked against v0.14 source)

**Project files:** `src/main.s`, generated `src/font.inc` and `src/screen.inc`, `cfg/x16.cfg`, `Makefile`, `build.bat`, `tools/assets.py`.

- `start` sets up VERA, draws static background/corridor, status text, and `.` prompt; installs a chained IRQ handler.
- `main_loop` polls X16 KERNAL `GETIN`, handles Enter and Delete, and accepts a bounded command buffer (up to 27 characters).
- IRQ-driven periodic symbol toggles between `*` and `<`; **this is a visual heartbeat placeholder, not the original game heartbeat mechanics**.
- Commands in `handle_command`: `I` (placeholder inventory display), `GRID` (24-row font/grid test), `RNG` (deterministic RNG self-test), `MAZE` (generate and inspect maze), and `T L` (placeholder turn response). Other commands produce an unknown-command response. **Movement, turning, scroll use, reveal, combat, and genuine inventory are not yet implemented.**
- `rng_next` implements a 3-byte state RNG translation with `rng_selftest` checking 16 expected outputs; test seed `$12,$34,$56`.
- `maze_phase1` initializes a **1024-byte (32×32) maze array** to `$FF`, uses a fixed level-1 seed `$C7,$5D,$97`, performs random walks to clear **500 accepted cells**, and checks against clearing complete 2×2 squares. The source explicitly says **no walls or doors yet**; the full original generation and level structure remain incomplete.
- `MAZE` invokes generation, checksum, and open-cell counts. The observed diagnostic values were `Z:01F4` (500 zero bytes), `F:020C` (524 `$FF` bytes), `X:0000` (no other values), `S:09F4`. This validates those counts, **not full maze equivalence to the original**.
- `show_inventory_test` is a static text test, not an inventory engine.
- `clear_response` writes one response line at pixel y=200; `draw_prompt` writes a separate prompt line at y=208. These are **not a four-row scrolling console**.
- `draw_char` writes an 8×8 bitmap font and was modified in v0.14 to reject columns ≥40, but the actual screenshot still shows the MAZE diagnostic extending through the right border. The display bug is **unresolved**.

## 3. Test results and known defects

- Builds were compiled by the user under MSYS2/UCRT64 with `make clean` then `make`, using `ca65` and `ld65`. One intermediate build had 6502 relative branch range errors, subsequently addressed.
- An earlier `Makefile` clock-skew warning was reported; this is a file timestamp/build dependency concern, not a verified runtime issue.
- The v0.13 change separated diagnostic and prompt rows enough to eliminate the worst overwrite, but the diagnostic still crosses the right border and the prompt sits against the bottom border.
- **v0.14 did not visibly fix right-edge clipping**, as confirmed by the user's screenshot. Do not claim this is solved or issue another purely cosmetic revision without a measurable test.
- Repeated `MAZE` calls yielded consistent results, expected with the current fixed seed. They do not demonstrate player movement or a complete navigable dungeon.
- Current corridor is visually static, with no actual maze-driven viewpoint.
- No local assembler/emulator execution was reported for v0.14 by the assistant; user's screenshots are the main runtime verification.

## 4. Recommended next engineering milestones

1. **Establish reproducible local validation:** install/configure `ca65`, `ld65`, and preferably the X16 emulator in the coding environment; compile every change before packaging. Preserve one canonical source tree and version it (Git recommended).
2. **Fix display geometry properly:** define explicit game/status/console rectangles and character coordinates, test with overlong strings, implement four-row console history with scrolling, and keep a separate input prompt. Verify no border corruption on emulator screenshots.
3. **Prove original maze equivalence:** compare phase-I generated cells and later walls/doors against original source/reference data, not merely count totals; decide whether to store canonical mazes if needed.
4. **Render from world state:** add player position and orientation, ray/sector traversal, variable-depth corridor frames, side openings and doors; test using known map coordinates.
5. **Implement authentic game interactions:** move/turn, inventory, starting scroll and reveal/use mechanics, torch range, creatures and combat, timing/heartbeat.
6. **Refine presentation:** original text placement/font, inventory and scroll map, and optional composite-artifact experiment on physical X16.

## 5. Reference material

- Original gameplay screenshots were collected separately in `Daggorath_original_video_screenshots.zip` (8 video references: corridors, creatures, map, inventory, long-distance view). These should guide visual comparisons, **not replace source-level game behavior**.
- Source history available as `XDOD-v0.1-source.zip` through `XDOD-v0.14-source.zip` (including v0.9.1). **Use v0.14 as latest baseline, but compare earlier versions when investigating regressions.**

## 6. Build and test

```bash
make clean
make
```

Load `XDOD.PRG` in the X16 emulator or on hardware according to the project's README. Useful current diagnostics: `RNG`, `MAZE`, `GRID`, `I`; `T L` is still a stub. **Do not interpret a successful build as proof of correct VERA output.**

## 7. Development workflow decision

The previous rapid screenshot→ZIP→compile cycle yielded many small releases with insufficient verification. For the next phase, favor GPT-6 High/Extra High or a coding environment with direct project, toolchain, and emulator access. Deliver tested, milestone-sized changes with explicit pass/fail criteria and a short changelog. Keep the aim firmly on an **authentic Daggorath engine port**, not prolonged refinement of placeholder graphics.
