[CmdletBinding()]
param(
    [ValidateSet('Build','Test','Run')][string]$Action='Test',
    [string]$Ca65=$env:CA65,
    [string]$Ld65=$env:LD65,
    [string]$Emulator=$env:X16EMU,
    [int]$TimeoutSeconds=30
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
function Resolve-Tool($value,$name) {
    if($value) { if(Test-Path -LiteralPath $value) { return (Resolve-Path -LiteralPath $value).Path }; $cmd=Get-Command $value -ErrorAction SilentlyContinue; if($cmd){return $cmd.Source}; throw "Tool not found: $value" }
    foreach($candidate in @((Join-Path $PSScriptRoot "host64\$name.exe"),(Join-Path (Split-Path $root -Parent) "$name.exe"))) { if(Test-Path -LiteralPath $candidate){return $candidate} }
    $cmd=Get-Command $name -ErrorAction SilentlyContinue; if($cmd){return $cmd.Source}
    throw "Set the path to $name using its script parameter or environment variable."
}
$Ca65=Resolve-Tool $Ca65 'ca65'; $Ld65=Resolve-Tool $Ld65 'ld65'
if(!$Emulator) { $candidate='E:\X16\x16emu_win64-r49\x16emu.exe'; if(Test-Path -LiteralPath $candidate){$Emulator=$candidate} }
function Assemble($source,$stem) {
    & $Ca65 -g -I (Join-Path $root 'src') -l "$stem.lst" -o "$stem.o" $source
    if($LASTEXITCODE -ne 0){throw "Assembler failed: $source"}
    & $Ld65 -C (Join-Path $root 'cfg\x16.cfg') -m "$stem.map" -Ln "$stem.lbl" -o "$stem.prg" "$stem.o"
    if($LASTEXITCODE -ne 0){throw "Linker failed: $source"}
}
New-Item -ItemType Directory -Force -Path (Join-Path $root 'build') | Out-Null
if($Action -eq 'Test'){
    $previous=Join-Path $root 'build\tests\report.json'
    if(Test-Path -LiteralPath $previous){Remove-Item -LiteralPath $previous}
}
Assemble (Join-Path $root 'src\main.s') (Join-Path $root 'build\XDOD')
Copy-Item -LiteralPath (Join-Path $root 'build\XDOD.prg') -Destination (Join-Path $root 'XDOD.PRG')
Write-Host "Built XDOD.PRG ($((Get-Item (Join-Path $root 'XDOD.PRG')).Length) bytes)"
if($Action -eq 'Build'){return}
if(!$Emulator -or !(Test-Path -LiteralPath $Emulator)){throw 'Supply -Emulator or set X16EMU to x16emu.exe (r49 tested).'}
$rom=Join-Path (Split-Path $Emulator -Parent) 'rom.bin'
if(!(Test-Path -LiteralPath $rom)){throw "Missing matching ROM: $rom"}
if($Action -eq 'Run') {
    # A visible window is intentional for this interactive action.
    Start-Process -FilePath $Emulator -WorkingDirectory $root -ArgumentList @('-rom',('"'+$rom+'"'),'-prg',('"'+(Join-Path $root 'XDOD.PRG')+'"'),'-run','-quality','nearest')
    return
}
if(-not ('DaggorathReference' -as [type])){Add-Type -Path (Join-Path $root 'tests\Reference.cs')}
$results=Join-Path $root 'build\tests'
New-Item -ItemType Directory -Force -Path $results | Out-Null
$reportPath=Join-Path $results 'report.json'
if(Test-Path -LiteralPath $reportPath){Remove-Item -LiteralPath $reportPath}
$labels=@{}
Get-Content -LiteralPath (Join-Path $root 'build\XDOD.lbl') | ForEach-Object {
    if($_ -match '^al ([0-9A-Fa-f]+) \.(\w+)$'){$labels[$matches[2]]=[Convert]::ToInt32($matches[1],16)}
}
if(!$labels.ContainsKey('maze_level')){throw 'Missing maze_level: all five levels must be testable.'}
function Invoke-Machine($name,[string]$body,[switch]$Video,[switch]$Boot,[switch]$Rendered) {
    $dir=Join-Path $results $name; New-Item -ItemType Directory -Force -Path $dir | Out-Null
    # Assemble the production source unchanged, with only a separate test entry.
    $source=Join-Path $dir 'harness.s'
    [IO.File]::WriteAllText($source,".include `"main.s`"`n.segment `"CODE`"`ntest_entry:`n sei`n cld`n$body`n jmp `$ffff`n")
    $stem=Join-Path $dir 'harness'; Assemble $source $stem
    $entry=0
    Get-Content -LiteralPath "$stem.lbl" | ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.test_entry$'){$entry=[Convert]::ToInt32($matches[1],16)}}
    if(!$entry){throw 'Missing harness entry'}
    $prg=[IO.File]::ReadAllBytes("$stem.prg"); $load=[int]$prg[0]+256*[int]$prg[1]
    $bssEnd=0
    Get-Content -LiteralPath "$stem.lbl" | ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.__RAM_LAST__$'){$bssEnd=[Convert]::ToInt32($matches[1],16)}}
    if($load+$prg.Length-2 -gt 0x6000 -or $bssEnd -gt 0x6000){throw 'Test results at $6000 would overlap the growing program/BSS. Relocate the test buffers first.'}
    $commands=[Text.StringBuilder]::new()
    for($i=2;$i -lt $prg.Length;$i++){[void]$commands.AppendLine(('STM {0:X4} {1:X2}' -f ($load+$i-2),$prg[$i]))}
    if($Boot) {
        # Only the test's in-memory copy is patched: execute production startup,
        # then divert the first main-loop iteration to the IRQ observation loop.
        $resume=0
        Get-Content -LiteralPath "$stem.lbl" | ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.boot_resume$'){$resume=[Convert]::ToInt32($matches[1],16)}}
        if(!$resume){throw 'Missing boot resume label'}
        [void]$commands.AppendLine(('STM {0:X4} 4C' -f $labels.main_loop))
        [void]$commands.AppendLine(('STM {0:X4} {1:X2}' -f ($labels.main_loop+1),($resume -band 255)))
        [void]$commands.AppendLine(('STM {0:X4} {1:X2}' -f ($labels.main_loop+2),($resume -shr 8)))
        if($Rendered){
            $offset=$labels.main_loop-$load+2
            $prg[$offset]=0x4c; $prg[$offset+1]=$resume -band 255; $prg[$offset+2]=$resume -shr 8
            [IO.File]::WriteAllBytes("$stem.prg",$prg)
        }
    }
    [void]$commands.AppendLine(('RUN {0:X4}' -f $entry))
    # Drain both output streams while writing thousands of STM commands.
    $psi=[Diagnostics.ProcessStartInfo]::new()
    $dumpMode='R'; if($Video){$dumpMode='RV'}
    $psi.FileName=$Emulator; $psi.Arguments='-testbench -warp -sound none -dump '+$dumpMode+' -rom "'+$rom+'"'
    if($Rendered){
        if(!$Boot){throw 'Rendered smoke test requires -Boot'}
        # SDL's dummy display still runs r49 video timing; -testbench skips it.
        # No visible window or global SDL environment changes are required.
        $psi.Arguments='-warp -sound none -dump '+$dumpMode+' -rom "'+$rom+'" -prg "'+$stem+'.prg" -run'
        $psi.EnvironmentVariables['SDL_VIDEODRIVER']='dummy'
        $psi.EnvironmentVariables['SDL_AUDIODRIVER']='dummy'
    }
    $psi.WorkingDirectory=$dir; $psi.UseShellExecute=$false; $psi.CreateNoWindow=$true
    $psi.RedirectStandardInput=$true; $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true
    $process=[Diagnostics.Process]::new(); $process.StartInfo=$psi
    $dump=Join-Path $dir 'dump.bin'; if(Test-Path -LiteralPath $dump){Remove-Item -LiteralPath $dump}
    try {
        [void]$process.Start(); $stdout=$process.StandardOutput.ReadToEndAsync(); $stderr=$process.StandardError.ReadToEndAsync()
        if(!$Rendered){
            $writing=$process.StandardInput.WriteAsync($commands.ToString())
            if(!$writing.Wait($TimeoutSeconds*1000)){throw "${name}: input timed out"}
        }
        $process.StandardInput.Close()
        if(!$process.WaitForExit($TimeoutSeconds*1000)){throw "${name}: execution timed out"}
        $out=$stdout.Result; $err=$stderr.Result
        [IO.File]::WriteAllText((Join-Path $dir 'emulator.log'),$out+"`n"+$err)
        if($process.ExitCode -ne 0 -or $out -match 'ERR '){throw "$name emulator failed; see $dir\emulator.log"}
        if(!(Test-Path -LiteralPath $dump)){throw "$name produced no dump"}
        $ram=[IO.File]::ReadAllBytes($dump)
        $expectedLength=40960; if($Video){$expectedLength+=131072+256+512+14+1024}
        if($ram.Length -ne $expectedLength){throw "Unexpected r49 dump length $($ram.Length), expected $expectedLength"}
        return ,$ram
    } finally {if($process.Id -and !$process.HasExited){$process.Kill()}; $process.Dispose()}
}
$checks=[Collections.Generic.List[object]]::new()
function Check($name,$ok,$detail) {
    $checks.Add([pscustomobject]@{name=$name;pass=[bool]$ok;detail=$detail})
    Write-Host ((@{True='PASS';False='FAIL'}[[string][bool]$ok])+" $name : $detail")
}
function Equal-Bytes([byte[]]$a,[byte[]]$b){if($a.Length -ne $b.Length){return $false};for($n=0;$n -lt $a.Length;$n++){if($a[$n] -ne $b[$n]){return $false}};return $true}
$seedTable=[byte[]]@(0x73,0xc7,0x5d,0x97,0xf3,0x13,0x87)
$seeds=@([byte[]]@(0x12,0x34,0x56),[byte[]]@(0,0,0),[byte[]]@(255,255,255))
for($level=0;$level -lt 5;$level++){$seeds+=,([byte[]]$seedTable[$level..($level+2)])}
$body=[Text.StringBuilder]::new(); $expected=[Collections.Generic.List[byte]]::new(); $address=0x6000
foreach($seed in $seeds) {
    for($i=0;$i -lt 3;$i++){[void]$body.AppendLine((' lda #${0:X2}' -f $seed[$i]));[void]$body.AppendLine(" sta rng_seed+$i")}
    [void]$body.AppendLine(' ldx #0'); [void]$body.AppendLine(': jsr rng_next')
    for($i=0;$i -lt 3;$i++){[void]$body.AppendLine(" lda rng_seed+$i");[void]$body.AppendLine((' sta ${0:X4},x' -f ($address+256*$i)))}
    [void]$body.AppendLine(' inx');[void]$body.AppendLine(' bne :-')
    $model=[DaggorathReference]::new($seed); $states=New-Object byte[] 768
    for($i=0;$i -lt 256;$i++){[void]$model.Next();for($j=0;$j -lt 3;$j++){$states[$j*256+$i]=$model.Seed[$j]}}
    $expected.AddRange($states); $address+=768
}
$ram=Invoke-Machine 'rng' $body.ToString()
Check 'RNG states' (Equal-Bytes $ram[0x6000..($address-1)] $expected.ToArray()) '256 calls x 8 seeds; all three state bytes compared'
$body=[Text.StringBuilder]::new(); $maps=@(); $finals=@()
for($level=0;$level -lt 5;$level++) {
    [void]$body.AppendLine(" lda #$level`n sta maze_level")
    [void]$body.AppendLine(' jsr maze_phase1')
    for($p=0;$p -lt 4;$p++){[void]$body.AppendLine(" ldx #0`n: lda maze_map+$($p*256),x");[void]$body.AppendLine((' sta ${0:X4},x' -f (0x8000+1024*$level+256*$p)));[void]$body.AppendLine(" inx`n bne :-")}
    for($i=0;$i -lt 3;$i++){[void]$body.AppendLine(" lda rng_seed+$i");[void]$body.AppendLine((' sta ${0:X4}' -f (0x9800+3*$level+$i)))}
    $model=[DaggorathReference]::new([byte[]]$seedTable[$level..($level+2)]); $maps+=,($model.Phase1());$finals+=,([byte[]]$model.Seed.Clone())
}
$ram=Invoke-Machine 'maze' $body.ToString(); $modelIndex=0
for($level=0;$level -lt 5;$level++) {
    $actual=[byte[]]$ram[(0x8000+1024*$level)..(0x83ff+1024*$level)]
    [IO.File]::WriteAllBytes((Join-Path $results "phase1-level$($level+1).bin"),$actual)
    $diff=0; for($i=0;$i -lt 1024;$i++){if($actual[$i] -ne $maps[$modelIndex][$i]){$diff++}}
    Check "Phase I level $($level+1)" ($diff -eq 0) "$diff mismatched cells of 1024"
    Check "RNG after level $($level+1)" (Equal-Bytes $ram[(0x9800+3*$level)..(0x9802+3*$level)] $finals[$modelIndex]) 'exact final state (detects extra/missing random calls)'
    $modelIndex++
}
$ram=Invoke-Machine 'clipping' @'
 jsr inventory_init
 jsr setup_vera
 jsr clear_game_view
 lda #39
 sta char_x
 lda #232
 sta char_y
 lda #'A'
 jsr draw_char
 lda #40
 sta char_x
 lda #'B'
 jsr draw_char
 lda #255
 sta char_x
 lda #'C'
 jsr draw_char
 lda #0
 sta char_x
 lda #233
 sta char_y
 lda #'D'
 jsr draw_char
 lda #255
 sta char_y
 lda #'E'
 jsr draw_char
'@ -Video
$expectedVram=New-Object byte[] 38400
$fontOffset=$labels.font_data+(65-32)*32
$production=[IO.File]::ReadAllBytes((Join-Path $root 'XDOD.PRG'))
for($y=0;$y -lt 8;$y++){for($x=0;$x -lt 4;$x++){$expectedVram[(232+$y)*160+156+$x]=$production[2+$fontOffset-0x801+$y*4+$x]}}
Check 'Bitmap clipping' (Equal-Bytes $ram[40960..79359] $expectedVram) 'last valid glyph at (39,232); x=40/255 and y=233/255 leave all other pixels untouched'
$setup=@'
 jsr inventory_init
 jsr setup_vera
 jsr draw_background
 stz input_len
 stz maze_level
 jsr inventory_status
 jsr draw_prompt
'@
$command=@'
 lda #'M'
 sta input_buf
 lda #'A'
 sta input_buf+1
 lda #'Z'
 sta input_buf+2
 lda #'E'
 sta input_buf+3
 lda #4
 sta input_len
 jsr handle_command
 stz input_len
 jsr draw_prompt
'@
$ram=Invoke-Machine 'display' ($setup+"`n"+$command) -Video
$vram=[byte[]]$ram[40960..79359]
$borderOK=$true
foreach($y in 187..215){$borderByte=$vram[$y*160+143];if(($borderByte -band 15) -ne 1){$borderOK=$false}}
for($x=32;$x -le 287;$x++){if(($vram[215*160+[int][Math]::Floor($x/2)] -band $(if($x%2){15}else{240})) -eq 0){$borderOK=$false}}
Check 'MAZE command border' $borderOK 'response and prompt preserve the right and bottom game-frame borders'
$promptOK=$true
for($y=0;$y -lt 8;$y++){for($x=0;$x -lt 4;$x++){$font=$production[2+$labels.font_data-0x801+(46-32)*32+$y*4+$x];if($vram[(207+$y)*160+20+$x] -ne $font){$promptOK=$false}}}
Check 'Separate prompt' $promptOK 'MAZE response leaves the dot glyph intact at column 5, scanline 207'
$boot=Invoke-Machine 'boot' @'
 jmp start
boot_resume:
 sei
'@ -Boot
$irq=[int]$boot[0x314]+256*[int]$boot[0x315]
Check 'Startup and IRQ vector' ($irq -eq $labels.irq_handler -and $boot[$labels.pending_ticks] -eq 0) 'production startup reaches main loop and installs the IRQ vector (headless r49 does not advance video timing)'
$timed=Invoke-Machine 'timing' @'
 jmp start
boot_resume:
 cli
 lda pending_ticks
 cmp #2
 bcc boot_resume
 sei
'@ -Boot -Rendered
Check 'Rendered startup and IRQ' ($timed[$labels.pending_ticks] -eq 2) 'BASIC RUN boots the PRG; normal video timing and chained IRQ produce two 30-frame ticks using SDL dummy display'
function Export-MachineImage([byte[]]$dump,[string]$file) {
$vram=[byte[]]$dump[40960..79359]
Add-Type -AssemblyName System.Drawing
$image=[Drawing.Bitmap]::new(640,480)
try {
    $paletteOffset=40960+131072+256
    $colors=@();for($i=0;$i -lt 16;$i++){$gb=$dump[$paletteOffset+2*$i];$r=$dump[$paletteOffset+2*$i+1];$colors+= [Drawing.Color]::FromArgb(($r -band 15)*17,($gb -shr 4)*17,($gb -band 15)*17)}
    for($y=0;$y -lt 240;$y++){for($x=0;$x -lt 320;$x++){$packed=$vram[$y*160+[int][Math]::Floor($x/2)];$index=if($x%2){$packed -band 15}else{$packed -shr 4};$color=$colors[$index];$image.SetPixel(2*$x,2*$y,$color);$image.SetPixel(2*$x+1,2*$y,$color);$image.SetPixel(2*$x,2*$y+1,$color);$image.SetPixel(2*$x+1,2*$y+1,$color)}}
    $image.Save($file,[Drawing.Imaging.ImageFormat]::Png)
} finally {$image.Dispose()}
}
Export-MachineImage $ram (Join-Path $results 'display.png')
. (Join-Path $root 'tests\Inventory.ps1')
$prg=[IO.File]::ReadAllBytes((Join-Path $root 'XDOD.PRG'))
Check 'Standalone BASIC loader' ($prg[0] -eq 1 -and $prg[1] -eq 8 -and $labels.start -eq 2061) 'load $0801; SYS 2061 points to start'
$provenance=@()
foreach($path in @($Ca65,$Ld65,$Emulator,$rom,(Join-Path $root 'tests\Reference.cs'),(Join-Path $root 'reference\original\RANDOM.ASM'),(Join-Path $root 'reference\original\DGNGEN.ASM'))){$provenance+=[pscustomobject]@{file=$path;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}}
foreach($relative in @('src\inventory.inc','src\original_tables.inc','src\font.inc','tests\InventoryReference.cs','reference\original\PGET.ASM','reference\original\PEXAM.ASM','reference\original\PLOOK.ASM','reference\original\PARSER.ASM','reference\original\STATUS.ASM','reference\original\TOKEN.ASM','reference\original\DTABAS.ASM','reference\original\SWCHAR.ASM')) {
    $path=Join-Path $root $relative
    $provenance+=[pscustomobject]@{file=$path;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
}
$report=[ordered]@{time=(Get-Date -Format o);emulator=$Emulator;assembler=$Ca65;prg_sha256=(Get-FileHash -LiteralPath (Join-Path $root 'XDOD.PRG') -Algorithm SHA256).Hash;provenance=$provenance;checks=$checks.ToArray();limitations=@('Algorithm oracle is a source transcription, not a CoCo execution capture.','Phase II walls, doors, and full gameplay are not implemented.','Hardware composite color and audible audio fidelity require separate validation.')}
$report | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $reportPath -Encoding UTF8
if(@($checks | Where-Object {!$_.pass}).Count){throw 'Regression checks failed. See build/tests/report.json'}
Write-Host "All $($checks.Count) checks passed. Report: build/tests/report.json"
