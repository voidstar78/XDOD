// Independent semantic model of PGET.ASM, PLOOK.ASM, PEXAM.ASM and PARSER.ASM.
using System;
using System.Collections.Generic;
public sealed class InventoryReference {
    static readonly string[] Commands={"ATTACK","CLIMB","DROP","EXAMINE","GET","INCANT","LOOK","MOVE","PULL","REVEAL","STOW","TURN","USE","ZLOAD","ZSAVE"};
    static readonly string[] Directions={"LEFT","RIGHT","BACK","AROUND","UP","DOWN"};
    static readonly string[] Generics={"FLASK","RING","SCROLL","SHIELD","SWORD","TORCH"};
    readonly int[] hands={-1,-1}, links={1,-1}, owned={1,1};
    readonly int[] rows={0,0}, cols={0,0}, levels={0,0};
    int bag=0, weight=35, view=0, result=0, torch=-1;
    static int Parse(string word,string[] table) {
        int found=-1;
        if(word.Length==0) return -1;
        for(int i=0;i<table.Length;i++) if(table[i].StartsWith(word,StringComparison.Ordinal)) {if(found!=-1) return -1;found=i;}
        return found;
    }
    public void Apply(string line) {
        var t=line.ToUpperInvariant().Split(new char[]{' '},StringSplitOptions.RemoveEmptyEntries);
        if(t.Length==0) return;
        result=0;int command=Parse(t[0],Commands);
        if(command<0){result=1;return;}
        if(command==3){view=1;return;}
        if(command==6){view=0;return;}
        if(command!=2&&command!=4&&command!=8&&command!=10){result=2;return;}
        int hand=t.Length>1?Parse(t[1],Directions):-1;
        if(hand<0||hand>1){result=1;return;}
        if(command==10||command==2){
            int item=hands[hand];if(item<0){result=1;return;}
            hands[hand]=-1;
            if(command==10){links[item]=bag;bag=item;}
            else{owned[item]=0;rows[item]=16;cols[item]=11;levels[item]=0;weight-=item==0?25:10;}
            return;
        }
        if(hands[hand]>=0){result=1;return;}
        if(t.Length<3){result=1;return;}
        int cls=Parse(t[2],Generics),specific=-1;
        if(cls<0){
            // All 25 adjectives preserve ambiguity even though only two items exist.
            string[] adjectives={"SUPREME","JOULE","ELVISH","MITHRIL","SEER","THEWS","RIME","VISION","ABYE","HALE","SOLAR","BRONZE","VULCAN","IRON","LUNAR","PINE","LEATHER","WOODEN","FINAL","ENERGY","ICE","FIRE","GOLD","EMPTY","DEAD"};
            int adjective=Parse(t[2],adjectives);
            int[] classes={1,1,4,3,2,0,1,2,0,0,5,3,1,4,5,5,3,4,1,1,1,1,1,0,5};
            if(adjective<0||t.Length<4||Parse(t[3],Generics)!=classes[adjective]){result=1;return;}
            cls=classes[adjective]; specific=adjective;
        }
        Func<int,bool> match=i=>specific<0?(i==0?4:5)==cls:(i==0?17:15)==specific;
        if(command==8){
            int previous=-1,item=bag;
            while(item>=0&&!match(item)){previous=item;item=links[item];}
            if(item<0){result=1;return;}
            if(previous<0)bag=links[item];else links[previous]=links[item];
            hands[hand]=item;if(torch==item)torch=-1;
        }else{
            int item=-1;
            for(int i=0;i<2;i++)if(owned[i]==0&&rows[i]==16&&cols[i]==11&&levels[i]==0&&match(i)){item=i;break;}
            if(item<0){result=1;return;}
            hands[hand]=item;owned[item]=1;weight+=item==0?25:10;
        }
    }
    public byte[] Snapshot() {
        return new byte[]{(byte)(hands[0]+1),(byte)(hands[1]+1),(byte)(bag+1),(byte)(links[0]+1),(byte)(links[1]+1),
            (byte)owned[0],(byte)owned[1],(byte)rows[0],(byte)cols[0],(byte)levels[0],(byte)rows[1],(byte)cols[1],(byte)levels[1],
            (byte)weight,(byte)(weight>>8),(byte)view,(byte)result,(byte)(torch+1)};
    }
}
