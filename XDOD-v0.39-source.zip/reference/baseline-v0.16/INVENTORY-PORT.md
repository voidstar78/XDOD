# v0.16 inventory port boundaries

The earlier `I` screen was a static test and had no exit or usable objects.
It has been removed. This increment translates the original inventory slice
rather than adding a new inventory interaction scheme.

## Source mapping

| Original routine/data | 65C02 implementation |
| --- | --- |
| PEXAM.ASM: PEXAM | command_examine selects display_mode=EXAMIN |
| PLOOK.ASM: PLOOK | command_look selects VIEWER and restores the top view |
| PARSER.ASM: GETTOK/PARSER/PARSE0 | next_token/match_token, ASCII adapter, unique prefix matching |
| PARSER.ASM: PARHND/PAROBJ | command_hand/parse_object |
| PGET.ASM: PPULL | command_pull follows/unlinks the backpack list and clears active_torch if selected |
| PGET.ASM: PSTOW | command_stow inserts the held OCB at the list head |
| PGET.ASM: PDROP/PGET | command_drop/command_get; ownership, room/level and carried weight |
| PGET.ASM: COMUPD | inventory_redraw updates current main view and held-object status |
| PEXAM.ASM: EXAMIN/PRTOBJ | render_examine/inventory_print_object; floor first, two columns, separator, backpack |
| COMCRE.ASM: CFIND | inventory_cfind scans 32 original-layout CCB records for live same-room creatures |
| STATUS.ASM: OBJNAM/STATUX | object_name/inventory_status; revelation-aware names, EMPTY, right justification |
| ONCE.ASM: GAME10/GAME30 and COMDAT.ASM: GAMDAT | inventory_init: position (16,11), wooden sword then pine torch, revealed/owned, both hands empty |
| CD.ASM: OCB/CCB definitions | same 14/17-byte field offsets and pool capacities; pointers adapted to little-endian 65C02 |
| TOKEN.ASM | original_tables.inc, decoded from actual five-bit packed data |
| DTABAS.ASM | original object class/reveal/offense/special values and weight table |
| SWCHAR.ASM and COMTXT.ASM: NDPB10 | original packed 5x7 alphabet and punctuation expanded and shifted into 8x8 4-bpp cells |

Regenerate tables with `tools/original-tables.ps1`, and original letter glyphs
with `tools/original-font.ps1`. Generated includes are checked in and sufficient
to build. Digits and diagnostic-only punctuation retain fallback glyphs; they
are outside the original alphabet. `TOKEN.ASM`'s actual packed words take
precedence over inconsistent comments/macros elsewhere (e.g. RIME vs HOTH).

Generic object selection uses class; adjective+generic selection uses type and
requires matching class. All original command/direction/generic/adjective words
participate in ambiguity checking, including commands not yet implemented.
Unused trailing command text is discarded as in HUMAN's post-command reset.
Supported commands do not invent success messages or extra exit keys.

## Validation

The full suite passes 59 checks on r49. The inventory checks execute the actual
65C02 command handler and compare semantic snapshots to InventoryReference.cs,
an independent transcription of the original operations. They cover head/tail
unlinking, stow insertion order, both hands occupied/empty, ambiguous prefixes,
adjective/class mismatch, case/spacing adaptation, invalid hand, floor drop/get,
weight changes and view persistence. Image checks compare actual VRAM glyphs,
conditional !CREATURE! output, active-torch inversion and status alignment.
EXAMINE then LOOK restores every byte of the current top-view bitmap.

`build/tests/inventory.png`, `inventory-equipped.png`, `inventory-creature.png`
and `look-after-inventory.png` are reconstructions of actual emulated VRAM.
The independent model is not an original-cartridge execution trace.

## Remaining original-game work

This is a source-based partial port, not a claim that the full engine is present.
The corridor is still static scaffolding. World generation/population, movement,
REVEAL/USE, live creature behavior, torch burning, and original fatigue/heartrate
timing remain unported. GET/DROP preserve original weight changes, but do not yet
invoke the original HUPDAT calculation. Starting items are faithful; other room
objects can currently enter the player-facing model by dropping those items.

The four-row scrolling console and exact status-strip geometry/inverse treatment
still need the original text subsystem port. Inventory protects the console area
and the top display is bounded, but large-list scrolling is not complete. The
heartbeat symbol remains a placeholder, not the original heart glyph/physiology.
Artifact colors and DAC sound are unchanged by this increment.
