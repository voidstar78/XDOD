// Independent host model, transcribed from reference/original/{RANDOM,DGNGEN}.ASM.
// This is an algorithm oracle, not a captured CoCo memory dump.
using System;
public sealed class DaggorathReference {
    public byte[] Seed;
    public int Calls;
    public DaggorathReference(byte[] seed) { Seed=(byte[])seed.Clone(); }
    public byte Next() {
        for(int i=0;i<8;i++) {
            int bits=Seed[2]&0xe1, ones=0;
            for(int j=0;j<8;j++) ones+=(bits>>j)&1;
            int carry=ones&1;
            for(int j=0;j<3;j++) {
                int value=Seed[j]*2+carry;
                Seed[j]=(byte)value; carry=value>>8;
            }
        }
        Calls++; return Seed[0];
    }
    public byte[] Phase1() {
        var map=new byte[1024]; for(int i=0;i<1024;i++) map[i]=255;
        int col=Next()&31, row=Next()&31, remaining=500, attempts=0;
        int[] dr={-1,0,1,0}, dc={0,1,0,-1};
        while(remaining>0) {
            if(++attempts>1000000) throw new Exception("Reference maze exceeded limit");
            int dir=Next()&3, distance=(Next()&7)+1;
            for(int step=0;step<distance;step++) {
                int r=row+dr[dir], c=col+dc[dir];
                if(r<0||r>=32||c<0||c>=32) break;
                if(map[r*32+c]!=0) {
                    // FRIEND plus four 8-bit sums of the three neighboring cells.
                    bool reject=false;
                    for(int dy=-1;dy<=0;dy++) for(int dx=-1;dx<=0;dx++) {
                        int sum=0;
                        for(int y=r+dy;y<=r+dy+1;y++) for(int x=c+dx;x<=c+dx+1;x++) {
                            if(y==r&&x==c) continue;
                            sum += (y<0||y>=32||x<0||x>=32) ? 255 : map[y*32+x];
                        }
                        if((sum&255)==0) reject=true;
                    }
                    if(reject) break;
                    map[r*32+c]=0; remaining--;
                    if(remaining==0) return map;
                }
                row=r; col=c;
            }
        }
        return map;
    }
    public byte[] Full() {
        byte[] map=Phase1();
        int[] dr={-1,0,1,0},dc={0,1,0,-1};
        for(int r=0;r<32;r++)for(int c=0;c<32;c++){
            if(map[r*32+c]==255)continue;
            for(int d=0;d<4;d++){
                int y=r+dr[d],x=c+dc[d];
                if(y<0||y>=32||x<0||x>=32||map[y*32+x]==255) map[r*32+c]|=(byte)(3<<(d*2));
            }
        }
        for(int type=1;type<=2;type++)for(int n=0;n<(type==1?70:45);n++){
            for(;;){
                int c=Next()&31,r=Next()&31;
                if(map[r*32+c]==255)continue;
                int d=Next()&3;
                if((map[r*32+c]&(3<<(2*d)))!=0)continue;
                map[r*32+c]|=(byte)(type<<(2*d));
                map[(r+dr[d])*32+c+dc[d]]|=(byte)(type<<(2*(d^2)));
                break;
            }
        }
        return map;
    }
}
