# XDOD v0.17 — torch use, original heart, four-row console, complete maze data

This milestone follows v0.16's inventory slice. It does not claim a completed
original-game renderer, navigation, creatures, fatigue model or audio.

## Try the torch workflow

After loading the new XDOD.PRG:

```text
E
P R T
U R
E
L
```

The game starts with no active torch, so LOOK is dark. USE RIGHT lights the held
pine torch and puts it back into the backpack, leaving the right hand empty.
EXAMINE then reverses that torch's name. Pulling it out clears active_torch;
using it again reactivates/stows it. This follows PUSE/PSTOW0/PPULL in the original
source, rather than assuming any held torch is automatically lit.

The command is STOW. S, ST, STO and STOW are unique prefixes. STORE is not a
prefix of STOW and returns the original CMDERR text, ???. Commands not yet
implemented continue to be labeled as such.

## Original display regions and heart

The original 256x192 game image is centered at (32,24) in the current 320x240
VERA surface. Rows 0..18 are the 152-pixel main view, row 19 is the inverse
status strip, and rows 20..23 are all four console rows.

The console now has a 128-character backing buffer, original 32-column wrapping,
one-row scrolling, command echo, deletion, period prompts and underscore cursor.
It occupies scanlines 184..215 without the prototype's inset border wasting a
text row. The keyboard buffer accepts 32 characters and dispatches when full,
matching HUMAN's buffer-full path. Direct test calls to handle_command need not
echo input; interactive input goes through the console path in main_loop.

SPCTAB's original small/large left/right heart halves are converted from their
raw seven-row bytes. They occupy original status columns 15 and 16. Pixel tests
compare both complete frames directly with the source bytes. The glyphs and
placement are ported; the physiological heartrate calculation remains pending.
The current animation still uses the prototype's fixed 30-frame interval.

## Torch depletion

torch.inc implements COMPLR:BURNER's counter and state changes. At a logical
one-minute service interval it decrements the active torch, clamps regular and
magic light to remaining time, marks it DEAD at timer 5 and reveals that name.
An exhausted timer does not underflow. Original PUPSUB-style light components
are read from the active OCB. The timing adapter currently groups 120 existing
half-second ticks; full original scheduler/phase behavior is not yet ported.

The unlit preview is now dark, and torch activation reveals the existing static
corridor scaffold. The original distance-dependent vector fade and geometry
are not yet implemented: do not interpret this preview as proof of torch-range
or maze-view fidelity. The renderer must use the light values with original
SETFAD/range logic next. Audio remains unported.

## Complete deterministic maze generation

maze_complete.inc translates DGNGEN's second phase: neighboring walls, 70 regular
doors and 45 secret doors, with reciprocal edge features and original RNG call
order. All five 1024-byte maps and final RNG states agree with Reference.cs's
independent 6809 source transcription. This is stronger than the earlier Phase I
cell comparison. Complete arrays are saved as build/tests/complete-level1.bin
through complete-level5.bin. MAZE now regenerates a complete map, not a Phase I
array that would destroy its wall/door information.

The original DGEN90 SECOND-dependent RNG spin follows map construction. It is
deliberately outside this deterministic map generator; it still needs integration
with the later world/scheduler port. These comparisons are not original-cartridge
execution captures or an assertion that all published map pictures were decoded.

Startup generates the complete first-level array. LOOK still uses the clearly
documented static corridor asset; it does not yet traverse that array. The next
renderer/navigation work should consume this validated map and the original
VARC/VIEWER geometry, not substitute a different maze generator or approximate
game rules. No debug-map screen has been presented as scroll gameplay.

## Validation

The suite passes 76 checks, including retained inventory/RNG/Phase I checks,
five complete maps and RNG states, four-row scroll-buffer and raster checks,
USE activation/stow/highlight, the pine burn sequence and exact heart frames.
Source, PRG and emulator provenance are recorded in build/tests/report.json.
Emulated-VRAM images include four-row-console.png and torch-active.png.

Known remaining work: original vector renderer and fade, navigation and its
half-step/turn animation, scroll use, world-object and creature spawning,
physiological timing/combat, stable artifact-color decode and sound. Artifact
phase must remain fixed in screen coordinates; this milestone adds no color
cycling and does not change that requirement.
