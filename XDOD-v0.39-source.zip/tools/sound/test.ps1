$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Add-Type -Path (Join-Path $PSScriptRoot 'SoundTrace.cs')
$dir=Join-Path $root 'build/sound/tests';New-Item -ItemType Directory -Force $dir|Out-Null
$ca=Join-Path $root 'tools/host64/ca65.exe';$ld=Join-Path $root 'tools/host64/ld65.exe';$emu='E:/X16/x16emu_win64-r49/x16emu.exe';$rom='E:/X16/x16emu_win64-r49/rom.bin'
$checks=[Collections.Generic.List[object]]::new();$nl=[Environment]::NewLine
function Check($name,$ok){$checks.Add([pscustomobject]@{name=$name;pass=[bool]$ok});if(!$ok){throw "FAIL $name"};Write-Host "PASS $name"}
function Run($name,$body,[switch]$Rendered){
 $folder=Join-Path $dir $name;New-Item -ItemType Directory -Force $folder|Out-Null
 foreach($artifact in @('dump.bin','capture.wav','capture.gif')) {
  $path=Join-Path $folder $artifact
  if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path}
 }
 $stem=Join-Path $folder 'harness';$text='.include "main.s"'+$nl+'.segment "CODE"'+$nl+'test_entry:'+$nl+' sei'+$nl+' cld'+$nl+' lda #1'+$nl+' sta coupling'+$nl+$body+$nl+' jmp $ffff'+$nl;[IO.File]::WriteAllText("$stem.s",$text)
 & $ca -g -I (Join-Path $root 'src/sound') -o "$stem.o" "$stem.s";if($LASTEXITCODE){throw 'Assembler failed'}
 & $ld -C (Join-Path $root 'cfg/dodsound.cfg') -Ln "$stem.lbl" -o "$stem.prg" "$stem.o";if($LASTEXITCODE){throw 'Linker failed'}
 $symbols=@{};Get-Content "$stem.lbl"|ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.(\w+)$'){$symbols[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
 $prg=[IO.File]::ReadAllBytes("$stem.prg");$commands=[Text.StringBuilder]::new()
 if($Rendered){$p=$symbols.main_loop-0x801+2;$target=$symbols.test_entry;$prg[$p]=0x4c;$prg[$p+1]=$target -band 255;$prg[$p+2]=$target -shr 8;[IO.File]::WriteAllBytes("$stem.prg",$prg)}else{for($i=2;$i -lt $prg.Length;$i++){[void]$commands.AppendLine(('STM {0:X4} {1:X2}' -f (0x801+$i-2),$prg[$i]))};[void]$commands.AppendLine(('RUN {0:X4}' -f $symbols.test_entry))}
 $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$emu;$psi.WorkingDirectory=$folder;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardInput=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
 $psi.Arguments='-testbench -warp -sound none -dump RB -rom "'+$rom+'"'
 if($Rendered){$psi.Arguments='-warp -dump RBV -rom "'+$rom+'" -prg "'+$stem+'.prg" -run -wav "'+(Join-Path $folder 'capture.wav')+'" -gif "'+(Join-Path $folder 'capture.gif')+'"';$psi.EnvironmentVariables['SDL_VIDEODRIVER']='dummy';$psi.EnvironmentVariables['SDL_AUDIODRIVER']='dummy'}
 $p=[Diagnostics.Process]::new();$p.StartInfo=$psi
 try{[void]$p.Start();$stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync();if(!$Rendered){$write=$p.StandardInput.WriteAsync($commands.ToString());if(!$write.Wait(30000)){throw 'Write timeout'}};$p.StandardInput.Close();if(!$p.WaitForExit(30000)){throw "Timeout $name"};[IO.File]::WriteAllText((Join-Path $folder 'emulator.log'),$stdout.Result+$nl+$stderr.Result);if($p.ExitCode){throw "Emulator failed $name"};return ,([IO.File]::ReadAllBytes((Join-Path $folder 'dump.bin')))}finally{if(!$p.HasExited){$p.Kill()};$p.Dispose()}
}
$slots=@(0,1,2,3,4,5,6,7,8,9,10,10,20,11,12,13,14,15,16,15,21,22,17,18,19)
foreach($slot in 0..24){
 $group=if($slot -lt 13){0}elseif($slot -lt 22){1}else{2};$local=$slot-@(0,13,22)[$group]
 $body=[Text.StringBuilder]::new(' stz saved_bank'+$nl);$expected=[Collections.Generic.List[byte]]::new();$offset=0x400
 foreach($distance in 0..8){
  foreach($line in @(" lda #$local",' sta selected'," lda #$group",' sta sound_group'," lda #$distance",' sta distance',' jsr sound_expand')){[void]$body.AppendLine($line)}
  $pcm=[DodSoundTrace]::Decode(([DodSoundTrace]::Build($slots[$slot])).Encode(),$distance);$sum=0;$xor=0;foreach($v in $pcm){$sum=($sum+$v) -band 65535;$xor=$xor -bxor $v}
  $bank=2+[int][Math]::Floor($pcm.Length/8192);$ptr=0xa000+$pcm.Length%8192;$expected.AddRange([byte[]]@(($pcm.Length -band 255),(($pcm.Length -shr 8) -band 255),($pcm.Length -shr 16),($sum -band 255),($sum -shr 8),$xor,$bank,($ptr -band 255),($ptr -shr 8)))
  foreach($field in @('sample_count','sample_count+1','sample_count+2','sample_sum','sample_sum+1','sample_xor','end_bank','end_ptr','end_ptr+1')){[void]$body.AppendLine(" lda $field");[void]$body.AppendLine(((' sta '+[char]36+'{0:X4}') -f $offset));$offset++}
 }
 $actual=Run "volume-slot-$slot" $body.ToString();$same=$true;for($i=0;$i -lt $expected.Count;$i++){if($actual[0x400+$i] -ne $expected[$i]){$same=$false;Write-Host "Mismatch $i actual $($actual[0x400+$i]) expected $($expected[$i])";break}};Check "Slot $slot all nine distances and coupled PCM checksums" $same
}
foreach($case in @(@(0,0,0),@(0,9,0),@(1,4,0),@(2,0,0),@(0,12,8),@(1,7,0),@(1,8,0))){
 $g=$case[0];$sel=$case[1];$d=$case[2];$slot=@(0,13,22)[$g]+$sel
 $lines=@(' stz saved_bank'," lda #$sel",' sta selected'," lda #$g",' sta sound_group'," lda #$d",' sta distance',' jsr sound_expand')
 $actual=Run "pcm-$g-$sel-$d" ($lines -join $nl);$pcm=[DodSoundTrace]::Decode(([DodSoundTrace]::Build($slots[$slot])).Encode(),$d);$same=$true
 for($i=0;$i -lt $pcm.Length;$i++){if($actual[40960+2*8192+$i] -ne $pcm[$i]){$same=$false;break}};Check "Every coupled PCM byte $g/$sel/$d" $same
 Check "Quiet endpoints $g/$sel/$d" ($pcm[0] -eq 0 -and $pcm[$pcm.Length-1] -eq 0)
}
$liveBody=@(' cli'," lda #'2'",' jsr tester_key',' jsr $ffde',' sta test_time','live_wait:',' jsr pcm_feed',' lda playing',' beq live_done',' jsr $ffde',' sec',' sbc test_time',' cmp #180',' bcc live_wait','live_done:',' sei',' lda playing',' sta $0400',' lda AUDIO_RATE',' sta $0401',' lda play_rate',' sta $0402',' jmp $ffff','test_time: .byte 0')
$live=Run 'live-fifo' ($liveBody -join $nl) -Rendered
Check 'Rendered FIFO playback completes at default rate 058' ($live[0x400] -eq 0 -and $live[0x401] -eq 0 -and $live[0x402] -eq 58)
# Initialize reserved banks identically: r49 powers up unused RAM with random bytes.
$sentinel=" lda #1`n sta `$00`nreserve_bank:`n ldx #0`n lda #`$a5`nreserve_byte:`n"
foreach($page in 0..31){$sentinel+=(' sta ${0:x4},x' -f (0xa000+256*$page))+"`n"}
$sentinel+=" inx`n bne reserve_byte`n dec `$00`n bpl reserve_bank`n stz `$00`n"
$baseline=Run 'reserved-baseline' ($sentinel+' stz saved_bank')
$expanded=Run 'reserved-after' ($sentinel+(@(' stz saved_bank',' stz selected',' stz sound_group',' stz distance',' jsr sound_expand') -join $nl))
$safe=$true;for($i=40960;$i -lt 40960+16384;$i++){if($baseline[$i] -ne $expanded[$i]){$safe=$false;break}}
Check 'System bank zero and framebuffer bank one remain untouched' $safe
$keys=[Text.StringBuilder]::new(' cli'+$nl);$offset=0x400
foreach($case in @(@('0','sound_group'),@('9','selected'),@('0','sound_group'),@('3','selected'),@('0','sound_group'),@('D','selected'),@('F','coupling'),@('R','play_rate'),@('X','playing'))){[void]$keys.AppendLine(" lda #'$($case[0])'");[void]$keys.AppendLine(' jsr tester_key');[void]$keys.AppendLine(" lda $($case[1])");[void]$keys.AppendLine(((' sta '+[char]36+'{0:X4}') -f $offset));$offset++};[void]$keys.AppendLine(' sei')
$controls=Run 'controls' $keys.ToString() -Rendered
$expected=@(1,8,2,2,0,12,0,58,0);$good=$true;for($i=0;$i -lt $expected.Count;$i++){if($controls[0x400+$i] -ne $expected[$i]){$good=$false}}
Check 'Group cycling, weapon and heartbeat keys, raw toggle and reset' $good
$checks|ConvertTo-Json|Set-Content (Join-Path $dir 'report.json');Write-Host "All $($checks.Count) sound checks passed"
