$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Add-Type -Path (Join-Path $PSScriptRoot 'SoundTrace.cs')
$dest=Join-Path $root 'build/sound';New-Item -ItemType Directory -Force $dest|Out-Null
$asm=[Text.StringBuilder]::new(".segment ""RODATA""`nsound_table:`n")
$slots=@(0,1,2,3,4,5,6,7,8,9,10,10,20,11,12,13,14,15,16,15,21,22,17,18,19)
foreach($id in $slots){[void]$asm.AppendLine(" .word sound_$id")}
$meta=@()
for($i=0;$i -lt 25;$i++){$t=[DodSoundTrace]::Build($i);$data=$t.Encode();[IO.File]::WriteAllBytes((Join-Path $dest "sound-$i.rle"),$data);$pcm=[DodSoundTrace]::Decode($data,0);[DodSoundTrace]::Wav((Join-Path $dest "sound-$i.wav"),$pcm);[void]$asm.AppendLine("sound_${i}: .incbin ""../../build/sound/sound-$i.rle""");$meta+=[pscustomobject]@{id=$i;source_cycles=$t.Cycles;events=$t.Events.Count;encoded_bytes=$data.Length;pcm_samples=$pcm.Length;seconds_at_064=$pcm.Length/24414.0625;seconds_at_default_058=$pcm.Length/(24414.0625*58/64)}}
[IO.File]::WriteAllText((Join-Path $root 'src/sound/assets.inc'),$asm.ToString())
$meta|ConvertTo-Json|Set-Content (Join-Path $dest 'sound-manifest.json')
$meta|Format-Table id,events,encoded_bytes,pcm_samples,seconds_at_default_058

