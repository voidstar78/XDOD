// SOUNDS.ASM algorithm transcription for DODSOUND v0.1 calibration.
// 6809 control-path timing is estimated; arithmetic/envelopes/DAC quantization
// follow source. This is not a cycle-exact 6809 execution capture.
using System;
using System.IO;
using System.Collections.Generic;
public sealed class DodSoundTrace {
 public sealed class Event { public long Cycle; public byte Sample; public Event(long t,int a){Cycle=t;Sample=(byte)a;} }
 public readonly List<Event> Events=new List<Event>();
 public long Cycles; public int NoiseState; public const double Clock=894886.25,Rate=24414.0625;
 public DodSoundTrace(){Events.Add(new Event(0,0));Cycles=4474;}
 void Tick(long c){Cycles+=c;}
 void Out(int a){Tick(20);Events.Add(new Event(Cycles,a));Tick(14);}
 int Noise(){NoiseState=(NoiseState*5)&65535;NoiseState=(NoiseState&65280)|((NoiseState+1)&255);Tick(38);return NoiseState;}
 void Wait(int x){Tick(8L*(x==0?65536:x)+20);}
 void Squeak(int start){for(int x=start;x>0;x--){Out(255);Wait(x);Out(0);Wait(x);Tick(18);}}
 void Rattle(int n){for(int i=0;i<n;i++){for(int y=0;y<192;y++){Out(Noise()>>8);Tick(8);}Wait(4096);Tick(13);}}
 void Growl(int attack){int env=0;while(env+attack<=65535){env+=attack;int a=Noise()>>8;Tick(65);Out((a*(env>>8))>>8);Wait(240);Tick(12);}env=65535;while(env>64){env-=64;int a=Noise()>>8;Tick(65);Out((a*(env>>8))>>8);Wait(96);Tick(12);}}
 void Metal(int f1,int f2){int x=f1,y=f2,env=65535,a=0;while(env>96){Tick(16);if(--x==0){x=f1;a^=127;env-=96;if(env<=0)break;Tick(82);Out((a*(env>>8))>>8);}if(--y==0){y=f2;a^=128;env-=96;if(env<=0)break;Tick(82);Out((a*(env>>8))>>8);}}}
 void Boom(int pitch,int reps){for(int x=pitch;x!=336;x+=2)for(int y=0;y<reps;y++){Out(Noise()>>8);Wait(x);Tick(13);}}
 void Wizard(){for(int i=0;i<8;i++){int n=(Noise()&255)>>1;Squeak(n==0?1:n);}Boom(128,1);Wait(4096);Boom(80,4);}
 void Whoosh(bool attack){int env=0;if(attack){while(env+128<=65535){env+=128;int a=Noise()>>8;Tick(65);Out((a*(env>>8))>>8);Tick(12);}}env=65535;while(env>160){env-=160;int a=Noise()>>8;Tick(65);Out((a*(env>>8))>>8);Tick(12);}}
 void Heartbeat(int jiffies,int edges){int level=0;for(int i=0;i<edges;i++){level^=255;Events.Add(new Event(Cycles,level));Tick((long)Math.Round(Clock*jiffies/60.0*58.0/64.0));}}
 void Klink(){int env=65535;while(env>96){int a=(Noise()>>8)>>1;env-=96;Tick(67);Out((a*(env>>8))>>8);if(env<=96)break;a=(Noise()>>8)|128;env-=96;Tick(67);Out((a*(env>>8))>>8);}}
 // WIZIX/WIZOX use KABOOM, the same tail reached by BDLBDL.
 // Locate its first complete RLE event so gameplay can share the wizard payload.
 public static int IntroExplosionOffset(){var prefix=new DodSoundTrace();for(int i=0;i<8;i++){int n=(prefix.Noise()&255)>>1;prefix.Squeak(n==0?1:n);}var full=Build(10);int bytes=0;for(int i=0;i<prefix.Events.Count;i++){long start=(long)Math.Round(full.Events[i].Cycle*Rate/Clock),end=(long)Math.Round(full.Events[i+1].Cycle*Rate/Clock);long count=end-start;while(count>0){int n=(int)Math.Min(65535,count);bytes+=n<=255?2:4;count-=n;}}return bytes;}
 public static DodSoundTrace Build(int id){var t=new DodSoundTrace();switch(id){case 0:t.Squeak(32);break;case 1:t.Rattle(10);break;case 2:t.Growl(768);break;case 3:for(int x=1280;x<2048;x+=48){t.Out(255);t.Wait(x);t.Out(0);t.Wait(x);t.Tick(16);}break;case 4:t.Metal(175,54);break;case 5:t.Growl(512);break;case 6:t.Rattle(2);break;case 7:t.Metal(50,18);break;case 8:t.Rattle(1);break;case 9:t.Growl(256);break;case 10:t.Wizard();break;case 11:for(int i=0;i<4;i++)t.Squeak(128);break;
case 12:for(int i=0;i<10;i++)t.Squeak(64);break;
case 13:t.Squeak(256);break;
case 14:t.Metal(100,36);break;
case 15:t.Whoosh(true);break;
case 16:t.Whoosh(false);break;
case 17:t.Heartbeat(46,2);break;
case 18:t.Heartbeat(16,4);break;
case 19:t.Heartbeat(3,8);break;
case 20:t.Wizard();t.Out(0);t.Tick((long)(Clock*0.7*58.0/64.0));t.Wizard();break;
case 21:t.Klink();break;
case 22:t.Metal(25,9);break;
case 23:t.Boom(80,5);break; // SWCHAR:BANGD / PATTK:A$EXP0
case 24:t.Boom(128,1);break; // SWCHAR:THUDD / PSTEP:A$THUD
default:throw new Exception("Unknown source sound");}t.Events.Add(new Event(t.Cycles+40,0));t.Cycles+=107386;return t;}
 public byte[] Encode(){var bytes=new List<byte>();for(int i=0;i<Events.Count;i++){long start=(long)Math.Round(Events[i].Cycle*Rate/Clock);long end=(long)Math.Round((i+1<Events.Count?Events[i+1].Cycle:Cycles)*Rate/Clock);int count=(int)(end-start);while(count>0){int n=Math.Min(65535,count);bytes.Add(Events[i].Sample);if(n<=255)bytes.Add((byte)n);else{bytes.Add(0);bytes.Add((byte)n);bytes.Add((byte)(n>>8));}count-=n;}}bytes.Add(0);bytes.Add(0);bytes.Add(0);bytes.Add(0);return bytes.ToArray();}
 public static byte Scale(int a,int distance){int v=255-31*distance;int max=((255*v)>>8)&252;return unchecked((byte)((((a*v)>>8)&252)-max/2));}
 public static byte[] Decode(byte[] encoded,int distance,bool coupled=true){return DecodeGain(encoded,255-31*distance,coupled);}
 public static byte[] DecodeGain(byte[] encoded,int gain,bool coupled=true){var pcm=new List<byte>();short dc=(short)((sbyte)unchecked((byte)(-((((255*gain)>>8)&252)/2)))*256);for(int p=0;p<encoded.Length;){int a=encoded[p++],n=encoded[p++];if(n==0){n=encoded[p++]+256*encoded[p++];if(n==0)break;}byte raw=unchecked((byte)((((a*gain)>>8)&252)-((((255*gain)>>8)&252)/2)));for(int i=0;i<n;i++){int x=(sbyte)raw,y=x;if(coupled){dc=unchecked((short)(dc+x-(dc>>8)));y=x-(dc>>8);y=Math.Max(-128,Math.Min(127,y));}pcm.Add(unchecked((byte)y));}}return pcm.ToArray();}
 public static void Wav(string path,byte[] signedPcm){using(var b=new BinaryWriter(File.Create(path))){int rate=22125;b.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));b.Write(36+signedPcm.Length);b.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));b.Write(16);b.Write((short)1);b.Write((short)1);b.Write(rate);b.Write(rate);b.Write((short)1);b.Write((short)8);b.Write(System.Text.Encoding.ASCII.GetBytes("data"));b.Write(signedPcm.Length);foreach(byte v in signedPcm)b.Write((byte)(v^128));}}
}
