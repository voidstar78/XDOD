$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
& (Join-Path $PSScriptRoot 'generate.ps1')
& (Join-Path $root 'tools/host64/ca65.exe') -g -I (Join-Path $root 'src/sound') -l (Join-Path $root 'build/sound/DODSOUND.lst') -o (Join-Path $root 'build/sound/DODSOUND.o') (Join-Path $root 'src/sound/main.s')
if($LASTEXITCODE){throw 'Sound tester assembly failed'}
& (Join-Path $root 'tools/host64/ld65.exe') -C (Join-Path $root 'cfg/dodsound.cfg') -m (Join-Path $root 'build/sound/DODSOUND.map') -Ln (Join-Path $root 'build/sound/DODSOUND.lbl') -o (Join-Path $root 'DODSOUND.PRG') (Join-Path $root 'build/sound/DODSOUND.o')
if($LASTEXITCODE){throw 'Sound tester linking failed'}
Write-Host "Built DODSOUND.PRG ($((Get-Item (Join-Path $root 'DODSOUND.PRG')).Length) bytes)"

