$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
New-Item -ItemType Directory -Force -Path (Join-Path $root 'build/sound') | Out-Null
if(-not ('DodSoundTrace' -as [type])){Add-Type -Path (Join-Path $PSScriptRoot 'SoundTrace.cs')}
Add-Type @'
using System;using System.Collections.Generic;
public static class GameLz {
 public static byte[] Pack(byte[] b){var o=new List<byte>();int p=0;while(p<b.Length){int f=o.Count;o.Add(0);for(int bit=0;bit<8&&p<b.Length;bit++){int len=0,dist=0;for(int d=1;d<=4096&&d<=p;d++){int n=0;while(n<18&&p+n<b.Length&&b[p+n]==b[p+n-d])n++;if(n>len){len=n;dist=d;if(n==18)break;}}if(len>=3&&len<18&&p+1<b.Length){int next=0;for(int d=1;d<=4096&&d<=p+1;d++){int n=0;while(n<18&&p+1+n<b.Length&&b[p+1+n]==b[p+1+n-d])n++;if(n>next)next=n;}if(next>len+1)len=0;}if(len>=3){o[f]|=(byte)(1<<bit);dist--;o.Add((byte)dist);o.Add((byte)(((dist>>8)&15)|((len-3)<<4)));p+=len;}else o.Add(b[p++]);}}return o.ToArray();}
 public static int[] Weights(byte[] b){long[] f=new long[511];int[] parent=new int[511];foreach(byte v in b)f[v]++;var nodes=new List<int>();for(int i=0;i<256;i++)nodes.Add(i);for(int k=256;k<511;k++){nodes.Sort((x,y)=>f[x]!=f[y]?f[x].CompareTo(f[y]):x.CompareTo(y));int a=nodes[0],c=nodes[1];nodes.RemoveRange(0,2);f[k]=f[a]+f[c];parent[a]=parent[c]=k;nodes.Add(k);}int[] w=new int[256];for(int i=0;i<256;i++){for(int t=i;t!=510;t=parent[t])w[i]++;}return w;}
 public static long Score(byte[] b){int[] w=Weights(b);long n=0;foreach(byte v in b)n+=w[v];return n;}
 public static byte[] Optimal(byte[] b,int[] w){int n=b.Length;var positions=new Dictionary<int,List<int>>();for(int p=0;p+2<n;p++){int h=b[p]|(b[p+1]<<8)|(b[p+2]<<16);List<int> a;if(!positions.TryGetValue(h,out a)){a=new List<int>();positions[h]=a;}a.Add(p);}long[] cost=new long[n+1];int[] len=new int[n],dist=new int[n];for(int p=n-1;p>=0;p--){cost[p]=1+w[b[p]]+cost[p+1];len[p]=1;if(p+2>=n)continue;var a=positions[b[p]|(b[p+1]<<8)|(b[p+2]<<16)];int j=a.BinarySearch(p)-1;for(;j>=0&&a[j]>=p-4096;j--){int q=a[j],m=3;while(m<18&&p+m<n&&b[p+m]==b[q+m])m++;int d=p-q-1;for(int z=3;z<=m;z++){long c=1+w[d&255]+w[(d>>8)|((z-3)<<4)]+cost[p+z];if(c<cost[p]||(c==cost[p]&&z>len[p])){cost[p]=c;len[p]=z;dist[p]=d;}}}}var o=new List<byte>();int at=0;while(at<n){int f=o.Count;o.Add(0);for(int bit=0;bit<8&&at<n;bit++){if(len[at]>=3){o[f]|=(byte)(1<<bit);o.Add((byte)dist[at]);o.Add((byte)((dist[at]>>8)|((len[at]-3)<<4)));}else o.Add(b[at]);at+=len[at];}}return o.ToArray();}
 public static byte[] Compress(byte[] b){byte[] best=Pack(b),current=best;long score=Score(best);for(int i=0;i<3;i++){current=Optimal(b,Weights(current));long s=Score(current);if(s<score){best=current;score=s;}}return best;}
}
'@
$raw=[Collections.Generic.List[byte]]::new();$offsets=@()
foreach($i in (@(0..10)+@(11..16)+@(21,22))){$offsets+= $raw.Count;$raw.AddRange(([DodSoundTrace]::Build($i)).Encode())}
$engineOffset=$raw.Count
$engine=[IO.File]::ReadAllBytes((Join-Path $root 'src/save_engine.bin'))
if($engine.Length -lt 1 -or $engine.Length -gt 3840){throw 'Runtime save helper exceeds its reserved code space'}
$raw.AddRange($engine)
$font=[byte[]]@([regex]::Matches((Get-Content (Join-Path $root 'src/font.inc') -Raw),'\$([0-9A-Fa-f]{2})')|ForEach-Object {[Convert]::ToByte($_.Groups[1].Value,16)})
if($font.Length -ne 512){throw 'Unexpected original font size'}
$raw.AddRange($font)
$bangTiming=([DodSoundTrace]::Build(23)).Encode();$thudTiming=([DodSoundTrace]::Build(24)).Encode()
$timing=[Collections.Generic.List[byte]]::new()
for($g=0;$g -lt 128;$g++){
 $values=@(for($j=0;$j -lt 5;$j++){$bangTiming[3+2*($g*5+$j)]})
 $base=($values|Measure-Object -Minimum).Minimum;$mask=0
 for($j=0;$j -lt 5;$j++){$mask=$mask -bor (($values[$j]-$base) -shl $j)}
 $timing.Add([byte]$base);$timing.Add([byte]$mask)
}
$timing.Add(0);$timing.AddRange([byte[]]$bangTiming[1282..1289]);$timing.AddRange([byte[]]$thudTiming[210..217])
for($i=0;$i -lt 104;$i++){$timing.Add($thudTiming[3+2*$i])};$timing.Add(0)
if($timing.Count -ne 378){throw 'Unexpected packed timing-table size'}
$raw.AddRange($timing.ToArray())
$motionText=Get-Content (Join-Path $root 'src/motion_data.inc') -Raw
$motionData=[byte[]]@([regex]::Matches($motionText,'\.byte ([0-9,]+)')|ForEach-Object {$_.Groups[1].Value.Split(',')|ForEach-Object {[byte]$_}})
$raw.AddRange($motionData)
$packed=[GameLz]::Compress($raw.ToArray())
$freq=New-Object long[] 511
foreach($v in $packed){$freq[$v]++}
$nodes=[Collections.Generic.List[int]]::new();foreach($i in 0..255){$nodes.Add($i)}
$left=New-Object int[] 511;$right=New-Object int[] 511
foreach($i in 256..510){$two=@($nodes|Sort-Object {$freq[$_]},{$_}|Select-Object -First 2);$left[$i]=$two[0];$right[$i]=$two[1];$freq[$i]=$freq[$two[0]]+$freq[$two[1]];[void]$nodes.Remove($two[0]);[void]$nodes.Remove($two[1]);$nodes.Add($i)}
$codes=@{}
function Codes($n,$bits){if($n -lt 256){$codes[[int]$n]=$bits;return};Codes $left[$n] ($bits+'0');Codes $right[$n] ($bits+'1')}
Codes 510 ''
$order=@(0..255 | Sort-Object {$codes[$_].Length},{$_});$counts=New-Object byte[] 24;$code=0;$previous=0
foreach($n in $order){$len=$codes[$n].Length;$counts[$len]++;$code=$code -shl ($len-$previous);$codes[$n]=[Convert]::ToString($code,2).PadLeft($len,'0');$code++;$previous=$len}
$huff=[Collections.Generic.List[byte]]::new();$v=0;$count=0
foreach($b in $packed){foreach($n in @([int]$b)){foreach($bit in $codes[[int]$n].ToCharArray()){$v=($v -shl 1)+[int]($bit -eq '1');$count++;if($count -eq 8){$huff.Add($v);$v=0;$count=0}}}}
if($count){$huff.Add($v -shl (8-$count))}
$packed=$huff.ToArray()
$explosion=$offsets[10]+[DodSoundTrace]::IntroExplosionOffset()
$bang=$engineOffset
$offsets+= $explosion
$offsets+= $bang
$offsets+= $bang+([DodSoundTrace]::Build(23)).Encode().Length
[IO.File]::WriteAllBytes((Join-Path $root 'build/sound/monsters.lz'),$packed)
[IO.File]::WriteAllBytes((Join-Path $root 'src/monsters.lz'),$packed)
$a=@('; Losslessly packed approved DODSOUND source traces.',' .segment "RODATA"','audio_banks:',(' .byte '+(($offsets|ForEach-Object {2+[int][Math]::Floor($_/8192)}) -join ',')),'audio_pointers:')
foreach($off in $offsets){$a+=(' .word ${0:x4}' -f (0xa000+$off%8192))}
$cacheBanks=@();$playLengths=@();$nextBank=6
foreach($voice in 0..21){
 $trace=if($voice -le 10){$voice}elseif($voice -le 16){$voice}elseif($voice -eq 17){21}elseif($voice -eq 18){22}elseif($voice -eq 20){23}elseif($voice -eq 21){24}else{10}
 $encoded=([DodSoundTrace]::Build($trace)).Encode()
 if($voice -eq 19){$encoded=$encoded[[DodSoundTrace]::IntroExplosionOffset()..($encoded.Length-1)]}
 $pcm=[DodSoundTrace]::DecodeGain($encoded,255)
 $length=$pcm.Length
 $last=$length-1
 while($last -gt 0){$sample=[int]$pcm[$last];if($sample -ge 128){$sample-=256};if([Math]::Abs($sample) -gt 1){break};$last--}
 $playLengths+=[Math]::Min($length,$last+129) # retain 128 settled samples; remove only the artificial quiet tail
 if($voice -eq 19){$cacheBanks+=$cacheBanks[10];continue} # wizard/explosion share one five-bank slot
 $cacheBanks+=$nextBank
 $nextBank+=[int][Math]::Ceiling($length/8192.0)
}
if($nextBank -gt 64){throw 'PCM voice caches exceed the X16 minimum 512KB RAM'}
$a+='audio_pcm_banks: .byte '+($cacheBanks -join ',')
$a+='audio_pcm_play_lo: .byte '+(($playLengths|ForEach-Object {$_ -band 255}) -join ',')
$a+='audio_pcm_play_hi: .byte '+(($playLengths|ForEach-Object {$_ -shr 8}) -join ',')
$a+='AUDIO_PCM_BANK_END='+$nextBank
$a+='AUDIO_RAW_SIZE='+$raw.Count
$a+='AUDIO_ENGINE_BANK='+(2+[int][Math]::Floor($engineOffset/8192))
$a+=('AUDIO_ENGINE_POINTER=${0:x4}' -f (0xa000+$engineOffset%8192))
$a+=('AUDIO_ENGINE_END=${0:x4}' -f (0x8000+$engine.Length))
$bangData=([DodSoundTrace]::Build(23)).Encode()
if($bangData.Length -ne 1290){throw 'Unexpected BANG encoding layout'}
$a+='AUDIO_BANG_INITIAL='+$bangData[1]
$a+='.ifdef TEST_NO_AUDIO'
$a+='audio_bang_counts:'
for($g=0;$g -lt 128;$g++){
 $values=@(for($j=0;$j -lt 5;$j++){$bangData[3+2*($g*5+$j)]})
 $base=($values|Measure-Object -Minimum).Minimum;$mask=0
 for($j=0;$j -lt 5;$j++){if($values[$j]-$base -gt 1){throw 'BANG timing span exceeds one sample'};$mask=$mask -bor (($values[$j]-$base) -shl $j)}
 $a+=' .byte '+$base+','+$mask
}
$a+=' .byte 0'
$a+='audio_bang_tail: .byte '+($bangData[1282..1289] -join ',')
$thudData=([DodSoundTrace]::Build(24)).Encode()
if($thudData.Length -ne 218 -or $thudData[1] -ne $bangData[1]){throw 'Unexpected THUD RLE layout'}
$a+=' .byte '+($thudData[210..217] -join ',')
$a+='audio_thud_counts:'
for($i=0;$i -lt 104;$i+=16){$values=@(for($j=$i;$j -lt [Math]::Min(104,$i+16);$j++){$thudData[3+2*$j]});$a+=' .byte '+($values -join ',')}
$a+=' .byte 0'
$a+='.endif'
$a+='audio_huff_counts: .byte '+($counts -join ',')
$a+='audio_huff_symbols: .byte '+($order -join ',')
$a+='.segment "ONCE_DATA"'
$a+='audio_packed_data:'
$a+='.ifndef TEST_NO_AUDIO'
$a+=' .incbin "monsters.lz"'
$a+='.else'
$a+=' .byte 0'
$a+='.endif'
[IO.File]::WriteAllLines((Join-Path $root 'src/audio_assets.inc'),$a)
Write-Host "Packed $($raw.Count) startup bytes (sounds, save helper, font and vectors) into $($packed.Length) bytes."




