# Convert SWCHAR.ASM's original packed 5x7 glyphs to the existing 4-bpp surface.
# ASCII digits/diagnostic-only punctuation retain the prototype's fallback glyphs.
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$path=Join-Path $root 'src\font.inc'
$old=[IO.File]::ReadAllText($path)
$font=[byte[]]@([regex]::Matches($old,'\$([0-9A-Fa-f]{2})') | ForEach-Object {[Convert]::ToByte($_.Groups[1].Value,16)})
if($font.Length -eq 512){
 $expanded=New-Object byte[] 2048
 foreach($g in 0..63){foreach($r in 0..7){foreach($q in 0..3){$v=$font[$g*8+$r];$expanded[$g*32+$r*4+$q]=(($v -shr (7-2*$q)) -band 1)*16+(($v -shr (6-2*$q)) -band 1)}}}
 $font=$expanded
}
if($font.Length -ne 2048){throw 'Expected 64 ASCII glyphs'}
$original=[IO.File]::ReadAllText((Join-Path $root 'reference\original\SWCHAR.ASM'))
$bytes=@([regex]::Matches($original,'(?m)^\s*FCB\s+%([01]{8})') | Select-Object -First 155 | ForEach-Object {$_.Groups[1].Value})
if($bytes.Count -ne 155){throw 'Incomplete original glyph table'}
for($glyph=0;$glyph -lt 31;$glyph++){
    $ascii=if($glyph -eq 0){32}elseif($glyph -le 26){64+$glyph}elseif($glyph -eq 27){33}elseif($glyph -eq 28){95}elseif($glyph -eq 29){63}else{46}
    $bits=$bytes[($glyph*5)..($glyph*5+4)] -join ''
    for($row=0;$row -lt 8;$row++){
        $value=if($row -lt 7){[Convert]::ToInt32($bits.Substring(5+5*$row,5),2) -shl 2}else{0}
        for($pair=0;$pair -lt 4;$pair++){
            $packed=(($value -shr (7-2*$pair)) -band 1)*16+(($value -shr (6-2*$pair)) -band 1)
            $font[($ascii-32)*32+$row*4+$pair]=$packed
        }
    }
}
$special=[regex]::Match($original,'(?ms)^SPCTAB\s+EQU(.*?)^THUDD').Groups[1].Value
$heart=@([regex]::Matches($special,'(?m)^\s*FCB\s+%([01]{8})') | ForEach-Object {[Convert]::ToInt32($_.Groups[1].Value,2)})
if($heart.Count -ne 28){throw 'Expected four seven-row heart halves'}
for($glyph=0;$glyph -lt 4;$glyph++){
    for($row=0;$row -lt 8;$row++){
        $value=if($row -lt 7){$heart[$glyph*7+$row]}else{0}
        for($pair=0;$pair -lt 4;$pair++){
            $font[(91+$glyph-32)*32+$row*4+$pair]=(($value -shr (7-2*$pair)) -band 1)*16+(($value -shr (6-2*$pair)) -band 1)
        }
    }
}
$packed=[Collections.Generic.List[byte]]::new()
foreach($g in 0..63){foreach($r in 0..7){$v=0;foreach($q in 0..3){$pair=$font[$g*32+$r*4+$q];$v=($v -shl 2)+[int](($pair -band 16) -ne 0)*2+[int](($pair -band 1) -ne 0)};$packed.Add($v)}}
$font=$packed.ToArray()
$out=[Text.StringBuilder]::new(@'
; Original CoCo SWCHAR glyphs and SPCTAB heart halves; diagnostic fallback digits.
.ifndef TEST_NO_AUDIO
.segment "BSS"
font_data: .res 512
font_data_end:
audio_bang_counts: .res 257
audio_bang_tail: .res 16
audio_thud_counts: .res 105
startup_assets_end:
.segment "RODATA"
.else
font_data:
'@+"`n")
for($i=0;$i -lt $font.Length;$i+=16){[void]$out.AppendLine(' .byte '+(($font[$i..($i+15)] | ForEach-Object {'${0:X2}' -f $_}) -join ','))}
[void]$out.AppendLine('font_data_end:')
[void]$out.AppendLine('.endif')
[void]$out.AppendLine('.ifdef TEST_NO_AUDIO')
[void]$out.AppendLine('startup_assets_end=font_data_end')
[void]$out.AppendLine('.endif')
[IO.File]::WriteAllText($path,$out.ToString())
Write-Host 'Imported original space, A-Z, !, _, ?, and . glyphs from packed source.'
