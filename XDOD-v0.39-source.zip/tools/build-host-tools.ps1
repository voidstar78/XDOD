[CmdletBinding()]
param([string]$SourceRoot='E:\X16\c_code\cc65-master',[string]$CompilerBin='C:\msys64\ucrt64\bin')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$src=Join-Path $SourceRoot 'src'
$gcc=Join-Path $CompilerBin 'gcc.exe'; $ar=Join-Path $CompilerBin 'ar.exe'
foreach($path in @($src,$gcc,$ar)){if(!(Test-Path -LiteralPath $path)){throw "Missing $path"}}
$work=Join-Path $root 'build\host-tools'; $dest=Join-Path $PSScriptRoot 'host64'
New-Item -ItemType Directory -Force -Path $work,$dest | Out-Null
$oldPath=$env:PATH
try {
    $env:PATH=$CompilerBin+';'+$oldPath
    Push-Location $work
    try {
        $common=@(Get-ChildItem -LiteralPath (Join-Path $src 'common') -Filter '*.c' | ForEach-Object FullName)
        & $gcc -O2 -I (Join-Path $src 'common') '-DBUILD_ID="local"' -c @common
        if($LASTEXITCODE -ne 0){throw 'cc65 common compile failed'}
        $objects=@($common | ForEach-Object {[IO.Path]::GetFileNameWithoutExtension($_)+'.o'})
        if(Test-Path -LiteralPath 'common.a'){Remove-Item -LiteralPath 'common.a'}
        & $ar rcs common.a @objects
        if($LASTEXITCODE -ne 0){throw 'cc65 archive failed'}
        foreach($tool in @('ca65','ld65')) {
            $files=@(Get-ChildItem -LiteralPath (Join-Path $src $tool) -Filter '*.c' | ForEach-Object FullName)
            & $gcc -O2 -I (Join-Path $src 'common') '-DBUILD_ID="local"' @files common.a -o (Join-Path $dest ($tool+'.exe'))
            if($LASTEXITCODE -ne 0){throw "$tool link failed"}
        }
    } finally {Pop-Location}
    Copy-Item -LiteralPath (Join-Path $SourceRoot 'LICENSE') -Destination (Join-Path $dest 'LICENSE')
    $manifest=@()
    foreach($folder in @('common','ca65','ld65')) {
        $manifest+=Get-ChildItem -LiteralPath (Join-Path $src $folder) -File | Where-Object {$_.Extension -in @('.c','.h')} | ForEach-Object {
            [pscustomobject]@{file=($folder+'/'+$_.Name);sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
        }
    }
    $manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $dest 'source-manifest.json') -Encoding UTF8
    & (Join-Path $dest 'ca65.exe') --version
    & (Join-Path $dest 'ld65.exe') --version
} finally {$env:PATH=$oldPath}
