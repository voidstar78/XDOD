# Re-run only the positive combat/presentation fixtures after a full suite.
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$priorPath=Join-Path $root 'build/tests/report.json'
if(!(Test-Path $priorPath)){$priorPath=Join-Path $root 'build/v021-base-report.json'}
$prior=Get-Content $priorPath -Raw | ConvertFrom-Json
$prior | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $root 'build/v021-base-report.json')
$beforeHash=(Get-FileHash (Join-Path $root 'XDOD.PRG')).Hash
$workflow=Get-Content (Join-Path $root 'tools/workflow.ps1') -Raw
$prefix=$workflow.Substring(0,$workflow.IndexOf('$seedTable='))
$prefix=$prefix.Replace('$PSScriptRoot',("'"+$PSScriptRoot+"'"))
Invoke-Expression $prefix
$Ca65=Join-Path $root 'tools/host64/ca65.exe'
$Ld65=Join-Path $root 'tools/host64/ld65.exe'
$Emulator='E:\X16\x16emu_win64-r49\x16emu.exe'
$TimeoutSeconds=30
if((Get-FileHash (Join-Path $root 'XDOD.PRG')).Hash -ne $beforeHash -or $beforeHash -ne $prior.prg_sha256){throw 'Production changed; run the full workflow instead.'}
$ast=[Management.Automation.Language.Parser]::ParseInput($workflow,[ref]$null,[ref]$null)
$export=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Export-MachineImage'},$true)
Invoke-Expression $export.Extent.Text
$inventory=Get-Content (Join-Path $root 'tests/Inventory.ps1') -Raw
$ast=[Management.Automation.Language.Parser]::ParseInput($inventory,[ref]$null,[ref]$null)
foreach($name in @('Command-Assembly','Text-Pixels-Equal')){$f=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true);Invoke-Expression $f.Extent.Text}
$production=[IO.File]::ReadAllBytes((Join-Path $root 'XDOD.PRG'))
if(-not ('WorldReference' -as [type])){Add-Type -Path (Join-Path $root 'tests/WorldReference.cs')}
$worldSetup=" jsr setup_vera`n jsr draw_background`n jsr inventory_init`n jsr world_init`n jsr world_add_test_scroll`n stz heart_state`n"
$litSetup=$worldSetup+" stz maze_level`n jsr maze_generate`n"+(Command-Assembly 'P R T')+(Command-Assembly 'U R')
. (Join-Path $root 'tests/CombatPresentation.ps1')
$geometry=Get-Content (Join-Path $root 'tests/world-geometry.json') -Raw | ConvertFrom-Json
$shapeList=[Collections.Generic.List[int[][]]]::new()
foreach($shape in $geometry.shapes){$lines=[Collections.Generic.List[int[]]]::new();foreach($line in $shape.lines){$lines.Add([int[]]$line)};$shapeList.Add($lines.ToArray())}
$worldModel=[WorldReference]::new($shapeList.ToArray(),[int[]]$geometry.scales)
$fullMaps=@(,([DaggorathReference]::new([byte[]]@(0x73,0xc7,0x5d))).Full())
. (Join-Path $root 'tests/Increment23.ps1')
$newNames=@($checks | ForEach-Object {$_.name})
$prior.checks=@($prior.checks | Where-Object {$_.name -notin $newNames})+@($checks.ToArray())
$prior.time=Get-Date -Format o
foreach($file in $prior.provenance){$file.sha256=(Get-FileHash -LiteralPath $file.file).Hash}
$prior | ConvertTo-Json -Depth 6 | Set-Content $reportPath
if(@($prior.checks | Where-Object {!$_.pass}).Count){throw 'Regression checks failed'}
Write-Host "All $($prior.checks.Count) checks passed; unchanged production binary verified."
