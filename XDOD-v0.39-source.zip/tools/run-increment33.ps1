$ErrorActionPreference='Stop'
$Ca65='E:\X16\c_code\cc65-snapshot-win32\bin\XDOD\tools\host64\ca65.exe'
$Ld65='E:\X16\c_code\cc65-snapshot-win32\bin\XDOD\tools\host64\ld65.exe'
$Emulator='E:\X16\x16emu_win64-r49\x16emu.exe'
$TimeoutSeconds=60
$workflow=Get-Content (Join-Path $PSScriptRoot 'workflow.ps1') -Raw
$prefix=$workflow.Substring($workflow.IndexOf('$ErrorActionPreference='),$workflow.IndexOf('$seedTable=')-$workflow.IndexOf('$ErrorActionPreference='))
$prefix=$prefix.Replace('$PSScriptRoot',("'"+$PSScriptRoot+"'"))
Invoke-Expression $prefix
foreach($file in @('tools/workflow.ps1','tests/Inventory.ps1','tests/CombatPresentation.ps1','tests/SaveLoad.ps1')){
 $ast=[Management.Automation.Language.Parser]::ParseInput((Get-Content (Join-Path $root $file) -Raw),[ref]$null,[ref]$null)
 foreach($name in @('Export-MachineImage','Command-Assembly','Text-Pixels-Equal','Invoke-Combat','Save-TestSymbols')){
  $f=$ast.Find({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq $name},$true)
  if($f){Invoke-Expression $f.Extent.Text}
 }
}
$worldSetup=" jsr setup_vera`n jsr inventory_init`n jsr world_init`n stz heart_state`n"
$commandRoutine=@"
test_command:
 sta str_ptr
 sty str_ptr+1
 ldy #0
@copy:
 lda (str_ptr),y
 sta input_buf,y
 beq @run
 iny
 bra @copy
@run:
 sty input_len
 jmp handle_command
"@
. (Join-Path $root 'tests/Increment33.ps1')
. (Join-Path $root 'tests/Increment34.ps1')
$checks.ToArray()|ConvertTo-Json -Depth 4|Set-Content (Join-Path $results 'increment33.json')
if(@($checks|Where-Object {!$_.pass}).Count){throw 'Increment 33 checks failed'}

