# Decode the actual packed TOKEN.ASM bits; do not infer vocabulary from comments.
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$source=[IO.File]::ReadAllText((Join-Path $root 'reference\original\TOKEN.ASM'))
function Read-Table($start,$end,$count){
    $section=[regex]::Match($source,"(?ms)^$start\s+FCB.*?^$end\s+EQU").Value
    $entries=[regex]::Matches($section,'(?ms)^\s*XDEF\s+T\.(\w+),[^\r\n]+(.*?)(?=^\s*XDEF|\z)')
    $result=@()
    foreach($e in $entries | Select-Object -First $count){
        $bits=([regex]::Matches($e.Groups[2].Value,'(?m)^\s*FCB\s+%([01]{8})') | ForEach-Object {$_.Groups[1].Value}) -join ''
        $length=[Convert]::ToInt32($bits.Substring(0,5),2)
        $class=[Convert]::ToInt32($bits.Substring(5,5),2)
        $word='';for($i=0;$i -lt $length;$i++){$word += [char](64+[Convert]::ToInt32($bits.Substring(10+5*$i,5),2))}
        $result+= [pscustomobject]@{symbol=$e.Groups[1].Value;word=$word;class=$class}
    }
    if($result.Count -ne $count){throw "Incomplete $start"}
    return $result
}
$commands=@(Read-Table 'CMDTAB' 'CMDNUM' 15)
$directions=@(Read-Table 'DIRTAB' 'DIRNUM' 6)
$adjectives=@(Read-Table 'ADJTAB' 'ADJNUM' 25)
$generics=@(Read-Table 'GENTAB' 'GENNUM' 6)
$out=[Text.StringBuilder]::new('; Generated from original packed TOKEN.ASM and DTABAS.ASM. Do not edit.'+"`n")
foreach($table in @(@{name='commands';items=$commands},@{name='directions';items=$directions},@{name='adjectives';items=$adjectives},@{name='generics';items=$generics})){
    [void]$out.AppendLine($table.name+'_table:')
    for($i=0;$i -lt $table.items.Count;$i++){[void]$out.AppendLine(' .word '+$table.name+"_$i")}
    for($i=0;$i -lt $table.items.Count;$i++){[void]$out.AppendLine(($table.name+"_$i"+': .byte "'+$table.items[$i].word+'",0'))}
}
$database=[IO.File]::ReadAllText((Join-Path $root 'reference\original\DTABAS.ASM'))
$rows=@()
foreach($block in @('OBJXXX','SPCXXX')){
    $section=[regex]::Match($database,"(?ms)^$block\s+MACR(.*?)^\s+ENDM").Groups[1].Value
    foreach($entry in [regex]::Matches($section,'(?m)^\s*\\[12]\s+(\w+),([^\r\n]+)')){
        $rows+=,(@($entry.Groups[1].Value)+@($entry.Groups[2].Value.Split(',')))
    }
}
if($rows.Count -ne 25){throw 'Expected 25 original object definitions'}
for($i=0;$i -lt 25;$i++){[void]$out.AppendLine(('TYPE_'+$adjectives[$i].symbol+" = $i"))}
[void]$out.AppendLine('object_definitions:')
for($i=0;$i -lt 25;$i++){[void]$out.AppendLine((' .byte '+$adjectives[$i].class+','+($rows[$i][3..5] -join ',')))}
[void]$out.AppendLine('object_special:')
for($i=0;$i -lt 25;$i++){
    $values=@(0,0,0)
    if($rows[$i].Count -ge 11){$values=$rows[$i][8..10]}
    $values=@($values | ForEach-Object {if($_ -match '^T\.(\w+)$'){'TYPE_'+$matches[1]}else{$_}})
    [void]$out.AppendLine(' .byte '+($values -join ','))
}
[void]$out.AppendLine('original_weights: .byte 5,1,10,25,25,10')
[IO.File]::WriteAllText((Join-Path $root 'src\original_tables.inc'),$out.ToString())
Write-Host 'Decoded 15 commands, 6 directions, 25 adjectives and 6 generics from original packed bytes.'
