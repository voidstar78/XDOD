# Compile original vector lists to fixed-point DDA records. No invented geometry.
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$stream=[Collections.Generic.List[object]]::new();$labels=@{}
$special=@{'V$NEW'=255;'V$END'=254;'V$JMP'=253;'V$REL'=252;'V$JSR'=251;'V$RTS'=250}
foreach($file in @('VARC.ASM','VERT.ASM','D3.ASM','D4.ASM','VOBJ.ASM')){
    foreach($line in Get-Content -LiteralPath (Join-Path $root ('reference\original\'+$file))){
        $code=($line -split ';',2)[0]
        if($code -match '^([A-Z][A-Z0-9]*)\s+(FCB|FDB|SVORG|SVECT|SVEND|SVNEW)'){$labels[$matches[1]]=$stream.Count}
        if($code -match '\b(FCB|FDB|SVORG|SVECT|SVEND|SVNEW)\b\s*(.*)$'){
            $op=$matches[1];$args=$matches[2].Trim()
            if($op -eq 'SVNEW'){$stream.Add(255);continue}
            if($op -eq 'SVEND'){$stream.Add(254);continue}
            if($op -eq 'FDB'){$stream.Add([pscustomobject]@{ref=$args});continue}
            if(!$args){continue}
            foreach($arg in $args.Split(',')){
                $arg=$arg.Trim()
                $v=if($special.ContainsKey($arg)){$special[$arg]}elseif($arg.StartsWith('%')){[Convert]::ToInt32($arg.Substring(1),2)}else{[int]::Parse($arg)}
                $stream.Add($v)
            }
        }
    }
}
$shapes=@('LPASAG','LDOOR','LSDOOR','LWALL','FPASAG','FDOOR','FSDOOR','FWALL','RPASAG','RDOOR','RSDOOR','RWALL','CELINE','HOLEUP','HOLEDN','FLUP','FLDN','SPIDER','VIPER','SGINT1','BLOB','KNIGT1','SGINT2','SCORP','KNIGT2','WRAITH','BALROG','WIZ0','WIZ1','WIZ2','LPEEK','RPEEK','FFLASK','FRING','FSCROL','FSHIEL','FSWORD','FTORCH')
$segments=@()
foreach($shape in $shapes){
    $pc=$labels[$shape];$previous=$null;$stack=[Collections.Generic.Stack[int]]::new();$lines=@()
    for($guard=0;$guard -lt 1000;$guard++){
        $y=$stream[$pc];$pc++
        if($y -eq 254){break}
        if($y -eq 255){$previous=$null;continue}
        if($y -eq 253 -or $y -eq 251){if($y -eq 251){$stack.Push($pc+1)};$pc=$labels[$stream[$pc].ref];$previous=$null;continue}
        if($y -eq 250){$pc=$stack.Pop();$previous=$null;continue}
        if($y -ge 250){throw "Unsupported vector control $y in $shape"}
        $x=$stream[$pc];$pc++
        $point=@([int]$x,[int]$y)
        if($null -ne $previous){$lines+=,(@($previous)+$point)}
        $previous=$point
    }
    $segments+=,[pscustomobject]@{name=$shape;lines=$lines}
}
$scale=@(200,128,80,50,31,20,12,8,4,2)
$out=[Text.StringBuilder]::new('; Generated original VARC/VERT geometry, NORSCL and VECTOR fixed-point records.'+"`n")
# VFTTAB lists: current level's UP group, then next group's DOWN features.
$groups=@(@(),@(@(1,0,23),@(0,15,4),@(0,20,17),@(1,28,30)),@(@(1,2,3),@(0,3,31),@(0,19,20),@(0,31,0)),@(),@(@(0,0,31),@(0,5,0),@(0,22,28),@(0,31,16)),@())
[void]$out.AppendLine('world_vertical_tables:')
for($level=0;$level -lt 5;$level++){[void]$out.AppendLine(" .word world_vertical_$level")}
for($level=0;$level -lt 5;$level++){
    [void]$out.AppendLine("world_vertical_$level"+':')
    foreach($entry in $groups[$level]){if($entry.Count -eq 3){[void]$out.AppendLine(' .byte '+($entry -join ','))}}
    foreach($entry in $groups[$level+1]){if($entry.Count -eq 3){[void]$out.AppendLine(' .byte '+($entry[0]+2)+','+$entry[1]+','+$entry[2])}}
    [void]$out.AppendLine(' .byte 255')
}
[IO.File]::WriteAllText((Join-Path $root 'src\world_assets.inc'),$out.ToString())
$manifest=[pscustomobject]@{scales=$scale;shapes=$segments}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $root 'tests\world-geometry.json') -Encoding UTF8
Write-Host ('Imported '+$shapes.Count+' original shapes at 10 original distance scales.')
# Compact original endpoints allow exact alternate scales without duplicating
# every fixed-point record in the standalone PRG.
$raw=[Text.StringBuilder]::new("; Original raw vector endpoints for HLFSCL/BAKSCL.`n.segment ""RODATA""`nmotion_raw_tables:`n")
for($i=0;$i -lt $segments.Count;$i++){[void]$raw.AppendLine(" .word motion_raw_$i")}
for($i=0;$i -lt $segments.Count;$i++){
 [void]$raw.AppendLine("motion_raw_${i}: .byte "+$segments[$i].lines.Count)
 foreach($line in $segments[$i].lines){[void]$raw.AppendLine(' .byte '+($line -join ','))}
}
[void]$raw.AppendLine('motion_normal_scales: .byte 200,128,80,50,31,20,12,8,4,2
 motion_half_scales: .byte 255,156,100,65,40,26,16,10,6,3,1')
$motion=$raw.ToString()
$split=$motion.IndexOf('motion_raw_0:')
$data=$motion.Substring($split)
[IO.File]::WriteAllText((Join-Path $root 'src\motion_data.inc'),$data)
$working=[regex]::Replace($data,'\.byte ([0-9,]+)',{param($m) '.res '+$m.Groups[1].Value.Split(',').Count})
[IO.File]::WriteAllText((Join-Path $root 'src\motion_working.inc'),$working)
[IO.File]::WriteAllText((Join-Path $root 'src\motion_assets.inc'),$motion.Substring(0,$split)+".ifdef TEST_NO_AUDIO`n.include `"motion_data.inc`"`n.endif`n")
# Creature definitions and population matrix are imported from their ROM tables.
$definitions=Get-Content -LiteralPath (Join-Path $root 'reference\original\DTABAS.ASM') -Raw
$entries=[regex]::Matches($definitions,'(?m)^\s*\\1\s+(SPIDER|VIPER|SGINT1|BLOB|KNIGT1|SGINT2|SCORP|KNIGT2|WRAITH|BALROG|WIZ0|WIZ1),([0-9,]+)')
if($entries.Count -ne 12){throw 'Expected 12 original creature definitions'}
$cre=[Text.StringBuilder]::new("; Original CDBTAB, power words little endian for 65C02.`ncre_definitions:`n")
foreach($entry in $entries){$v=@($entry.Groups[2].Value.Split(',')|ForEach-Object {[int]$_});$bytes=@(($v[6] -band 255),($v[6] -shr 8))+$v[2..5]+$v[0..1];[void]$cre.AppendLine(' .byte '+($bytes -join ','))}
$comdat=Get-Content -LiteralPath (Join-Path $root 'reference\original\COMDAT.ASM') -Raw
$matrix=[regex]::Match($comdat,'(?ms)^CMTTAB\s+FCB(.*?)^CMTEND').Groups[1].Value
$matrix='FCB'+$matrix
$rows=[regex]::Matches($matrix,'FCB\s+([0-9,]+)')
if($rows.Count -ne 5){throw 'Expected 5 source population rows'}
[void]$cre.AppendLine('cre_matrix:')
foreach($row in $rows){[void]$cre.AppendLine(' .byte '+$row.Groups[1].Value)}
[IO.File]::WriteAllText((Join-Path $root 'src\creature_assets.inc'),$cre.ToString())
