using System;
public static class SaveReference {
 public const int Size=2745,Objects=31,Creatures=1039,Health=2615;
 public static int Word(byte[] a,int p){return a[p]+256*a[p+1];}
 public static void Put(byte[] a,int p,int v){a[p]=(byte)v;a[p+1]=(byte)(v>>8);}
 public static ushort Crc(byte[] a){int c=65535;for(int i=0;i<a.Length;i++){int v=(i==14||i==15)?0:a[i];c^=v<<8;for(int j=0;j<8;j++)c=((c<<1)^((c&32768)!=0?0x1021:0))&65535;}return (ushort)c;}
 public static void Seal(byte[] a){Put(a,14,Crc(a));}
 public static byte[] Rebase(byte[] a,int target){byte[] b=(byte[])a.Clone();int delta=target-Word(b,8);for(int i=0;i<4;i++)Shift(b,16+2*i,delta);for(int i=0;i<72;i++)Shift(b,Objects+14*i,delta);for(int i=0;i<32;i++)Shift(b,Creatures+17*i+8,delta);Put(b,8,target);Seal(b);return b;}
 static void Shift(byte[] b,int p,int delta){int v=Word(b,p);if(v!=0)Put(b,p,(v+delta)&65535);}
}
