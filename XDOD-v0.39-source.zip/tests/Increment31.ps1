$body=$worldSetup+@'
 stz demo_head
 stz demo_tail
 stz demo_luk_delay
 ldx #31
@init:
 txa
 sta demo_order,x
 dex
 bpl @init
 lda #33
 sta demo_order+32
 lda #1
 sta cre_delay
 sta cre_delay+1
 jsr demo_tick
 lda cre_delay
 sta $9a00
 lda cre_delay+1
 sta $9a01
 lda demo_tail
 sta $9a02
 lda #0
 jsr demo_reschedule
 lda #1
 sta cre_delay
 jsr demo_tick
 lda demo_queue+1
 sta $9a03
 lda cre_delay
 sta $9a04
'@
$r=Invoke-Machine 'cre-source-timer-scan' $body
Check 'Original QUESCN ends at first expiration' (Equal-Bytes $r[0x9a00..0x9a04] ([byte[]]@(0,1,1,1,1))) 'later timers miss this tick; rescheduling appends the task, so CCB 1 expires before CCB 0 next time'
$body=$worldSetup+@'
 stz demo_head
 stz demo_tail
 ldx #31
@init:
 txa
 sta demo_order+1,x
 dex
 bpl @init
 lda #33
 sta demo_order
 lda #1
 sta demo_luk_delay
 sta cre_delay
 jsr demo_tick
 lda demo_queue
 sta $9a00
 lda cre_delay
 sta $9a01
'@
$r=Invoke-Machine 'cre-source-luk-timer' $body
Check 'LUKNEW shares the original tenth queue' (Equal-Bytes $r[0x9a00..0x9a01] ([byte[]]@(33,1))) 'an expired redraw task stops the scan before the following creature timer'
$r=Invoke-Machine 'color3-rgb-phase' ($worldSetup+" lda #3`n sta artifact_mode`n lda #`$10`n jsr artifact_pair`n sta `$9a00`n lda #1`n jsr artifact_pair`n sta `$9a01`n")
Check 'CoCo3 RGB phase is blue even / gold odd' (Equal-Bytes $r[0x9a00..0x9a01] ([byte[]]@(0x70,0x03))) 'global pair decoder swaps hues while preserving original one-pixel positions'
$r=Invoke-Combat 'crisp-inventory-rgb' ($litSetup+(Command-Assembly 'E')+(Command-Assembly 'COLOR 3')) -Video
Export-MachineImage $r (Join-Path $results 'color3-inventory-v031.png')
$body=$armed+$spider+"`n"+@'
 lda hand_ptr
 sta hand_ptr+2
 lda hand_ptr+1
 sta hand_ptr+3
 stz hand_ptr
 stz hand_ptr+1
 jsr console_init
 jsr console_prompt
 lda #1
 sta demo_active
 sta demo_stage
 sta demo_turn
 stz demo_cursor
 stz demo_abort
 stz demo_timer
 lda #9
 sta demo_index
 jsr demo_poll
'@
$r=Invoke-Combat 'intro-demo-hit-spacing' $body
$line=[Text.Encoding]::ASCII.GetString([byte[]]$r[($combatLabels.console_text+32)..($combatLabels.console_text+63)])
Check 'Demo hit leaves two spaces after RIGHT' ($line.StartsWith('.ATTACK RIGHT  !!!')) 'PLAY40 final token space plus HMAN30 cursor erase; tested through the actual demo parser and landed attack'
$r=Invoke-Combat 'intro-death-timeout-wrap' ($worldSetup+" lda #57`n sta game_second`n jsr game_death_scene`n lda intro_death_deadline`n sta `$9a00`n")
Check 'Defeat attract deadline wraps at sixty seconds' ($r[0x9a00] -eq 5) '57 + 8 seconds wraps to 5; measured after the full death taunt, not at the beginning of its fade'
$body=@'
 jmp start
boot_resume:
 cli
 jsr game_death_scene
 jsr $ffde
 sta $0400
 stx $0401
 lda #$4c
 sta intro_show
 lda #<returned_to_intro
 sta intro_show+1
 lda #>returned_to_intro
 sta intro_show+2
@wait:
 jsr demo_poll
 bra @wait
returned_to_intro:
 jsr $ffde
 sec
 sbc $0400
 sta $0402
 txa
 sbc $0401
 sta $0403
 sei
 jmp $ffff
'@
$r=Invoke-Machine 'audio-death-attract-timeout' $body -Boot -Rendered
$elapsed=$r[0x402]+256*$r[0x403]
Check 'Defeat returns to intro without a key' ($elapsed -ge 420 -and $elapsed -le 481) "fresh taunt starts an eight-second deadline (whole-second resolution); actual r49 clock returned after $elapsed jiffies, then enters intro_show"

foreach($mode in 0..3){
 $expected=@(0,1,5,3)[$mode]
 $alternate=if($mode){$expected+1}else{0}
 $body=$worldSetup+" stz artifact_mode`n"+(Command-Assembly "COLOR $mode")+" lda artifact_mode`n sta `$9a00`n"+(Command-Assembly "COLOR $mode")+" lda artifact_mode`n sta `$9a01`n"+(Command-Assembly "COLOR $mode")+" lda artifact_mode`n sta `$9a02`n"
 $r=Invoke-Combat "color-mode-$mode-repeat" $body
 Check "COLOR $mode selects and reverses its own phase" (Equal-Bytes $r[0x9a00..0x9a02] ([byte[]]@($expected,$alternate,$expected))) 'all modes use the same global decoder for text, creatures, walls and scrolls; monochrome has no chroma phase'
}
$r=Invoke-Combat 'color-blank-monochrome' ($worldSetup+" lda #5`n sta artifact_mode`n"+(Command-Assembly 'COLOR'))
Check 'Bare COLOR selects monochrome' ($r[$combatLabels.artifact_mode] -eq 0) 'blank argument is equivalent to COLOR 0'
$mono=Invoke-Combat 'color2-monochrome-reference' ($litSetup+(Command-Assembly 'COLOR 0')) -Video
$crisp2=Invoke-Combat 'color2-crisp-reference' ($litSetup+(Command-Assembly 'COLOR 2')) -Video
$same=$true
foreach($y in 24..175){foreach($x in 32..287){$p=40960+160*$y+[int][Math]::Floor($x/2);$shift=if($x%2){0}else{4};if((($mono[$p] -shr $shift) -band 15) -ne [int]((($crisp2[$p] -shr $shift) -band 15) -ne 0)){$same=$false}}}
Check 'Crisp red/blue preserves every source pixel' $same 'COLOR 2 keeps monochrome pixel occupancy, unlike the intentionally expanded RF chroma pairs'
Export-MachineImage $crisp2 (Join-Path $results 'color2-dungeon-v031.png')
$r=Invoke-Combat 'release-no-level-command' ($worldSetup+(Command-Assembly 'LEVEL 5'))
Check 'Release rejects debug LEVEL command' ($r[$combatLabels.maze_level] -eq 0 -and $r[$combatLabels.command_result] -eq 1) 'normal C D / C U remain the supported level transitions'
$r=Invoke-Machine 'audio-release-original-starting-items' " jmp start`nboot_resume:`n cli`n jsr intro_exit`n sei`n" -Boot -Rendered
$combatLabels=Save-TestSymbols 'audio-release-original-starting-items'
$objects=$combatLabels.objects
Check 'Original two starting backpack objects' (($r[$combatLabels.bag_ptr]+256*$r[$combatLabels.bag_ptr+1]) -eq $objects -and ($r[$objects]+256*$r[$objects+1]) -eq ($objects+14) -and ($r[$objects+14]+256*$r[$objects+15]) -eq 0) 'fresh-game path retains sword -> torch -> null; no injected SEER SCROLL, while normal dungeon loot still exists'

$numbered=$producer.Replace('"ZSAVE"','"ZSAVE 54321 F"')
$r=Invoke-Machine 'audio-numbered-save' ($numbered+"`n"+$commandRoutine) -Boot -Rendered
$numberedFile=Join-Path $results 'audio-numbered-save/XDOD-54321.SAV'
$numberedBytes=[IO.File]::ReadAllBytes($numberedFile)
Check 'Numbered ZSAVE F writes requested slot without tape delay' ($r[0x401] -eq 0 -and $r[0x404] -lt 120 -and [SaveReference]::Word($numberedBytes,[SaveReference]::Health) -eq 1903) 'real HostFS save and overwrite of XDOD-54321.SAV'
$folder=Join-Path $results 'audio-numbered-load'
New-Item -ItemType Directory -Force -Path $folder|Out-Null
[IO.File]::WriteAllBytes((Join-Path $folder 'XDOD-54321.SAV'),$numberedBytes)
$r=Invoke-Machine 'audio-numbered-load' ($parser.Replace('"ZLOAD"','"ZLOAD 54321 F"')+"`n"+$commandRoutine) -Boot -Rendered
Check 'Numbered ZLOAD F restores requested slot without tape delay' ($r[0x400] -eq 0 -and $r[0x404] -lt 120) 'loads the numeric filename in a fresh emulator process'
$r=Invoke-Machine 'audio-default-fast-save' ($producer.Replace('"ZSAVE"','"ZSAVE F"')+"`n"+$commandRoutine) -Boot -Rendered
Check 'ZSAVE F uses the default filename without tape delay' ($r[0x401] -eq 0 -and $r[0x404] -lt 120 -and (Test-Path (Join-Path $results 'audio-default-fast-save/XDOD.SAV'))) 'F alone is a modifier, not a slot'
$r=Invoke-Machine 'audio-eight-digit-save' ($producer.Replace('"ZSAVE"','"ZSAVE 00123456"')+"`n"+$commandRoutine) -Boot -Rendered
Check 'Eight-digit slot preserves leading zeroes' ($r[0x401] -eq 0 -and (Test-Path (Join-Path $results 'audio-eight-digit-save/XDOD-00123456.SAV'))) 'full eight-character numeric slot round trips into the disk filename'
foreach($argument in @('123456789','12X','1 2','-1','F 5','5 F EXTRA','5 FF')){
 $r=Invoke-Combat ('invalid-slot-'+$argument.Replace(' ','_')) ($worldSetup+(Command-Assembly "ZSAVE $argument"))
 Check "Save rejects invalid arguments '$argument'" ($r[$combatLabels.command_result] -eq 1) 'syntax is optional numeric slot followed by optional F'
}
