# Additional source-model fixtures for original creature population and geometry.
$creMatrix=@(@(9,9,4,2,0,0,0,0,0,0,0,0),@(2,4,0,6,6,6,0,0,0,0,0,0),@(0,0,0,4,0,6,8,4,0,0,1,0),@(0,0,0,0,0,0,8,6,6,4,0,0),@(2,2,2,2,2,2,2,4,4,8,0,1))
$creDefs=@(@(32,0,0,255,128,255,23,11),@(56,0,0,255,80,128,15,7),@(200,0,0,255,52,192,29,23),@(48,1,0,255,96,167,31,31),@(248,1,0,128,96,60,13,7),@(192,2,0,128,128,48,17,13),@(144,1,255,128,255,128,5,4),@(32,3,0,64,255,8,13,7),@(32,3,192,16,192,8,3,3),@(232,3,255,5,255,3,4,3),@(232,3,255,6,255,0,13,7),@(64,31,255,6,255,0,13,7))
foreach($level in 0..4){
 $body=$worldSetup+" lda #$level`n sta maze_level`n jsr maze_generate`n jsr rng_init_test`n jsr cre_spawn`n ldx #0`ncre_copy:`n lda creatures,x`n sta `$9a00,x`n lda creatures+256,x`n sta `$9b00,x`n inx`n bne cre_copy`n ldx #31`ncre_tail:`n lda creatures+512,x`n sta `$9c00,x`n dex`n bpl cre_tail`n"
 $born=Invoke-Machine "cre-spawn-$level" $body
 $random=[DaggorathReference]::new([byte[]]@(0x12,0x34,0x56));$occupied=[Collections.Generic.HashSet[int]]::new();$expected=New-Object byte[] 544;$slot=0
 for($type=11;$type -ge 0;$type--){for($n=0;$n -lt $creMatrix[$level][$type];$n++){
  do{$col=$random.Next() -band 31;$row=$random.Next() -band 31;$pos=$row*32+$col}while($fullMaps[$level][$pos] -eq 255 -or $occupied.Contains($pos) -or $pos -eq 0)
  [void]$occupied.Add($pos);[Array]::Copy([byte[]]$creDefs[$type],0,$expected,$slot*17,8);$expected[$slot*17+12]=255;$expected[$slot*17+13]=$type;$expected[$slot*17+15]=$row;$expected[$slot*17+16]=$col;$slot++
 }}
 Check "Original creature births L$($level+1)" (Equal-Bytes $born[0x9a00..0x9c1f] $expected) 'NEWLVX descending type order, CMTTAB counts, CDBTAB parameters, RNG column-before-row and occupied-cell rejection'
}
# Every forward creature/wizard list at near, middle and far distances.
foreach($type in 0..12){foreach($range in @(0,1,3,6,9)){
 $shape=17+$type;$level=$type%2;$inverse=if($level){255}else{0}
 $body=$worldSetup+" lda #$inverse`n sta world_inverse`n jsr world_clear`n lda #$shape`n sta world_shape`n lda #$range`n sta world_range`n lda #20`n sta world_light`n jsr world_draw_shape`n lda #152`n jsr world_publish`n"
 $actor=Invoke-Machine "cre-raster-$type-$range" $body -Video
 $expected=$worldModel.Actor($shape,$range,20,$level)
 Check "Creature $type range $range geometry" (Equal-Bytes ([WorldReference]::FromDump($actor,152)) $expected[0..4863]) 'original D3/D4 vector list, signed scaling, clipping, inverse polarity and endpoint convention'
 if($range -eq 1){Export-MachineImage $actor (Join-Path $results "creature-$type.png")}
}}
# Passage ray can cross door faces. Passive creatures pursue but never attack.
$corridor=$worldSetup+" lda #255`n ldx #0`ncre_fill:`n sta maze_map,x`n sta maze_map+256,x`n sta maze_map+512,x`n sta maze_map+768,x`n inx`n bne cre_fill`n lda #`$55`n ldx #6`ncre_open:`n sta maze_map+324,x`n dex`n bpl cre_open`n lda #10`n sta player_row`n sta player_col`n sta creatures+15`n lda #4`n sta creatures+16`n lda #255`n sta creatures+12`n jsr cre_first`n"
$chase=Invoke-Machine 'cre-door-chase' ($corridor+" jsr cre_move`n lda creatures+15`n sta `$9a00`n lda creatures+16`n sta `$9a01`n lda creatures+14`n sta `$9a02`n")
Check 'Creature sees through door faces' (Equal-Bytes $chase[0x9a00..0x9a02] ([byte[]]@(10,5,1))) 'same-row LOS uses original STEPOK traversability; creature advances east through regular doors'
$occupied=Invoke-Machine 'cre-occupied-destination' ($corridor+" lda #255`n sta creatures+17+12`n lda #10`n sta creatures+17+15`n lda #5`n sta creatures+17+16`n jsr cre_move`n lda creatures+16`n sta `$9a00`n")
Check 'Creature occupancy blocks movement' ($occupied[0x9a00] -eq 4) 'CWALK refuses another live CCB in its destination'
foreach($type in @(0,6,10,11)){
 $pickup=$worldSetup+(Command-Assembly 'P L SW')+(Command-Assembly 'D L')+" lda #255`n sta creatures+12`n lda #$type`n sta creatures+13`n lda player_row`n sta creatures+15`n lda player_col`n sta creatures+16`n jsr cre_first`n jsr cre_move`n lda objects+OC_OWN`n sta `$9a00`n lda world_damage`n sta `$9a01`n"
 $picked=Invoke-Machine "cre-pickup-$type" $pickup
 $owner=if($type -eq 0){255}else{0}
 Check "Creature $type pickup/passive rule" ($picked[0x9a00] -eq $owner -and $picked[0x9a01] -eq 0) 'ordinary creature collects dropped items first; scorpion and both wizards do not; same-room contact causes no combat damage'
}
foreach($variant in 0..2){
 $wizard=Invoke-Machine "intro-wizard-$variant" ($worldSetup+" lda #$variant`n sta intro_variant`n jsr intro_show_variant`n") -Video
 $expected=$worldModel.Actor((27+$variant),1,20,0)
 Check "Wizard intro variant $variant" (Equal-Bytes ([WorldReference]::FromDump($wizard,152)) $expected[0..4863]) 'original WIZ0/WIZ1/WIZ2 geometry, range-one scale, fade sequence reaches full solid wizard'
 Export-MachineImage $wizard (Join-Path $results "wizard-intro-$variant.png")
}
# Stable spatial pair decoding, both startup phases, and an exact BW toggle.
$colorViews=@{}
foreach($mode in @('BW','RED','BLUE')){
 $command=@{BW='COLOR 0';RED='COLOR 1';BLUE='COLOR 1'}[$mode]
 $phase=if($mode -eq 'BLUE'){" lda #2`n sta artifact_mode`n jsr artifact_build`n jsr inventory_redraw`n"}else{Command-Assembly $command}
 $view=Invoke-Machine "color-$mode" ($litSetup+" stz artifact_mode`n"+$phase) -Video
 $colorViews[$mode]=$view;Export-MachineImage $view (Join-Path $results "artifact-$mode.png")
}
$colorOK=$true;$swapped=$true;$colorCount=0
for($y=24;$y -lt 176;$y++){for($x=16;$x -lt 144;$x++){
 $p=40960+$y*160+$x;$mono=$colorViews.BW[$p];$red=if($mono -eq 16){34}elseif($mono -eq 1){102}else{$mono};$blue=if($mono -eq 16){102}elseif($mono -eq 1){34}else{$mono}
 if($colorViews.RED[$p] -ne $red){$colorOK=$false};if($colorViews.BLUE[$p] -ne $blue){$swapped=$false};if($red -gt 17){$colorCount++}
}}
Check 'Stable red artifact phase' ($colorOK -and $colorCount -gt 0) 'isolated even/odd bit pairs become two-pixel chroma; black/white runs remain neutral; no ghosting filter'
Check 'Opposite blue artifact phase' $swapped 'phase choice swaps red and blue without changing the logical scene'
$returnColor=Invoke-Machine 'color-return' ($litSetup+(Command-Assembly 'COLOR 1')+(Command-Assembly 'T L')+(Command-Assembly 'T R')) -Video
$stable=$true;for($y=24;$y -lt 176;$y++){for($x=16;$x -lt 144;$x++){if($returnColor[40960+$y*160+$x] -ne $colorViews.RED[40960+$y*160+$x]){$stable=$false}}}
Check 'Artifact colors return after turning' $stable 'same scene restores identical colored pixels; clock and gameplay RNG do not control chroma phase'

# Production intro/startup followed by the actual IRQ-driven tenth queue.
$liveActors=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 ldx #0
cre_live_copy_before:
 lda creatures,x
 sta $9a00,x
 lda creatures+256,x
 sta $9b00,x
 inx
 bne cre_live_copy_before
 ldx #31
cre_live_tail_before:
 lda creatures+512,x
 sta $9c00,x
 dex
 bpl cre_live_tail_before
 jsr $ffde
 sta cre_live_start
cre_live_loop:
 jsr health_task
 jsr health_poll
 jsr cre_poll
 jsr $ffde
 sec
 sbc cre_live_start
 cmp #192
 bcc cre_live_loop
 sei
 ldx #0
cre_live_copy_after:
 lda creatures,x
 sta $9c20,x
 lda creatures+256,x
 sta $9d20,x
 inx
 bne cre_live_copy_after
 ldx #31
cre_live_tail_after:
 lda creatures+512,x
 sta $9e20,x
 dex
 bpl cre_live_tail_after
 lda world_damage
 sta $9e40
 lda display_mode
 sta $9e41
 jmp $ffff
cre_live_start: .byte 0
'@
$live=Invoke-Machine 'cre-live-startup' $liveActors -Boot -Rendered -Video
$before=$live[0x9a00..0x9c1f];$after=$live[0x9c20..0x9e3f];$changed=0;$valid=$true;$positions=[Collections.Generic.HashSet[int]]::new();$count=0
for($i=0;$i -lt 32;$i++){if($after[$i*17+12]){$count++;$r=$after[$i*17+15];$c=$after[$i*17+16];$p=$r*32+$c;if($fullMaps[0][$p] -eq 255 -or !$positions.Add($p)){$valid=$false};if($r -ne $before[$i*17+15] -or $c -ne $before[$i*17+16]){$changed++}}}
Check 'Live startup and creature scheduling' ($valid -and $count -eq 24 -and $changed -gt 0 -and $live[0x9e40] -eq 0 -and $live[0x9e41] -eq 0) 'actual intro/startup spawns 24 level-one creatures; real IRQ tenths move them onto unique valid cells without combat damage'

# Repeat MOVE into a real neighboring wall through the live input/Enter path.
$blockedPos=-1
for($p=32;$p -lt 1024;$p++){if($fullMaps[0][$p] -ne 255 -and $fullMaps[0][$p-32] -eq 255){$blockedPos=$p;break}}
$bumpRow=[int][Math]::Floor($blockedPos/32);$bumpCol=$blockedPos%32
$bumpLive=" jmp start`nboot_resume:`n lda bump_initialized`n bne bump_loop`n inc bump_initialized`n cli`n"+(Command-Assembly 'P R T')+(Command-Assembly 'U R')+" lda #$bumpRow`n sta player_row`n lda #$bumpCol`n sta player_col`n stz player_direction`nbump_loop:`n lda health_visual`n bne bump_done`n jsr health_task`n jsr health_poll`n jsr health_present`n lda bump_count`n cmp #180`n bcs bump_done`n ldx bump_phase`n lda bump_keys,x`n inc bump_phase`n ldx bump_phase`n cpx #2`n bcc bump_dispatch`n stz bump_phase`n inc bump_count`nbump_dispatch:`n jmp input_received`nbump_done:`n sei`n lda health_visual`n sta `$9a00`n lda world_damage`n sta `$9a01`n lda bump_count`n sta `$9a02`n jmp `$ffff`nbump_initialized: .byte 0`nbump_phase: .byte 0`nbump_count: .byte 0`nbump_keys: .byte 'M',13`n"
$rapid=Invoke-Machine 'running-wall-faint' $bumpLive -Boot -Rendered
Check 'Rapid wall bumps reach fainting in live play' ($rapid[0x9a00] -eq 1 -and $rapid[0x9a02] -lt 180) "real 60Hz recovery, original carried weight and parser path; faint observed after $($rapid[0x9a02]) bumps without altering HUPDAT thresholds"
# Independent MOVTAB preference oracle, including the sign/25% branches.
$wanderBody=[Text.StringBuilder]::new($worldSetup+" stz maze_level`n jsr maze_generate`n lda #255`n sta creatures+12`n lda #6`n sta creatures+13`n jsr cre_first`n")
$wanderExpected=[Collections.Generic.List[byte]]::new();$offset=0x9a00
$openCells=@(0..1023|Where-Object {$fullMaps[0][$_] -ne 255})
for($case=0;$case -lt 64;$case++){
 $p=$openCells[$case*3];$r=[int][Math]::Floor($p/32);$c=$p%32;$d=$case%4;$pr=($r+7)%32;$pc=($c+9)%32;$seed=[byte[]]@(0x12,0x34,$case)
 [void]$wanderBody.AppendLine(" lda #$r`n sta creatures+15`n lda #$c`n sta creatures+16`n lda #$d`n sta creatures+14`n lda #$pr`n sta player_row`n lda #$pc`n sta player_col`n lda #18`n sta rng_seed`n lda #52`n sta rng_seed+1`n lda #$case`n sta rng_seed+2`n jsr cre_move")
 $random=[DaggorathReference]::new($seed);$v=$random.Next();$tab=@(0,3,1,0,1,3,0);$start=if($v -band 128){0}else{3};if(($v -band 3) -eq 0){$start++};$preferences=@($tab[$start],$tab[$start+1],$tab[$start+2],2)
 foreach($relative in $preferences){$direction=($d+$relative)%4;$nr=$r+@(-1,0,1,0)[$direction];$nc=$c+@(0,1,0,-1)[$direction];if($nr -ge 0 -and $nr -lt 32 -and $nc -ge 0 -and $nc -lt 32 -and $fullMaps[0][$nr*32+$nc] -ne 255){$r=$nr;$c=$nc;$d=$direction;$dr=[Math]::Abs($r-$pr);$dc=[Math]::Abs($c-$pc);if($dr -le 8 -and $dc -le 8 -and [Math]::Min($dr,$dc) -le 2){[void]$random.Next()};break}}
 $wanderExpected.AddRange([byte[]](@($r,$c,$d)+$random.Seed))
 foreach($field in @('creatures+15','creatures+16','creatures+14','rng_seed','rng_seed+1','rng_seed+2')){[void]$wanderBody.AppendLine(" lda $field");[void]$wanderBody.AppendLine((' sta ${0:X4}' -f $offset));$offset++}
}
$wander=Invoke-Machine 'cre-wander-oracle' $wanderBody.ToString()
Check 'Original random wandering preferences' (Equal-Bytes $wander[0x9a00..($offset-1)] $wanderExpected.ToArray()) '64 positions/seeds cover both MOVTAB orders, 25% direction-change preference, fallback steps and sound-choice RNG consumption'
foreach($seconds in @(0,1,13,59)){
 $spin=Invoke-Machine "cre-clock-spin-$seconds" ($worldSetup+" jsr rng_init_test`n lda #$seconds`n sta game_second`n jsr cre_spin_seed`n lda rng_seed`n sta `$9a00`n lda rng_seed+1`n sta `$9a01`n lda rng_seed+2`n sta `$9a02`n")
 $random=[DaggorathReference]::new([byte[]]@(18,52,86));$count=if($seconds){$seconds}else{256};for($i=0;$i -lt $count;$i++){[void]$random.Next()}
 Check "Original DGEN90 spin $seconds" (Equal-Bytes $spin[0x9a00..0x9a02] $random.Seed) 'post-maze SECOND-based RNG spin affects creature placement, never the predetermined maze'
}
$secretChase=Invoke-Machine 'cre-secret-door-chase' ($corridor.Replace('#$55','#$aa')+" jsr cre_move`n lda creatures+16`n sta `$9a00`n")
Check 'Creature sees through secret doors' ($secretChase[0x9a00] -eq 5) 'line of sight and movement use occupiable cells, including magic door faces'
foreach($shape in @(30,31)){
 $peek=Invoke-Machine "cre-peek-$shape" ($worldSetup+" stz world_inverse`n jsr world_clear`n lda #$shape`n sta world_shape`n lda #1`n sta world_range`n lda #13`n sta world_light`n jsr world_draw_shape`n lda #152`n jsr world_publish`n") -Video
 $expected=$worldModel.Actor($shape,1,13,0)
 Check "Original peek list $shape" (Equal-Bytes ([WorldReference]::FromDump($peek,152)) $expected[0..4863]) 'source LPEEK/RPEEK vector lists use the shared original scaling and fade engine'
}
# Actual VIEW30/CMRDRW integration, not just isolated actor vector rendering.
foreach($case in @(@(0,0),@(6,0),@(6,13))){
 $type=$case[0];$magic=$case[1];$magical=if($type -eq 6){255}else{0}
 $scene=$worldSetup+" lda #255`n ldx #0`ncre_scene_fill:`n sta maze_map,x`n sta maze_map+256,x`n sta maze_map+512,x`n sta maze_map+768,x`n inx`n bne cre_scene_fill`n lda #3`n sta maze_map+523`n lda #255`n sta creatures+12`n lda #$type`n sta creatures+13`n lda #$magical`n sta creatures+2`n lda #16`n sta creatures+15`n lda #11`n sta creatures+16`n lda #7`n sta regular_light`n lda #$magic`n sta magic_light`n jsr world_viewer`n"
 $actual=Invoke-Machine "cre-world-light-$type-$magic" $scene -Video
 $map=New-Object byte[] 1024;for($i=0;$i -lt 1024;$i++){$map[$i]=255};$map[523]=3
 $expected=$worldModel.View($map,16,11,0,7,$magic,0);$light=if($magical){$magic}else{7};$actor=$worldModel.Actor((17+$type),0,$light,0)
 for($i=0;$i -lt 4864;$i++){$expected[$i]=$expected[$i] -bor $actor[$i]}
 Check "World creature lighting $type/$magic" (Equal-Bytes ([WorldReference]::FromDump($actual,152)) $expected[0..4863]) 'VIEW30 selects the live sector CCB and CMRDRW chooses physical versus magical visibility before layering original vectors'
}
