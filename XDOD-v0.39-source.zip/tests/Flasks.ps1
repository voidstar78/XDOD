# Exercise USE through the parser, including an unrevealed flask and an empty one.
$cases=@(
 @{Name='THEWS';Type=5;Hand='L';Damage=31;PowerAfter=2000;DamageAfter=31},
 @{Name='HALE';Type=9;Hand='R';Damage=260;PowerAfter=1000;DamageAfter=0},
 @{Name='ABYE';Type=8;Hand='L';Damage=10;PowerAfter=1000;DamageAfter=806},
 @{Name='EMPTY';Type=23;Hand='R';Damage=31;PowerAfter=1000;DamageAfter=31}
)
foreach($case in $cases){
 $hand=if($case.Hand -eq 'L'){'hand_ptr'}else{'hand_ptr+2'}
 $setup=@"
 jsr setup_vera
 jsr inventory_init
 jsr world_init
 jsr maze_generate
 lda #<objects
 sta obj_ptr
 sta $hand
 lda #>objects
 sta obj_ptr+1
 sta ${hand}+1
 lda #$($case.Type)
 jsr inventory_fill
 ldy #OC_REVEAL
 lda #40
 sta (obj_ptr),y
 lda #<1000
 sta health_power
 lda #>1000
 sta health_power+1
 lda #<$($case.Damage)
 sta world_damage
 lda #>$($case.Damage)
 sta world_damage+1
"@
 $command=Command-Assembly "USE $($case.Hand)"
 $r=Invoke-Combat "use-flask-$($case.Name)" ($setup+"`n"+$command+$command)
 $expectedReveal=if($case.Type -eq 23){40}else{0}
 Check "USE $($case.Name) flask" (
  [SaveReference]::Word($r,$combatLabels.health_power) -eq $case.PowerAfter -and
  [SaveReference]::Word($r,$combatLabels.world_damage) -eq $case.DamageAfter -and
  [SaveReference]::Word($r,$combatLabels[$hand.Split('+')[0]]+$(if($case.Hand -eq 'L'){0}else{2})) -eq $combatLabels.objects -and
  $r[$combatLabels.objects+9] -eq 23 -and
  $r[$combatLabels.objects+11] -eq $expectedReveal
 ) 'original flask effect, preserved hand and no effect from drinking the empty flask again'
}
