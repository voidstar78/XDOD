# A spider entering the player's cell must be shown at range zero BEFORE input.
$contact=$armed+$spider+"`n"+@'
 lda #255
 ldx #0
@fill:
 sta maze_map,x
 sta maze_map+256,x
 sta maze_map+512,x
 sta maze_map+768,x
 inx
 bne @fill
 stz maze_map+330
 stz maze_map+362
 stz maze_map+394
 lda #10
 sta player_row
 sta player_col
 sta creatures+16
 lda #11
 sta creatures+15
 lda #2
 sta player_direction
 stz creatures+8
 stz creatures+9
 stz creatures+14
 jsr inventory_redraw
'@
$contact+="`n"
$far=Invoke-Combat 'cre-contact-before' $contact -Video
$move=@'
 lda #1
 sta cre_enabled
 sta cre_ready
 stz cre_due
 stz cre_delay
 stz cre_cursor
 jsr cre_poll
'@
$move+="`n"
$entered=Invoke-Combat 'cre-contact-immediate' ($contact+$move) -Video
$state=@($entered[$combatLabels.creatures+15],$entered[$combatLabels.creatures+16],$entered[$combatLabels.cre_delay],$entered[$combatLabels.cre_dirty],$entered[$combatLabels.cre_due])
$forced=Invoke-Combat 'cre-contact-forced-reference' ($contact+$move+" jsr inventory_redraw`n") -Video
$a=[WorldReference]::FromDump($entered,152);$b=[WorldReference]::FromDump($forced,152);$old=[WorldReference]::FromDump($far,152)
Check 'Contact publishes the range-zero creature before input' ((Equal-Bytes $state ([byte[]]@(10,10,11,0,0))) -and (Equal-Bytes $a $b) -and -not (Equal-Bytes $a $old)) 'cre_due starts at zero; actual framebuffer matches an immediate redraw, not the stale range-one spider'
$r=Invoke-Combat 'combat-no-range-one-hit' ($contact+" lda #1`n sta combat_enabled`n"+(Command-Assembly 'A L'))
Check 'Attack cannot hit a creature one cell away' ($r[$combatLabels.combat_hit] -eq 0 -and $r[$combatLabels.combat_killed] -eq 0 -and $r[$combatLabels.creatures+12] -eq 255) 'same-cell target lookup remains authoritative; no ranged sword attacks added'
$wall=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 lda #255
 ldx #0
@fill:
 sta maze_map,x
 sta maze_map+256,x
 sta maze_map+512,x
 sta maze_map+768,x
 inx
 bne @fill
 stz maze_map
 stz player_row
 stz player_col
 stz player_direction
'@
$wall+="`n"
$index=0
foreach($command in @('M','M B','M L','M R')){$wall+=(Command-Assembly $command)+" lda world_move_result`n sta `$040$index`n";$index++}
$wall+=" sei`n lda aud_type`n sta `$0404`n lda player_row`n sta `$0405`n lda player_col`n sta `$0406`n"
$r=Invoke-Machine 'audio-wall-impact-command' $wall -Boot -Rendered
$pcm=[DodSoundTrace]::DecodeGain(([DodSoundTrace]::Build(24)).Encode(),255)
Check 'Blocked movement in all directions plays source THUD' ((Equal-Bytes $r[0x400..0x406] ([byte[]]@(1,1,1,1,21,0,0))) -and (Equal-Bytes (Audio-CachedPcm $r 'audio-wall-impact-command' 21 $pcm.Length) $pcm)) 'actual M/M B/M L/M R parser paths reject travel and play every BOOMER sample at pitch $0080, one repetition'
$r=Invoke-Combat 'input-no-thud-on-open-move' ($contact+" lda #255`n sta aud_type`n"+(Command-Assembly 'M'))
Check 'Successful movement does not play wall impact' ($r[$combatLabels.world_move_result] -eq 0 -and $r[$combatLabels.aud_type] -eq 255 -and $r[$combatLabels.player_row] -eq 11) 'movement into an occupiable cell retains ordinary stepping behavior'
