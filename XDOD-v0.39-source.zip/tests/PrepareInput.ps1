# Inject three human-sized batches into the actual KERNAL keyboard buffer
# during the rendered PREPARE wait, then let the normal main loop consume them.
$body=@'
 jmp start
boot_resume:
 cli
 stz $0401
 lda #$4c
 sta health_poll
 lda #<prepare_keys
 sta health_poll+1
 lda #>prepare_keys
 sta health_poll+2
 jsr intro_exit
 lda input_write
 sta $0400
 lda #$20
 sta main_loop
 lda #<health_task
 sta main_loop+1
 lda #>health_task
 sta main_loop+2
 lda #<read_key
 sta player_input+1
 lda #>read_key
 sta player_input+2
 jmp main_loop
read_key:
 jsr game_getin
 cmp #0
 bne have_key
 sei
 jmp $ffff
have_key:
 rts
prepare_keys:
 lda game_preparing
 beq resume_poll
 lda game_second
 beq resume_poll
 cmp #4
 bcs resume_poll
 cmp $0401
 beq resume_poll
 sta $0401
 phx
 phy
 tax
 lda key_start-1,x
 tay
 lda key_length-1,x
 php
 sei
 ldx $00
 phx
 stz $00
 sta KEYCOUNT
 ldx #0
copy_key:
 lda keys,y
 sta KEYBUFFER,x
 iny
 inx
 cpx KEYCOUNT
 bcc copy_key
 plx
 stx $00
 plp
 ply
 plx
resume_poll:
 lda health_pending
 jmp health_poll+3
key_start: .byte 0,6,10
key_length: .byte 6,4,7
keys: .byte "P R T",13,"U R",13,"P L SW",13
'@
$body=$body.Replace('KEYBUFFER',('$'+('{0:x4}' -f $symbols.keyd))).Replace('KEYCOUNT',('$'+('{0:x4}' -f $symbols.ndx)))
$r=Invoke-Machine 'audio-prepare-three-commands' $body -Boot -Rendered
$s=Save-TestSymbols 'audio-prepare-three-commands'
Check 'PREPARE buffers the full opening command sequence' (
 $r[0x400] -eq 17 -and $r[0x401] -eq 3 -and $r[$s.input_read] -eq 17 -and
 [SaveReference]::Word($r,$s.hand_ptr) -eq $s.objects -and
 [SaveReference]::Word($r,$s.hand_ptr+2) -eq 0 -and
 [SaveReference]::Word($r,$s.active_torch) -eq ($s.objects+14)
) 'all three KERNAL input batches survive PREPARE and equip the sword and lit torch through the normal parser'
