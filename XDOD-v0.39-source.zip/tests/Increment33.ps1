# Original PINCAN, PATTK ring-riddle and HUMAN:PLAY10 regressions.
$held=@'
 jsr setup_vera
 jsr inventory_init
 jsr world_init
 lda #<objects
 sta obj_ptr
 sta hand_ptr
 lda #>objects
 sta obj_ptr+1
 sta hand_ptr+1
 lda #TYPE_RN01
 jsr inventory_fill
 jsr next_object
 lda obj_ptr
 sta hand_ptr+2
 lda obj_ptr+1
 sta hand_ptr+3
 lda #TYPE_RN01
 jsr inventory_fill
 stz bag_ptr
 stz bag_ptr+1
'@
$held+="`n"
foreach($word in @('ENER','ICE','ENERGY')){
 $r=Invoke-Combat "incant-full-word-$word" ($held+(Command-Assembly "I $word"))
 $expected=if($word -eq 'ENERGY'){19}else{1}
 Check "INCANT $word processes both held rings" ($r[$combatLabels.objects+9] -eq $expected -and $r[$combatLabels.objects+23] -eq $expected) 'PINCAN requires the complete matching adjective; abbreviated or wrong words leave rings unchanged'
 if($word -eq 'ENERGY'){
  Check 'INCANT clears both secret-word fields' ($r[$combatLabels.objects+7] -eq 0 -and $r[$combatLabels.objects+21] -eq 0) 'STATUS may change obj_ptr; the activating ring pointer is restored before clearing its field'
 }
}
foreach($pair in @(@(6,'ICE',20),@(12,'FIRE',21))){
 $r=Invoke-Combat "incant-$($pair[1])" ($held+" lda #<objects`n sta obj_ptr`n lda #>objects`n sta obj_ptr+1`n lda #$($pair[0])`n jsr inventory_fill`n"+(Command-Assembly "INCANT $($pair[1])"))
 Check "INCANT $($pair[1]) fills original attack parameters" ($r[$combatLabels.objects+9] -eq $pair[2] -and $r[$combatLabels.objects+7] -eq 0 -and $r[$combatLabels.objects+12] -eq 255 -and $r[$combatLabels.objects+13] -eq 255) 'RIME/ICE and VULCAN/FIRE transform using the original object tables'
}
$riddle=$worldSetup+@'
 lda #3
 sta object_count
 lda #<(objects+28)
 sta obj_ptr
 lda #>(objects+28)
 sta obj_ptr+1
 lda #TYPE_RN05
 jsr inventory_fill
 ldy #OC_OWN
 lda #0
 sta (obj_ptr),y
 lda #4
 sta maze_level
 ldy #OC_LEVEL
 sta (obj_ptr),y
 lda #11
 sta combat_special
 jsr combat_story
 jsr torch_light
'@
$riddle+="`n"
$r=Invoke-Combat 'incant-final-riddle' $riddle
$o=$combatLabels.objects
Check 'Final wizard removes every other allocated object' ($r[$combatLabels.object_count] -eq 1 -and $r[$o+9] -eq 0 -and (Equal-Bytes $r[($o+14)..($o+1007)] (New-Object byte[] 994))) 'XDOD starter-first allocation is remapped to the cartridge single-ring layout'
Check 'Riddle clears hands bag torch and fixes light' ((Equal-Bytes $r[$combatLabels.bag_ptr..($combatLabels.bag_ptr+7)] (New-Object byte[] 8)) -and $r[$combatLabels.regular_light] -eq 7 -and $r[$combatLabels.magic_light] -eq 19 -and $r[$combatLabels.cre_enabled] -eq 0 -and $r[$combatLabels.combat_special] -eq 12) 'PATTK supplies PRLITE=$07 and PMLITE=$13 without a PINE TORCH object'

$body=$riddle+@'
 stz $0400
 lda #<objects
 sta hand_ptr
 lda #>objects
 sta hand_ptr+1
 lda #$4c
 sta intro_show_variant
 lda #<win_probe
 sta intro_show_variant+1
 lda #>win_probe
 sta intro_show_variant+2
'@+"`n"+(Command-Assembly 'I FINAL')+@'
 jmp $ffff
win_probe:
 inc $0400
 rts
'@
$r=Invoke-Combat 'incant-final-wins' $body
Check 'INCANT FINAL selects star wizard ending' ($r[0x400] -eq 1 -and $r[$combatLabels.objects+9] -eq 18 -and $r[$combatLabels.intro_variant] -eq 2 -and $r[$combatLabels.intro_kind] -eq 3 -and $r[$combatLabels.combat_special] -eq 13 -and $r[$combatLabels.combat_enabled] -eq 0) 'PINCAN:WINNER uses WIZ2 and terminates gameplay'

# End-to-end imported late-game state, including ring-riddle disk roundtrip.
$slot28=Join-Path $root 'tests/fixtures/XDOD-28.SAV'
if(Test-Path $slot28){
 $folder=Join-Path $results 'audio-import28-final-victory'
 New-Item -ItemType Directory -Force $folder|Out-Null
 Copy-Item $slot28 (Join-Path $folder 'XDOD-28.SAV') -Force
 $body=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 lda #<load28
 ldy #>load28
 jsr test_command
 lda save_result
 sta $0400
 jsr cre_first
 ldx #32
find_wizard:
 ldy #13
 lda (cre_ptr),y
 cmp #11
 beq found_wizard
 jsr cre_next
 dex
 bne find_wizard
 jmp $ffff
found_wizard:
 ldy #15
 lda (cre_ptr),y
 sta player_row
 iny
 lda (cre_ptr),y
 sta player_col
 lda #<attack
 ldy #>attack
 jsr test_command
 jsr combat_story
 lda combat_special
 sta $0401
 lda #<save_riddle
 ldy #>save_riddle
 jsr test_command
 lda save_result
 sta $0402
 lda #<load_riddle
 ldy #>load_riddle
 jsr test_command
 lda save_result
 sta $0403
 lda #<get_ring
 ldy #>get_ring
 jsr test_command
 lda #<reveal_ring
 ldy #>reveal_ring
 jsr test_command
 lda #<incant_final
 ldy #>incant_final
 stz artifact_mode
 jsr artifact_build
 lda #<incant_final
 ldy #>incant_final
 jsr test_command
 sei
 jmp $ffff
load28: .byte "ZLOAD 28",0
attack: .byte "A L",0
save_riddle: .byte "ZSAVE 99",0
load_riddle: .byte "ZLOAD 99",0
get_ring: .byte "G L R",0
reveal_ring: .byte "R L",0
incant_final: .byte "I FINAL",0
'@
 $r=Invoke-Machine 'audio-import28-final-victory' ($body+"`n"+$commandRoutine) -Boot -Rendered -Video
 $s=Save-TestSymbols 'audio-import28-final-victory'
 Check 'Imported save 28 reaches victory through actual commands' ($r[0x400] -eq 0 -and $r[0x401] -eq 12 -and $r[0x402] -eq 0 -and $r[0x403] -eq 0 -and $r[$s.objects+9] -eq 18 -and $r[$s.intro_kind] -eq 3 -and $r[$s.display_mode] -eq 3) 'ZLOAD, one sword kill, ring-riddle ZSAVE/ZLOAD, GET/REVEAL and INCANT FINAL execute in the actual release with PCM/IRQ enabled'
 $video=[byte[]](@($r[0..40959])+@($r[(40960+524288)..($r.Length-1)]))
 Check 'Victory message leaves the first parser row blank' ((Text-Pixels-Equal $video 'BEHOLD! DESTINY AWAITS THE HAND' 4 192 0) -and (Text-Pixels-Equal $video '       OF A NEW WIZARD...' 4 200 0)) 'requested blank row, seven-space second-line indent, star wizard and empty status band'
 Export-MachineImage $video (Join-Path $results 'victory-v034.png')
 $motionText=Get-Content (Join-Path $root 'src/motion_data.inc') -Raw
 $expectedMotion=[byte[]]@([regex]::Matches($motionText,'\.byte ([0-9,]+)')|ForEach-Object {$_.Groups[1].Value.Split(',')|ForEach-Object {[byte]$_}})
 Check 'Packed runtime vectors restore losslessly' (Equal-Bytes $r[$s.motion_raw_0..($s.motion_raw_0+$expectedMotion.Length-1)] $expectedMotion) 'all original vector endpoints and scale bytes match the pre-pack source'
}

$body=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 jsr inventory_init
 jsr world_init
 stz maze_level
 jsr maze_generate
 lda #<sword
 ldy #>sword
 jsr test_command
 lda #<torch
 ldy #>torch
 jsr test_command
 lda #<use_torch
 ldy #>use_torch
 jsr test_command
 ldx #7
copy_serpent:
 lda cre_definitions+8,x
 sta creatures,x
 dex
 bpl copy_serpent
 lda #255
 sta creatures+12
 lda #1
 sta creatures+13
 sta cre_enabled
 sta combat_enabled
 sta audio_enabled
 lda player_row
 sta creatures+15
 lda player_col
 sta creatures+16
 lda #7
 sta cre_delay
 jsr rng_init_test
 stz input_len
 jsr console_init
 jsr console_prompt
 stz input_read
 lda #12
 sta input_write
 ldx #11
queue_keys:
 lda burst,x
 sta input_queue,x
 dex
 bpl queue_keys
 stz $0400
 lda #$20
 sta main_loop
 lda #<health_task
 sta main_loop+1
 lda #>health_task
 sta main_loop+2
 lda #<count_poll
 sta main_loop+10
 lda #>count_poll
 sta main_loop+11
 lda #<probe_key
 sta player_input+1
 lda #>probe_key
 sta player_input+2
 jmp main_loop
count_poll:
 inc $0400
 jmp cre_poll
probe_key:
 jsr game_getin
 cmp #0
 bne key_done
 sei
 lda input_read
 sta $0401
 lda creatures+12
 sta $0402
 lda world_damage
 sta $0403
 jmp $ffff
key_done:
 rts
sword: .byte "P L SW",0
torch: .byte "P R T",0
use_torch: .byte "U R",0
burst: .byte "A L",13,"A L",13,"A L",13
'@
$r=Invoke-Machine 'audio-live-three-serpent-attacks' ($body+"`n"+$commandRoutine) -Boot -Rendered
Check 'Live PLAYER drains three buffered attacks before yielding' (Equal-Bytes $r[0x400..0x403] ([byte[]]@(1,12,0,6))) 'actual input/console/parser, sword combat and PCM; one creature poll, twelve characters, dead serpent and only six exertion damage; attack odds and serpent delay remain original'


