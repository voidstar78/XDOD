# r49 integration checks: system RAM preservation and the actual GETIN routine.
$symPath=Join-Path (Split-Path $Emulator -Parent) 'kernal.sym'
if(!(Test-Path -LiteralPath $symPath)){throw 'Keyboard integration checks need matching r49 kernal.sym beside the emulator.'}
$symbols=@{}
Get-Content -LiteralPath $symPath | ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.(keyd|ndx)$'){$symbols[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
if(!$symbols.ContainsKey('keyd') -or !$symbols.ContainsKey('ndx')){throw 'Missing KERNAL keyboard-buffer symbols'}
$preserve=@'
 jsr setup_vera
 jsr inventory_init
 jsr world_init
 stz maze_level
 jsr maze_generate
 stz $00
 lda #$00
 sta obj_ptr
 sta name_ptr
 lda #$a0
 sta obj_ptr+1
 lda #$80
 sta name_ptr+1
 ldx #31
 ldy #0
test_copy_reserved:
 lda (obj_ptr),y
 sta (name_ptr),y
 iny
 bne test_copy_reserved
 inc obj_ptr+1
 inc name_ptr+1
 dex
 bne test_copy_reserved
 jsr world_clear
 jsr world_viewer
 jsr world_map
 lda $00
 sta $0402
 stz $0400
 stz $0401
 stz $00
 lda #$00
 sta obj_ptr
 sta name_ptr
 lda #$a0
 sta obj_ptr+1
 lda #$80
 sta name_ptr+1
 ldx #31
 ldy #0
test_compare_reserved:
 lda (obj_ptr),y
 cmp (name_ptr),y
 beq :+
 inc $0400
 bne :+
 inc $0401
: iny
 bne test_compare_reserved
 inc obj_ptr+1
 inc name_ptr+1
 dex
 bne test_compare_reserved
 lda $0400
 sta $9a00
 lda $0401
 sta $9a01
 lda $0402
 sta $9a02
'@
$preserved=Invoke-Machine 'kernel-bank-preservation' $preserve
Check 'Reserved RAM bank zero stays intact' ($preserved[0x9a00] -eq 0 -and $preserved[0x9a01] -eq 0) 'all 7936 bytes at bank 0 $A000-$BEFF unchanged after framebuffer clear, dungeon rendering and scroll map'
Check 'Framebuffer uses user RAM bank one' ($preserved[0x9a02] -eq 1) 'rendering selects bank 1; bank 0 remains owned by KERNAL/CMDR-DOS'
$queue=@'
 jsr setup_vera
 jsr inventory_init
 jsr world_init
 stz $00
 lda #'E'
'@
$queue+="`n sta `$$('{0:X4}' -f $symbols.keyd)`n lda #13`n sta `$$('{0:X4}' -f ($symbols.keyd+1))`n lda #2`n sta `$$('{0:X4}' -f $symbols.ndx)`n"
$queue+=@'
 jsr world_clear
 jsr GETIN
 sta $9a00
 jsr GETIN
 sta $9a01
'@
$read=Invoke-Machine 'real-getin-after-framebuffer' $queue
Check 'Real KERNAL GETIN survives rendering' ($read[0x9a00] -eq 69 -and $read[0x9a01] -eq 13) 'keys queued in the actual r49 keyboard buffer survive clear and are returned by unmodified GETIN'
