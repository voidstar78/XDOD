# Exercise stale keys before death AND a key queued by IRQ during its explosion.
$kernel=@{};Get-Content (Join-Path (Split-Path $Emulator -Parent) 'kernal.sym')|ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.(keyd|ndx)$'){$kernel[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
$death=@"
 jmp start
boot_resume:
 sei
 lda old_irq
 sta test_chain
 lda old_irq+1
 sta test_chain+1
 lda #<test_irq
 sta old_irq
 lda #>test_irq
 sta old_irq+1
 stz test_injected
 stz `$00
 lda #65
 sta $($kernel.keyd)
 lda #3
 sta $($kernel.ndx)
 lda #1
 sta `$00
 sta health_dead
 cli
 jsr game_death_scene
 jsr GETIN
 sta `$0400
 lda display_mode
 sta `$0401
 lda intro_kind
 sta `$0402
 sei
 stz `$00
 lda #90
 sta $($kernel.keyd)
 lda #1
 sta $($kernel.ndx)
 sta `$00
 jsr GETIN
 sta `$0403
 lda test_injected
 sta `$0404
 jmp `$ffff
test_irq:
 pha
 lda intro_kind
 cmp #1
 bne @done
 lda intro_fade
 bne @done
 lda AUDIO_RATE
 beq @done
 lda test_injected
 bne @done
 inc test_injected
 lda `$00
 pha
 stz `$00
 lda #65
 sta $($kernel.keyd)
 lda #1
 sta $($kernel.ndx)
 pla
 sta `$00
@done:
 pla
 jmp (test_chain)
test_chain: .word 0
test_injected: .byte 0
"@
$r=Invoke-Machine 'audio-death-keyboard-flush' $death -Boot -Rendered
Check 'Death discards queued attacks through the complete taunt' (Equal-Bytes $r[0x400..0x404] ([byte[]]@(0,3,1,90,1))) 'stale input and an IRQ-injected key during KABOOM are gone; a fresh key remains readable afterward'
$kill=" jmp start`nboot_resume:`n cli`n jsr cre_spawn`n jsr cre_first`n stz creatures+8`n stz creatures+9`n stz creatures+13`n stz combat_def`n stz combat_def+1`n jsr combat_kill`n sei`n lda combat_killed`n sta `$0400`n lda aud_type`n sta `$0401`n"
$r=Invoke-Machine 'audio-creature-defeated' $kill -Boot -Rendered
$pcm=[DodSoundTrace]::DecodeGain(([DodSoundTrace]::Build(23)).Encode(),255)
Check 'Creature defeat plays original BANG' ((Equal-Bytes $r[0x400..0x401] ([byte[]]@(1,20))) -and (Equal-Bytes (Audio-CachedPcm $r 'audio-creature-defeated' 20 $pcm.Length) $pcm)) 'real combat_kill path reaches A$EXP0; all BOOMER samples match pitch $0050, five repetitions'
