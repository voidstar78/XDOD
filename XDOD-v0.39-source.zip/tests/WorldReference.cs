// Independent host interpretation of VIEWER/VARC/VERT/VECTOR/MAPPER/PSTEP.
using System;
public sealed class WorldReference {
    readonly int[][][] shapes;
    readonly int[] scales;
    static readonly int[] dr={-1,0,1,0},dc={0,1,0,-1};
    // Original VFTTAB group order, including empty sentinel groups.
    static readonly int[][][] groups={new int[0][],new int[][]{new[]{1,0,23},new[]{0,15,4},new[]{0,20,17},new[]{1,28,30}},new int[][]{new[]{1,2,3},new[]{0,3,31},new[]{0,19,20},new[]{0,31,0}},new int[0][],new int[][]{new[]{0,0,31},new[]{0,5,0},new[]{0,22,28},new[]{0,31,16}},new int[0][]};
    public WorldReference(int[][][] sourceShapes,int[] sourceScales){shapes=sourceShapes;scales=sourceScales;}
    public static byte[] FromDump(byte[] dump,int height){
        var fb=new byte[height*32];
        for(int y=0;y<height;y++)for(int x=0;x<256;x++){
            int v=dump[40960+(y+24)*160+16+x/2];v=(x&1)==0?v>>4:v&15;
            if(v>1)throw new Exception("Unexpected non-monochrome framebuffer pixel");
            if(v==1)fb[y*32+x/8]|=(byte)(128>>(x&7));
        }
        return fb;
    }
    static void Put(byte[] fb,int x,int y,bool inverse){int p=y*32+x/8,bit=128>>(x&7);fb[p]=(byte)(inverse?fb[p]&~bit:fb[p]|bit);}
    void Shape(byte[] fb,int shape,int range,int light,bool inverse){
        int deficit=7+range-light;
        if(deficit>=7)return;
        int period=deficit<=0?1:(1<<(deficit-1))+1;
        foreach(int[] s in shapes[shape]){
            int x0=128+(int)Math.Floor((s[0]-128)*scales[range]/128.0),y0=76+(int)Math.Floor((s[1]-76)*scales[range]/128.0);
            int x1=128+(int)Math.Floor((s[2]-128)*scales[range]/128.0),y1=76+(int)Math.Floor((s[3]-76)*scales[range]/128.0);
            int n=Math.Max(Math.Abs(x1-x0),Math.Abs(y1-y0));if(n==0)continue;
            int dx=(x1-x0)*256/n,dy=(y1-y0)*256/n,xx=x0*256+128,yy=y0*256+128;
            for(int k=0;k<n;k++,xx+=dx,yy+=dy){
                if((k+1)%period!=0)continue;
                int x=xx>>8,y=yy>>8;
                if(x>=0&&x<256&&y>=0&&y<152)Put(fb,x,y,inverse);
            }
        }
    }
    public byte[] Actor(int shape,int range,int light,int level){
        var fb=new byte[6144];bool inverse=(level&1)!=0;
        if(inverse)for(int i=0;i<fb.Length;i++)fb[i]=255;
        Shape(fb,shape,range,light,inverse);return fb;
    }
    public byte[] View(byte[] map,int row,int col,int direction,int light,int magic,int level){
        var fb=new byte[6144];bool inverse=(level&1)!=0;
        if(inverse)for(int i=0;i<fb.Length;i++)fb[i]=255;
        for(int range=0;range<10;range++){
            int cell=map[row*32+col],front=(cell>>(2*direction))&3;
            for(int side=0;side<3;side++){
                int d=(direction+new[]{3,0,1}[side])&3,feature=(cell>>(2*d))&3,shape=side*4+feature;
                if(feature==2){Shape(fb,shape,range,magic,inverse);shape++;}
                Shape(fb,shape,range,light,inverse);
            }
            int vertical=-1;
            foreach(var v in groups[level])if(v[1]==row&&v[2]==col){vertical=v[0];break;}
            if(vertical<0)foreach(var v in groups[level+1])if(v[1]==row&&v[2]==col){vertical=v[0]+2;break;}
            int shapeIndex=vertical<0?12:new[]{13,15,14,16}[vertical];
            Shape(fb,shapeIndex,range,light,inverse);
            if(front!=0)break;
            row+=dr[direction];col+=dc[direction];if(row<0||row>=32||col<0||col>=32)break;
        }
        return fb;
    }
    static void Mark(byte[] fb,int row,int col,int a,int b){fb[(row*6+1)*32+col]=(byte)a;fb[(row*6+2)*32+col]=(byte)b;fb[(row*6+3)*32+col]=(byte)b;fb[(row*6+4)*32+col]=(byte)a;}
    public byte[] Map(byte[] map,int row,int col,int level){
        var fb=new byte[6144];
        for(int r=0;r<32;r++)for(int c=0;c<32;c++)for(int y=0;y<6;y++)fb[(r*6+y)*32+c]=(byte)(map[r*32+c]==255?255:0);
        Mark(fb,row,col,0x24,0x18);
        foreach(var v in groups[level])Mark(fb,v[1],v[2],0x3c,0x24);
        foreach(var v in groups[level+1])Mark(fb,v[1],v[2],0x3c,0x24);
        return fb;
    }
    public byte[] SeerMap(byte[] map,int row,int col,int level,int objectRow,int objectCol,int creatureRow,int creatureCol){
        var fb=Map(map,row,col,level);
        Mark(fb,objectRow,objectCol,0,8);Mark(fb,creatureRow,creatureCol,0x10,0x54);
        Mark(fb,row,col,0x24,0x18);
        foreach(var v in groups[level])Mark(fb,v[1],v[2],0x3c,0x24);
        foreach(var v in groups[level+1])Mark(fb,v[1],v[2],0x3c,0x24);
        return fb;
    }
    public byte[] BlockedBits(byte[] map){
        var bits=new byte[512];int n=0;
        for(int row=0;row<32;row++)for(int col=0;col<32;col++)for(int d=0;d<4;d++,n++){
            int y=row+dr[d],x=col+dc[d];bool block=y<0||y>=32||x<0||x>=32||map[y*32+x]==255;
            if(block)bits[n>>3]|=(byte)(128>>(n&7));
        }
        return bits;
    }
}
