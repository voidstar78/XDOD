# Dot-sourced by workflow.ps1 after the machine runner and bitmap exporter exist.
if(-not ('InventoryReference' -as [type])){Add-Type -Path (Join-Path $root 'tests\InventoryReference.cs')}
$sequence=@('E','P L S','P L WO S','P L WO SW','P R P T','P L TORCH','S L','S R','P L TORCH','D L','E','G R TORCH','EXAMINE','L','BOGUS','I','P R SWORD','S R','P L SWORD','P R TORCH','STOW LEFT','STOW RIGHT','PULL LEFT PINE SWORD','GET BACK TORCH','  pull  l  w  sword','S L','P L TORCH','STOW L','P R SWORD','D R','GET L WOODEN SWORD','LOOK')
$body=[Text.StringBuilder]::new(" jsr setup_vera`n jsr draw_background`n jsr inventory_init`n")
$expected=[Collections.Generic.List[byte]]::new()
$model=[InventoryReference]::new()
$pointerFields=@('hand_ptr','hand_ptr+2','bag_ptr','objects','objects+OC_LEN')
$scalarFields=@('objects+OC_OWN','objects+OC_LEN+OC_OWN','objects+OC_ROW','objects+OC_COL','objects+OC_LEVEL','objects+OC_LEN+OC_ROW','objects+OC_LEN+OC_COL','objects+OC_LEN+OC_LEVEL','object_weight','object_weight+1','display_mode','command_result')
$snapshots=@('')+$sequence
for($step=0;$step -lt $snapshots.Count;$step++){
    $command=$snapshots[$step]
    if($step -gt 0){
        for($i=0;$i -lt $command.Length;$i++){[void]$body.AppendLine((' lda #${0:X2}' -f [int][char]$command[$i]));[void]$body.AppendLine(" sta input_buf+$i")}
        [void]$body.AppendLine(" lda #$($command.Length)`n sta input_len`n jsr handle_command")
        $model.Apply($command)
    }
    $snapshot=$model.Snapshot();$expected.AddRange($snapshot)
    $offset=0x9a00+$step*18
    foreach($field in $pointerFields){
        [void]$body.AppendLine(" lda $field`n ldy $field+1`n jsr test_pointer_id")
        [void]$body.AppendLine((' sta ${0:X4}' -f $offset));$offset++
    }
    foreach($field in $scalarFields){[void]$body.AppendLine(" lda $field");[void]$body.AppendLine((' sta ${0:X4}' -f $offset));$offset++}
    [void]$body.AppendLine(" lda active_torch`n ldy active_torch+1`n jsr test_pointer_id")
    [void]$body.AppendLine((' sta ${0:X4}' -f $offset))
}
[void]$body.AppendLine(@'
 jmp test_snapshots_done
test_pointer_id:
 cmp #<objects
 bne :+
 cpy #>objects
 bne :+
 lda #1
 rts
: cmp #<(objects+OC_LEN)
 bne :+
 cpy #>(objects+OC_LEN)
 bne :+
 lda #2
 rts
: cmp #0
 bne :+
 cpy #0
 bne :+
 lda #0
 rts
: lda #$ff
 rts
test_snapshots_done:
'@)
$machine=Invoke-Machine 'inventory-transfers' $body.ToString()
for($step=0;$step -lt $snapshots.Count;$step++){
    $offset=0x9a00+$step*18
    $actual=[byte[]]$machine[$offset..($offset+17)]
    $wanted=[byte[]]$expected.ToArray()[($step*18)..($step*18+17)]
    $ok=Equal-Bytes $actual $wanted
    $name=if($step -eq 0){'original starting objects'}else{$snapshots[$step]}
    Check "Inventory step $step ($name)" $ok $(if($ok){'hands, links, ownership, position, weight, view and command result match source model'}else{'actual='+($actual -join ',')+' expected='+($wanted -join ',')})
}
function Command-Assembly([string]$line){
    $code=[Text.StringBuilder]::new()
    for($i=0;$i -lt $line.Length;$i++){[void]$code.AppendLine((' lda #${0:X2}' -f [int][char]$line[$i]));[void]$code.AppendLine(" sta input_buf+$i")}
    [void]$code.AppendLine(" lda #$($line.Length)`n sta input_len`n jsr handle_command`n stz input_len`n lda display_mode`n cmp #2`n bcs :+`n jsr draw_prompt`n:")
    return $code.ToString()
}
$setupInventory=" jsr setup_vera`n jsr draw_background`n jsr inventory_init`n jsr inventory_status`n"
$examine=Invoke-Machine 'inventory-screen' ($setupInventory+(Command-Assembly 'E')) -Video
Export-MachineImage $examine (Join-Path $results 'inventory.png')
function Text-Pixels-Equal([byte[]]$dump,[string]$text,[int]$column,[int]$scanline,[int]$inverse=0){
    if($scanline -eq 176 -and !$PSBoundParameters.ContainsKey('inverse')){$inverse=17}
    for($i=0;$i -lt $text.Length;$i++){
        $fontOffset=2+$labels.font_data-0x801+([int][char]$text[$i]-32)*32
        for($y=0;$y -lt 8;$y++){for($x=0;$x -lt 4;$x++){
            $wanted=(Get-FontPixelByte ([int][char]$text[$i]) $y $x) -bxor $inverse
            if($dump[40960+($scanline+$y)*160+($column+$i)*4+$x] -ne $wanted){return $false}
        }}
    }
    return $true
}
Check 'Starting backpack raster' ((Text-Pixels-Equal $examine 'WOODEN SWORD' 4 48) -and (Text-Pixels-Equal $examine 'PINE TORCH' 20 48)) 'source-defined starting items are drawn from actual OCBs in two columns'
Check 'Empty starting hands raster' ((Text-Pixels-Equal $examine 'EMPTY' 4 176) -and (Text-Pixels-Equal $examine 'EMPTY' 31 176)) 'actual left/right hand state; right name aligned to logical column 31'
$returnView=Invoke-Machine 'inventory-look' ($setupInventory+(Command-Assembly 'E')+(Command-Assembly 'L')) -Video
Export-MachineImage $returnView (Join-Path $results 'look-after-inventory.png')
$screenSource=[IO.File]::ReadAllText((Join-Path $root 'src\screen.inc'))
$rle=@([regex]::Matches($screenSource,'\$([0-9A-Fa-f]{2})') | ForEach-Object {[Convert]::ToByte($_.Groups[1].Value,16)})
$pixels=[Collections.Generic.List[byte]]::new()
for($i=0;$i -lt $rle.Length;$i+=2){for($j=0;$j -lt $rle[$i];$j++){$pixels.Add($rle[$i+1])}}
Check 'EXAMINE -> LOOK restores view' (Equal-Bytes $returnView[40960..(40960+176*160-1)] (New-Object byte[] (176*160))) 'unlit LOOK is dark; no torch is silently activated'
# Actual CCB position/liveness gates !CREATURE!, not a canned always-on label.
$creatureSetup=@'
 lda #1
 sta creatures+12
 lda player_row
 sta creatures+15
 lda player_col
 sta creatures+16
'@
$warning=Invoke-Machine 'inventory-warning' ($setupInventory+$creatureSetup+"`n"+(Command-Assembly 'E')) -Video
Export-MachineImage $warning (Join-Path $results 'inventory-creature.png')
$changed=0
for($i=0;$i -lt 8*160;$i++){if($warning[40960+32*160+$i] -ne $examine[40960+32*160+$i]){$changed++}}
Check 'Inventory creature warning' (($changed -gt 0) -and (Text-Pixels-Equal $warning '!CREATURE!' 15 32)) 'exact warning glyphs from a live CCB at the player position'
$otherRoom=$creatureSetup+"`n inc creatures+16`n"
$absent=Invoke-Machine 'inventory-other-room' ($setupInventory+$otherRoom+(Command-Assembly 'E')) -Video
Check 'No warning for another room' (Equal-Bytes $absent[40960..79359] $examine[40960..79359]) 'live creature at another coordinate leaves the entire inventory image unchanged'
# PPULL explicitly clears PTORCH if the removed bag object was the burning torch.
$torchSetup=" lda #<(objects+OC_LEN)`n sta active_torch`n lda #>(objects+OC_LEN)`n sta active_torch+1`n"
$lit=Invoke-Machine 'inventory-highlight' ($setupInventory+$torchSetup+(Command-Assembly 'E')) -Video
Check 'Active torch highlight' (Text-Pixels-Equal $lit 'PINE TORCH' 20 48 17) 'EXAMIN inverts the burning backpack torch, then restores normal text'
$torch=Invoke-Machine 'inventory-active-torch' ($setupInventory+$torchSetup+(Command-Assembly 'P L TORCH')+" lda active_torch`n sta `$9a00`n lda active_torch+1`n sta `$9a01`n")
Check 'PULL extinguishes active bag torch' ($torch[0x9a00] -eq 0 -and $torch[0x9a01] -eq 0) 'PPULL clears the active-torch pointer, independent of the burn task'
$dropped=Invoke-Machine 'inventory-floor' ($setupInventory+(Command-Assembly 'P L TORCH')+(Command-Assembly 'D L')+(Command-Assembly 'E')) -Video
Check 'Dropped object appears in room' ((Text-Pixels-Equal $dropped 'PINE TORCH' 4 32) -and (Text-Pixels-Equal $dropped 'WOODEN SWORD' 4 56)) 'room objects precede separator; backpack is rebuilt from its remaining list'
$equipped=Invoke-Machine 'inventory-equipped' ($setupInventory+(Command-Assembly 'E')+(Command-Assembly 'P L SWORD')+(Command-Assembly 'P R TORCH')) -Video
Export-MachineImage $equipped (Join-Path $results 'inventory-equipped.png')
Check 'Equipped objects status raster' ((Text-Pixels-Equal $equipped 'WOODEN SWORD' 4 176) -and (Text-Pixels-Equal $equipped 'PINE TORCH' 26 176)) 'both actual held objects are drawn and removed from backpack'
