# Compare actual machine half-step rasters against the source-scale host renderer.
foreach($mode in @(1,2)){
 $scales=if($mode -eq 1){[int[]]@(255,156,100,65,40,26,16,10,6,3)}else{[int[]]@(156,100,65,40,26,16,10,6,3,1)}
 $halfModel=[WorldReference]::new($shapeList.ToArray(),$scales)
 foreach($level in 0..4){
  $row=16;$col=11
  if($fullMaps[$level][$row*32+$col] -eq 255){$pos=0;while($fullMaps[$level][$pos] -eq 255){$pos++};$row=[int][Math]::Floor($pos/32);$col=$pos%32}
  $body=$worldSetup+" lda #$level`n sta maze_level`n jsr maze_generate`n lda #$row`n sta player_row`n lda #$col`n sta player_col`n lda #13`n sta regular_light`n sta magic_light`n lda #$mode`n sta motion_scale_mode`n jsr world_viewer`n"
  $half=Invoke-Machine "half-$mode-level$level" $body -Video
  $expected=$halfModel.View($fullMaps[$level],$row,$col,0,13,13,$level)
  Check "Half-step mode $mode level $($level+1)" (Equal-Bytes ([WorldReference]::FromDump($half,152)) $expected[0..4863]) 'entire raster follows original HLFSCL/BAKSCL with signed fixed-point endpoint scaling'
  if($level -eq 0){Export-MachineImage $half (Join-Path $results "half-step-$mode.png")}
 }
}
# Source HUPDAT arithmetic, including the final failed subtraction in its quotient.
$healthBody=[Text.StringBuilder]::new($worldSetup);$healthExpected=[Collections.Generic.List[byte]]::new();$offset=0x9a00
foreach($power in @(160,1000,6000)){
 foreach($damage in @(0,1,8,64,128,132,136,140,144,152,160,161,256,1000,6000)){
  [void]$healthBody.AppendLine(" lda #$($power -band 255)`n sta health_power`n lda #$($power -shr 8)`n sta health_power+1`n lda #$($damage -band 255)`n sta world_damage`n lda #$($damage -shr 8)`n sta world_damage+1`n stz health_fainted`n stz health_dead`n jsr health_update")
  $rate=([int][Math]::Floor(64.0*$power/($power+2*$damage))+1-19) -band 255
  $signed=if($rate -gt 127){$rate-256}else{$rate}
  $dead=[int]($damage -gt $power);$faint=[int]($signed -le 3 -or $dead)
  $healthExpected.AddRange([byte[]]@($rate,$faint,$dead))
  foreach($field in @('health_rate','health_fainted','health_dead')){[void]$healthBody.AppendLine(" lda $field");[void]$healthBody.AppendLine((' sta ${0:X4}' -f $offset));$offset++}
 }
}
$health=Invoke-Machine 'health-arithmetic' $healthBody.ToString()
Check 'Original HUPDAT rate and thresholds' (Equal-Bytes $health[0x9a00..($offset-1)] $healthExpected.ToArray()) '45 power/damage pairs: 24-bit division, signed faint threshold and strict damage>power death'
$recoverBody=[Text.StringBuilder]::new($worldSetup+" lda #160`n sta world_damage`n stz world_damage+1`n jsr health_update`n")
$recoveryExpected=[Collections.Generic.List[byte]]::new();$damage=160;$fainted=1;$offset=0x9a00
for($i=0;$i -lt 180;$i++){
 [void]$recoverBody.AppendLine(' jsr health_slow')
 $damage=[Math]::Max(0,$damage-[int][Math]::Ceiling($damage/64.0))
 $rate=[int][Math]::Floor(10240.0/(160+2*$damage))+1-19
 if($fainted -and $rate -gt 4){$fainted=0}
 $recoveryExpected.AddRange([byte[]]@($damage,$rate,$fainted))
 foreach($field in @('world_damage','health_rate','health_fainted')){[void]$recoverBody.AppendLine(" lda $field");[void]$recoverBody.AppendLine((' sta ${0:X4}' -f $offset));$offset++}
}
$recovered=Invoke-Machine 'health-recovery' $recoverBody.ToString()
Check 'HSLOW recovery and waking hysteresis' (Equal-Bytes $recovered[0x9a00..($offset-1)] $recoveryExpected.ToArray()) '180 source recovery updates: ceil(D/64), waking only above rate 4, no residual damage at rest'
# An awake player can cross the death threshold in a single heavily laden bump.
$heavy=$worldSetup+" stz maze_level`n jsr maze_generate`n lda #136`n sta world_damage`n lda #200`n sta object_weight`n stz object_weight+1`n lda #0`n sta player_row`n sta player_col`n sta player_direction`n"+(Command-Assembly 'M')+" lda world_damage`n sta `$9a00`n lda health_dead`n sta `$9a01`n lda world_move_result`n sta `$9a02`n"
$heavyDump=Invoke-Machine 'heavy-wall-death' $heavy
Check 'Laden wall collision can be fatal' (Equal-Bytes $heavyDump[0x9a00..0x9a02] ([byte[]]@(164,1,1))) 'blocked step retains position and adds (200/8)+3=28 damage, exceeding power 160'

# Count publications with a test-only trampoline; execute production rendering.
$publishHook=" stz `$9a00`n lda #`$4c`n sta world_publish`n lda #<test_publish_hook`n sta world_publish+1`n lda #>test_publish_hook`n sta world_publish+2`n"
$publishEnd=" jmp test_publish_done`ntest_publish_hook:`n inc `$9a00`n sta world_height`n jmp world_publish+3`ntest_publish_done:`n"
foreach($case in @(@('T L',2),@('T R',2),@('T A',3),@('M',2),@('M B',2))){
 $command=$case[0];$count=$case[1]
 $scene=$litSetup+$publishHook+(Command-Assembly $command)+$publishEnd
 $sequence=Invoke-Machine ('motion-sequence-'+$command.Replace(' ','-')) $scene -Video
 Check "Original $command frame sequence" ($sequence[0x9a00] -eq $count) 'turns upload the horizontal base once per sweep; moving columns are patched in place; MOVE publishes half-step then standing view'
}
$blockedScene=$litSetup+" stz player_row`n stz player_col`n stz player_direction`n"+$publishHook+(Command-Assembly 'M')+$publishEnd+" lda player_row`n sta `$9a01`n lda player_col`n sta `$9a02`n lda world_move_result`n sta `$9a03`n"
$bounce=Invoke-Machine 'wall-bounce-sequence' $blockedScene
Check 'Blocked forward step bounces' ($bounce[0x9a00] -eq 2 -and $bounce[0x9a01] -eq 0 -and $bounce[0x9a02] -eq 0 -and $bounce[0x9a03] -eq 1) 'half-step published, obstruction rejects position change, then standing view restored'
# Rendered mode retains actual delays and runs the real chained KERNAL clock.
$timingBody=" jmp start`nboot_resume:`n cli`n"+(Command-Assembly 'P R T')+(Command-Assembly 'U R')+" jsr `$ffde`n sta `$9a04`n"+(Command-Assembly 'T R')+" jsr `$ffde`n sec`n sbc `$9a04`n sta `$9a00`n jsr `$ffde`n sta `$9a04`n"+(Command-Assembly 'T A')+" jsr `$ffde`n sec`n sbc `$9a04`n sta `$9a01`n sei`n"
$animationTime=Invoke-Machine 'rendered-animation-timing' $timingBody -Boot -Rendered
Check 'Live IRQ animation timing' ($animationTime[0x9a00] -ge 16 -and $animationTime[0x9a01] -ge 32 -and $animationTime[0x9a01] -gt $animationTime[0x9a00]) 'real KERNAL jiffies advance during each animation; about-face takes two complete sweeps'
# Faint/wake presentation must blank and restore the same lit architecture.
$faintSetup=$litSetup+" lda #160`n sta world_damage`n jsr health_update`n jsr health_present`n"
$faintImage=Invoke-Machine 'faint-presentation' $faintSetup -Video
$black=New-Object byte[] 4864
Check 'Faint blanks dungeon view' (Equal-Bytes ([WorldReference]::FromDump($faintImage,152)) $black) 'source threshold triggers fade-out and an empty primary dungeon view'
$wakeBody=$faintSetup+" stz world_damage`n stz world_damage+1`n jsr health_update`n jsr health_present`n"
$wakeImage=Invoke-Machine 'wake-presentation' $wakeBody -Video
$restored=$worldModel.View($fullMaps[0],16,11,0,7,0,0)
Check 'Waking restores lit view' (Equal-Bytes ([WorldReference]::FromDump($wakeImage,152)) $restored[0..4863]) 'recovery above the waking threshold fades the original architecture back in'
