# The visible parser must echo a key without repainting all 128 cells.
$r=Invoke-Combat 'console-single-letter-cache' ($worldSetup+" jsr console_init`n jsr console_prompt`n stz console_drawn`n stz console_drawn+1`n lda #'A'`n jsr console_put`n jsr console_render`n") -Video
Check 'Typing redraws only changed console cells' (($r[$combatLabels.console_drawn]+256*$r[$combatLabels.console_drawn+1]) -le 2 -and (Text-Pixels-Equal $r '.A' 4 192 0)) 'the cursor and new character update without a four-row repaint'

$r=Invoke-Combat 'color2-emulator-hues' ($worldSetup+" lda #5`n sta artifact_mode`n lda #16`n jsr artifact_pair`n sta `$9a00`n lda #1`n jsr artifact_pair`n sta `$9a01`n") -Video
Check 'COLOR 2 uses crisp orange and blue' (Equal-Bytes $r[0x9a00..0x9a01] ([byte[]]@(0x40,0x05))) 'one-pixel chroma positions; palette entries 4/5 are separate from the RF pink/cyan and RGB blue/gold modes'

foreach($delta in @(@(0,0),@(8,2),@(2,8),@(8,3),@(3,3),@(9,0))){
 $dr=$delta[0];$dc=$delta[1]
 $body=$worldSetup+" jsr cre_first`n lda #10`n sta player_row`n sta player_col`n lda #$(10+$dr)`n sta creatures+15`n lda #$(10+$dc)`n sta creatures+16`n stz creatures+14`n stz `$0400`n stz `$0401`n lda #`$38`n sta cre_step`n lda #`$60`n sta cre_step+1`n lda #`$18`n sta cre_find`n lda #`$60`n sta cre_find+1`n lda #`$4c`n sta rng_next`n lda #<sound_rng`n sta rng_next+1`n lda #>sound_rng`n sta rng_next+2`n lda #`$4c`n sta game_sound`n lda #<sound_probe`n sta game_sound+1`n lda #>sound_probe`n sta game_sound+2`n lda #0`n jsr cre_walk`n jmp `$ffff`nsound_rng:`n inc `$0400`n lda #1`n rts`nsound_probe:`n inc `$0401`n stx `$0402`n rts`n"
 $r=Invoke-Combat "hearing-cross-$dr-$dc" $body
 $audible=([Math]::Max($dr,$dc) -le 8 -and [Math]::Min($dr,$dc) -le 2)
 Check "Original hearing area ($dr,$dc)" ($r[0x400] -eq [int]$audible -and $r[0x401] -eq [int]$audible -and (!$audible -or $r[0x402] -eq [Math]::Max($dr,$dc))) 'source CWALK uses larger axis <=8 and smaller axis <=2; max-axis distance drives gain, and inaudible moves consume no sound-choice RNG'
}

$body=@'
 jsr audio_init
 stz aud_conversions
 stz aud_conversions+1
 lda #1
 sta aud_type
 sta aud_distance
 jsr audio_cached_expand
 lda aud_conversions
 sta $0400
 jsr audio_cached_expand
 lda aud_conversions
 sta $0401
 lda #2
 sta aud_distance
 jsr audio_cached_expand
 lda aud_conversions
 sta $0402
'@
$r=Invoke-Machine 'audio-exact-cache-gain-change' $body
Check 'PCM cache reuses only matching gains' (Equal-Bytes $r[0x400..0x402] ([byte[]]@(1,1,2))) 'repeat playback avoids conversion; a changed distance rebuilds the voice'
$expected=[DodSoundTrace]::DecodeGain(([DodSoundTrace]::Build(1)).Encode(),128)
Check 'Cached PCM retains the exact approved waveform' (Equal-Bytes $r[(40960+7*8192)..(40960+7*8192+$expected.Length-1)] $expected) 'every PCM byte at the new distance matches the independent sound oracle'
$cacheSymbols=Save-TestSymbols 'audio-exact-cache-gain-change'
$playLength=8192*($r[$cacheSymbols.aud_endbank]-7)+$r[$cacheSymbols.aud_end]+256*$r[$cacheSymbols.aud_end+1]-0xa000
$quiet=$playLength -gt 128 -and $playLength -lt $expected.Length
for($i=$playLength-128;$i -lt $expected.Length;$i++){$sample=[int]$expected[$i];if($sample -ge 128){$sample-=256};if([Math]::Abs($sample) -gt 1){$quiet=$false}}
Check 'Playback trims only the settled quiet tail' $quiet 'at least 128 settled samples remain, and every removed sample is within one signed PCM unit of zero; full cached waveform remains intact'

$body=@'
 jsr audio_init
 stz aud_conversions
 lda #10
 sta aud_type
 stz aud_distance
 jsr audio_cached_expand
 lda #19
 sta aud_type
 jsr audio_cached_expand
 lda #10
 sta aud_type
 jsr audio_cached_expand
 lda aud_conversions
 sta $0400
'@
$r=Invoke-Machine 'audio-wizard-cache-alias' $body
Check 'Shared wizard/explosion bank slot invalidates safely' ($r[0x400] -eq 3) 'each overwriting voice invalidates its alias; the 512KB machine needs no extra RAM'

# A key is queued in actual KERNAL bank zero after the defeat timeout, at
# the beginning of the returning title's PCM explosion rather than its fade.
$body=@'
 jmp start
boot_resume:
 cli
 jsr game_death_scene
 lda game_second
 sta intro_death_deadline
 lda #$4c
 sta audio_poll
 lda #<inject_title_key
 sta audio_poll+1
 lda #>inject_title_key
 sta audio_poll+2
 jsr demo_poll
 sei
 lda display_mode
 sta $0400
 lda intro_abort
 sta $0401
 jmp $ffff
inject_title_key:
 lda #$20
 sta audio_poll
 lda #<health_poll
 sta audio_poll+1
 lda #>health_poll
 sta audio_poll+2
 lda $00
 pha
 stz $00
 lda #'X'
 sta KEYBUFFER
 lda #1
 sta KEYCOUNT
 pla
 sta $00
 lda intro_kind
 sta $0402
 jmp audio_poll
'@
$keySymbols=@{};Get-Content (Join-Path (Split-Path $Emulator -Parent) 'kernal.sym')|ForEach-Object{if($_ -match '^al ([0-9A-Fa-f]+) \.(keyd|ndx)$'){$keySymbols[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
$body=$body.Replace('KEYBUFFER',('$'+('{0:x4}' -f $keySymbols.keyd))).Replace('KEYCOUNT',('$'+('{0:x4}' -f $keySymbols.ndx)))
$r=Invoke-Machine 'audio-return-title-interrupt-explosion' $body -Boot -Rendered
Check 'Returning title accepts a key during its sound' (Equal-Bytes $r[0x400..0x402] ([byte[]]@(0,1,0))) 'fresh key cancels title PCM and starts a new game after the defeat timeout; death-taunt keys remain discarded'

$burst="A L`rA L`rA L`r"
$body=$worldSetup+" stz input_read`n stz input_write`n stz health_pending`n stz `$00`n"
foreach($batch in @(@(0,9),@(10,11))){
 foreach($i in $batch[0]..$batch[1]){$body+=" lda #$([int][char]$burst[$i])`n sta `$"+('{0:x4}' -f ($keySymbols.keyd+$i-$batch[0]))+"`n"}
 $body+=" lda #$($batch[1]-$batch[0]+1)`n sta `$"+('{0:x4}' -f $keySymbols.ndx)+"`n jsr audio_poll`n"
}
foreach($i in 0..12){$body+=" jsr game_getin`n sta `$"+('{0:x4}' -f (0x400+$i))+"`n"}
$body+=" jsr intro_flush_keys`n lda input_read`n ora input_write`n sta `$040d`n"
$r=Invoke-Combat 'input-three-attacks-during-sound' $body
Check 'Sound buffering retains three rapid attack commands' (Equal-Bytes $r[0x400..0x40d] ([byte[]](@($burst.ToCharArray()|ForEach-Object {[int]$_})+@(0,0)))) 'two actual KERNAL buffer batches become twelve ordered characters; death/title flush clears the private buffer too'
