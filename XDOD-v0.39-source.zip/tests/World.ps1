if(-not ('WorldReference' -as [type])){Add-Type -Path (Join-Path $root 'tests\WorldReference.cs')}
$geometry=Get-Content -LiteralPath (Join-Path $root 'tests\world-geometry.json') -Raw | ConvertFrom-Json
$shapeList=[Collections.Generic.List[int[][]]]::new()
foreach($shape in $geometry.shapes){$lines=[Collections.Generic.List[int[]]]::new();foreach($line in $shape.lines){$lines.Add([int[]]$line)};$shapeList.Add($lines.ToArray())}
$worldModel=[WorldReference]::new($shapeList.ToArray(),[int[]]$geometry.scales)
$worldSetup=" jsr setup_vera`n jsr draw_background`n jsr inventory_init`n jsr world_init`n jsr world_add_test_scroll`n stz heart_state`n"
for($level=0;$level -lt 5;$level++){
    $map=$fullMaps[$level]
    $position=16*32+11
    if($map[$position] -eq 255){$position=[Array]::FindIndex($map,[Predicate[byte]]{param($v) $v -ne 255})}
    $row=[int][Math]::Floor($position/32);$col=$position%32
    for($direction=0;$direction -lt 4;$direction++){
        $light=if($level -eq 0 -and $direction -eq 0){7}else{13};$magic=if($light -eq 7){0}else{11}
        $setup=$worldSetup+" lda #$level`n sta maze_level`n jsr maze_generate`n lda #$row`n sta player_row`n lda #$col`n sta player_col`n lda #$direction`n sta player_direction`n lda #$light`n sta regular_light`n lda #$magic`n sta magic_light`n jsr world_viewer`n jsr inventory_status`n jsr console_render`n"
        $rendered=Invoke-Machine "view-level$($level+1)-dir$direction" $setup -Video
        $expected=$worldModel.View($map,$row,$col,$direction,$light,$magic,$level)
        Check "World view L$($level+1) D$direction" (Equal-Bytes ([WorldReference]::FromDump($rendered,152)) $expected[0..4863]) 'entire 256x152 view matches original geometry, fixed-point stepping, clipping, fade and inverse level'
        if($direction -eq 0){
            $statusInverse=if($level%2){0}else{17}
            Check "Level $($level+1) status polarity" (Text-Pixels-Equal $rendered 'EMPTY' 4 176 $statusInverse) 'original alternating main/status inverse treatment'
        }
        if($direction -eq 0){Export-MachineImage $rendered (Join-Path $results "dungeon-level$($level+1).png")}
    }
    $mapSetup=$worldSetup+" lda #$level`n sta maze_level`n jsr maze_generate`n lda #$row`n sta player_row`n lda #$col`n sta player_col`n jsr world_map`n"
    $mapped=Invoke-Machine "map-level$($level+1)" $mapSetup -Video
    Check "Original scroll map L$($level+1)" (Equal-Bytes ([WorldReference]::FromDump($mapped,192)) ($worldModel.Map($map,$row,$col,$level))) 'all 6144 bitmap bytes: 8x6 cells, player X and original up/down feature markers'
    Export-MachineImage $mapped (Join-Path $results "scroll-level$($level+1).png")
}
# Every cell/direction on every level, including border rejection and doors.
$nav=[Text.StringBuilder]::new($worldSetup)
for($level=0;$level -lt 5;$level++){
    [void]$nav.AppendLine(" lda #$level`n sta maze_level`n jsr maze_generate")
    # Set result pointer with ordinary hex immediates, not source relocations.
    [void]$nav.AppendLine((' lda #${0:X2}' -f ((0x8000+$level*512) -band 255)))
    [void]$nav.AppendLine(' sta str_ptr')
    [void]$nav.AppendLine((' lda #${0:X2}' -f ((0x8000+$level*512) -shr 8)))
    [void]$nav.AppendLine(" sta str_ptr+1`n stz test_row`n stz test_col`n stz test_dir`n stz test_bits`n stz test_count`n jsr test_all_steps")
}
[void]$nav.AppendLine(@'
 jmp test_nav_done
test_all_steps:
 lda test_row
 sta player_row
 lda test_col
 sta player_col
 lda test_dir
 sta player_direction
 lda #0
 jsr world_try_step
 lda world_move_result
 cmp #1
 lda test_bits
 rol
 sta test_bits
 inc test_count
 lda test_count
 cmp #8
 bne @next_direction
 ldy #0
 lda test_bits
 sta (str_ptr),y
 inc str_ptr
 bne @reset_bits
 inc str_ptr+1
@reset_bits:
 stz test_count
 stz test_bits
@next_direction:
 inc test_dir
 lda test_dir
 cmp #4
 bcc test_all_steps
 stz test_dir
 inc test_col
 lda test_col
 cmp #32
 bcc test_all_steps
 stz test_col
 inc test_row
 lda test_row
 cmp #32
 bcc test_all_steps
 rts
test_row: .byte 0
test_col: .byte 0
test_dir: .byte 0
test_bits: .byte 0
test_count: .byte 0
test_nav_done:
'@)
$steps=Invoke-Machine 'world-navigation' $nav.ToString()
for($level=0;$level -lt 5;$level++){
    Check "All movement destinations L$($level+1)" (Equal-Bytes $steps[(0x8000+512*$level)..(0x81ff+512*$level)] ($worldModel.BlockedBits($fullMaps[$level]))) '4096 direction/cell decisions match original STEPOK; walls and bounds reject, doors permit entry'
}
# Scroll must be a usable OCB and original hand-based USE command.
$scroll=Invoke-Machine 'test-scroll-use' ($worldSetup+" stz maze_level`n jsr maze_generate`n"+(Command-Assembly 'P R SCROLL')+(Command-Assembly 'U R')+" lda display_mode`n sta `$9a00`n lda hand_ptr+2`n sec`n sbc #<objects`n sta `$9a01`n") -Video
Check 'Revealed test scroll is usable' ($scroll[0x9a00] -eq 2 -and $scroll[0x9a01] -eq 28) 'P R SCROLL / U R selects MAPPER and keeps the scroll held as the original does'
Check 'USE scroll map raster' (Equal-Bytes ([WorldReference]::FromDump($scroll,192)) ($worldModel.Map($fullMaps[0],16,11,0))) 'the command path produces the same full-screen original map'
$mapHeartbeat=Invoke-Machine 'map-heartbeat' ($worldSetup+" stz maze_level`n jsr maze_generate`n stz burn_ticks`n"+(Command-Assembly 'P R SCROLL')+(Command-Assembly 'U R')+" jsr heartbeat_tick`n") -Video
Check 'Map suppresses status heartbeat' (Equal-Bytes ([WorldReference]::FromDump($mapHeartbeat,192)) ($worldModel.Map($fullMaps[0],16,11,0))) 'heartbeat cannot overwrite the full-screen map with status glyphs'
$unrevealed=Invoke-Machine 'scroll-unrevealed' ($worldSetup+" lda #5`n sta objects+2*OC_LEN+OC_REVEAL`n"+(Command-Assembly 'P R SCROLL')+(Command-Assembly 'U R')+" lda display_mode`n sta `$9a00`n")
Check 'Unrevealed scroll does not map' ($unrevealed[0x9a00] -eq 0) 'original PUSE refuses the unrevealed scroll without inventing a new success action'
# Test the actual TURN/MOVE parser and its position, orientation and damage changes.
$trace=@('T L','M','T R','M R','T A','M B','M L','M','T R','M','T L','T L','M','M B')
$traceBody=[Text.StringBuilder]::new($worldSetup+" stz maze_level`n jsr maze_generate`n")
$expectedTrace=[Collections.Generic.List[byte]]::new();$r=16;$c=11;$d=0;$damage=0;$blocked=0
$dr=@(-1,0,1,0);$dc=@(0,1,0,-1)
for($i=0;$i -lt $trace.Count;$i++){
    [void]$traceBody.AppendLine((Command-Assembly $trace[$i]))
    $tokens=$trace[$i].Split(' ')
    if($tokens[0] -eq 'T'){$d=($d+@{L=3;R=1;A=2}[$tokens[1]])%4}else{
        $relative=if($tokens.Count -eq 1){0}else{@{L=3;R=1;B=2}[$tokens[1]]}
        $absolute=($d+$relative)%4;$nr=$r+$dr[$absolute];$nc=$c+$dc[$absolute]
        $blocked=[int]($nr -lt 0 -or $nr -ge 32 -or $nc -lt 0 -or $nc -ge 32 -or $fullMaps[0][$nr*32+$nc] -eq 255)
        if(!$blocked){$r=$nr;$c=$nc};$damage+=8
    }
    $expectedTrace.AddRange([byte[]]@($r,$c,$d,($damage -band 255),($damage -shr 8),$blocked))
    $offset=0x9a00+6*$i
    foreach($field in @('player_row','player_col','player_direction','world_damage','world_damage+1','world_move_result')){
        [void]$traceBody.AppendLine(" lda $field");[void]$traceBody.AppendLine((' sta ${0:X4}' -f $offset));$offset++
    }
}
$traced=Invoke-Machine 'world-command-trace' $traceBody.ToString()
Check 'TURN and MOVE command trajectory' (Equal-Bytes $traced[0x9a00..(0x9a00+$expectedTrace.Count-1)] $expectedTrace.ToArray()) '14 commands match position, facing, blocked state and original PMOV90 weight-based energy cost'
# Returning to a view produces exactly the same raster; no temporal phase input.
$litSetup=$worldSetup+" stz maze_level`n jsr maze_generate`n"+(Command-Assembly 'P R T')+(Command-Assembly 'U R')
$startView=Invoke-Machine 'view-stability-start' ($litSetup+(Command-Assembly 'L')) -Video
$returnedView=Invoke-Machine 'view-stability-return' ($litSetup+(Command-Assembly 'T L')+(Command-Assembly 'T R')) -Video
Check 'Turn left then right restores raster' (Equal-Bytes ([WorldReference]::FromDump($startView,152)) ([WorldReference]::FromDump($returnedView,152))) 'same world, torch and facing yield byte-identical dungeon pixels'
Export-MachineImage $startView (Join-Path $results 'navigable-dungeon.png')
# Production keyboard loop: map USE skips prompt, first next key restores view
# and is still processed as the first letter of TURN.
$keys="P R T`rU R`rP R SCROLL`rU R`rT R`rM`r"
$keyboardWorld=@'
 jmp start
boot_resume:
 ldx test_world_key_index
 lda test_world_keys,x
 beq test_world_keys_done
 inc test_world_key_index
 jmp input_received
test_world_keys_done:
 lda display_mode
 sta $9a00
 lda player_direction
 sta $9a01
 lda player_row
 sta $9a02
 lda player_col
 sta $9a03
 jmp $ffff
test_world_key_index: .byte 0
test_world_keys:
'@
$keyboardWorld+="`n .byte "+((@($keys.ToCharArray() | ForEach-Object {[int]$_})+@(0)) -join ',')+"`n"
$interactive=Invoke-Machine 'world-keyboard-flow' $keyboardWorld -Boot -Video
$expectedRow=16;$expectedCol=if($fullMaps[0][16*32+12] -ne 255){12}else{11}
Check 'Scroll exit and navigation keyboard flow' (Equal-Bytes $interactive[0x9a00..0x9a03] ([byte[]]@(0,1,$expectedRow,$expectedCol))) 'next key exits MAPPER; T R and M still execute; viewport returns to dungeon'
$interactiveExpected=$worldModel.View($fullMaps[0],$expectedRow,$expectedCol,1,7,0,0)
Check 'Interactive moved view raster' (Equal-Bytes ([WorldReference]::FromDump($interactive,152)) $interactiveExpected[0..4863]) 'production keyboard/USE/MOVE path displays the expected new room view'
Export-MachineImage $interactive (Join-Path $results 'navigation-keyboard.png')
$targeted=@(@(0,0,23,0),@(0,15,4,0),@(1,0,23,0))
$secretPosition=-1;$secretDirection=0
for($i=0;$i -lt 1024 -and $secretPosition -lt 0;$i++){if($fullMaps[0][$i] -ne 255){for($d=0;$d -lt 4;$d++){if((($fullMaps[0][$i] -shr (2*$d)) -band 3) -eq 2){$secretPosition=$i;$secretDirection=$d;break}}}}
$targeted+=,@(0,[int][Math]::Floor($secretPosition/32),($secretPosition%32),$secretDirection)
for($i=0;$i -lt $targeted.Count;$i++){
    $case=$targeted[$i];$level=$case[0];$row=$case[1];$col=$case[2];$direction=$case[3]
    $scene=$worldSetup+" lda #$level`n sta maze_level`n jsr maze_generate`n lda #$row`n sta player_row`n lda #$col`n sta player_col`n lda #$direction`n sta player_direction`n lda #13`n sta regular_light`n sta magic_light`n jsr world_viewer`n"
    $image=Invoke-Machine "world-feature-$i" $scene -Video
    $expected=$worldModel.View($fullMaps[$level],$row,$col,$direction,13,13,$level)
    Check "Original vertical/secret geometry $i" (Equal-Bytes ([WorldReference]::FromDump($image,152)) $expected[0..4863]) 'ladder up/down, floor hole or magical secret-door overlay matches source raster'
}
$open=@(0..1023 | Where-Object {$fullMaps[0][$_] -ne 255 -and $_ -ne (16*32+11)})
$pr=[int][Math]::Floor($open[0]/32);$pc=$open[0]%32
$cr=[int][Math]::Floor($open[1]/32);$cc=$open[1]%32
$seerScene=$worldSetup+" stz maze_level`n jsr maze_generate`n lda #TYPE_SCR1`n sta objects+2*OC_LEN+OC_TYPE`n"+(Command-Assembly 'P L SW')+(Command-Assembly 'D L')+" lda #$pr`n sta player_row`n lda #$pc`n sta player_col`n lda #1`n sta creatures+12`n lda #$cr`n sta creatures+15`n lda #$cc`n sta creatures+16`n"+(Command-Assembly 'P R SCROLL')+(Command-Assembly 'U R')
$seer=Invoke-Machine 'seer-map-markers' $seerScene -Video
Check 'Seer scroll object and creature markers' (Equal-Bytes ([WorldReference]::FromDump($seer,192)) ($worldModel.SeerMap($fullMaps[0],$pr,$pc,0,16,11,$cr,$cc))) 'original MAPPER marker patterns, ownership filter and player/vertical drawing order'
