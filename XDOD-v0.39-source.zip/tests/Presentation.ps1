# Original full maze, four-row console, SPCTAB heart and torch-use fixtures.
$body=[Text.StringBuilder]::new();$fullMaps=@();$fullSeeds=@()
for($level=0;$level -lt 5;$level++){
    [void]$body.AppendLine(" lda #$level`n sta maze_level`n jsr maze_generate")
    for($page=0;$page -lt 4;$page++){
        [void]$body.AppendLine(" ldx #0`n: lda maze_map+$($page*256),x")
        [void]$body.AppendLine((' sta ${0:X4},x' -f (0x8000+1024*$level+256*$page)))
        [void]$body.AppendLine(" inx`n bne :-")
    }
    for($i=0;$i -lt 3;$i++){[void]$body.AppendLine(" lda rng_seed+$i");[void]$body.AppendLine((' sta ${0:X4}' -f (0x9800+3*$level+$i)))}
    $reference=[DaggorathReference]::new([byte[]]$seedTable[$level..($level+2)])
    $fullMaps+=,($reference.Full());$fullSeeds+=,([byte[]]$reference.Seed.Clone())
}
$full=Invoke-Machine 'complete-mazes' $body.ToString()
for($level=0;$level -lt 5;$level++){
    $actual=[byte[]]$full[(0x8000+1024*$level)..(0x83ff+1024*$level)]
    Check "Complete maze level $($level+1)" (Equal-Bytes $actual $fullMaps[$level]) 'all 1024 cell bytes, including walls and 70 regular/45 secret reciprocal doors'
    Check "Complete maze RNG level $($level+1)" (Equal-Bytes $full[(0x9800+3*$level)..(0x9802+3*$level)] $fullSeeds[$level]) 'exact state before original jiffy-dependent final spin'
    [IO.File]::WriteAllBytes((Join-Path $results "complete-level$($level+1).bin"),$actual)
}
$consoleBody=[Text.StringBuilder]::new(" jsr setup_vera`n jsr draw_background`n jsr inventory_init`n stz heart_state`n jsr inventory_status`n")
$lines=@('ZERO','ROW ONE','ROW TWO','ROW THREE','ROW FOUR')
for($line=0;$line -lt $lines.Count;$line++){
    if($line -gt 0){[void]$consoleBody.AppendLine(' jsr console_newline')}
    foreach($c in $lines[$line].ToCharArray()){[void]$consoleBody.AppendLine((' lda #${0:X2}' -f [int]$c));[void]$consoleBody.AppendLine(' jsr console_put')}
}
[void]$consoleBody.AppendLine(" jsr console_render`n ldx #0`n: lda console_text,x`n sta `$9a00,x`n inx`n cpx #128`n bcc :-")
$four=Invoke-Machine 'four-row-console' $consoleBody.ToString() -Video
$expectedText=[Text.Encoding]::ASCII.GetBytes((($lines[1..4] | ForEach-Object {$_.PadRight(32)}) -join ''))
Check 'Four-row scroll buffer' (Equal-Bytes $four[0x9a00..0x9a7f] $expectedText) 'scroll discards one oldest row and retains four complete 32-column rows'
$rowsOK=$true
for($row=0;$row -lt 4;$row++){$rowsOK=$rowsOK -and (Text-Pixels-Equal $four $lines[$row+1] 4 (184+$row*8))}
Check 'Four visible console rows' $rowsOK 'pixel rows 184,192,200,208; all four rows lie inside the original 256x192 area'
Export-MachineImage $four (Join-Path $results 'four-row-console.png')
$useBody=$setupInventory+" stz heart_state`n"+(Command-Assembly 'P R TORCH')+(Command-Assembly 'U R')+(Command-Assembly 'E')
$used=Invoke-Machine 'torch-use' ($useBody+" lda active_torch`n sec`n sbc #<objects`n sta `$9a00`n lda active_torch+1`n sbc #>objects`n sta `$9a01`n lda hand_ptr+2`n ora hand_ptr+3`n sta `$9a02`n") -Video
Check 'USE activates and stows torch' (($used[0x9a00] -eq 14) -and ($used[0x9a01] -eq 0) -and ($used[0x9a02] -eq 0)) 'original PUSE/PSTOW0: active pointer to pine torch, right hand empty'
Check 'Used torch is reversed in backpack' (Text-Pixels-Equal $used 'PINE TORCH' 4 48 17) 'active torch is inserted at backpack head and visibly inverted'
Export-MachineImage $used (Join-Path $results 'torch-active.png')
$burn=[Text.StringBuilder]::new($useBody)
for($minute=0;$minute -le 15;$minute++){
    if($minute -gt 0){[void]$burn.AppendLine(' jsr torch_burn_minute')}
    $offset=0x9a00+5*$minute
    foreach($field in @('OC_SPECIAL','OC_SPECIAL+1','OC_SPECIAL+2','OC_TYPE','OC_REVEAL')){
        [void]$burn.AppendLine(" lda objects+OC_LEN+$field");[void]$burn.AppendLine((' sta ${0:X4}' -f $offset));$offset++
    }
}
$burned=Invoke-Machine 'torch-burn' $burn.ToString()
$burnOK=$true
for($minute=0;$minute -le 15;$minute++){
    $time=[Math]::Max(15-$minute,0);$type=if($time -le 5){24}else{15}
    $expectedBurn=[byte[]]@($time,[Math]::Min(7,$time),0,$type,0)
    if(!(Equal-Bytes $burned[(0x9a00+5*$minute)..(0x9a04+5*$minute)] $expectedBurn)){$burnOK=$false}
}
Check 'Original pine torch burn sequence' $burnOK '15-minute counter, light clamps, DEAD type at timer 5, no underflow after zero'
$heartSource=[IO.File]::ReadAllText((Join-Path $root 'reference\original\SWCHAR.ASM'))
$special=[regex]::Match($heartSource,'(?ms)^SPCTAB\s+EQU(.*?)^THUDD').Groups[1].Value
$heartBytes=@([regex]::Matches($special,'(?m)^\s*FCB\s+%([01]{8})') | ForEach-Object {[Convert]::ToInt32($_.Groups[1].Value,2)})
for($state=0;$state -lt 2;$state++){
    $heartDump=Invoke-Machine "heart-$state" ($setupInventory+" lda #$state`n sta heart_state`n jsr draw_heart") -Video
    $same=$true
    for($half=0;$half -lt 2;$half++){for($row=0;$row -lt 8;$row++){
        $bits=if($row -lt 7){$heartBytes[$state*14+$half*7+$row]}else{0}
        for($pixel=0;$pixel -lt 8;$pixel++){
            $color=1-(($bits -shr (7-$pixel)) -band 1)
            $value=$heartDump[40960+(176+$row)*160+(19+$half)*4+[int][Math]::Floor($pixel/2)]
            $actual=if($pixel%2){$value -band 15}else{$value -shr 4}
            if($actual -ne $color){$same=$false}
        }
    }}
    Check "Original heart frame $state" $same 'all pixels match both original SPCTAB halves on inverse status strip'
}
# Exercise the real input/Enter/delete/echo path, substituting GETIN only.
$keys="E`rP R T`rU R`rE`rL`r"
$keyboardBody=@'
 jmp start
boot_resume:
 ldx test_key_index
 lda test_keys,x
 beq keys_finished
 inc test_key_index
 jmp input_received
keys_finished:
 ldx #0
: lda console_text,x
 sta $9a00,x
 inx
 cpx #128
 bcc :-
 lda active_torch
 sec
 sbc #<objects
 sta $9a80
 lda active_torch+1
 sbc #>objects
 sta $9a81
 jmp $ffff
test_key_index: .byte 0
test_keys:
'@
$keyboardBody+="`n .byte "+((@($keys.ToCharArray() | ForEach-Object {[int]$_})+@(0)) -join ',')+"`n"
$keyboard=Invoke-Machine 'keyboard-flow' $keyboardBody -Boot -Video
$expectedConsole=New-Object byte[] 128
for($i=0;$i -lt 128;$i++){$expectedConsole[$i]=32}
$cursor=32;$expectedConsole[$cursor]=46;$cursor++
foreach($key in $keys.ToCharArray()){
    if([int]$key -eq 13){
        $expectedConsole[$cursor]=32;$cursor++
        if($cursor -ge 128){[Array]::Copy($expectedConsole,32,$expectedConsole,0,96);for($i=96;$i -lt 128;$i++){$expectedConsole[$i]=32};$cursor=96}
        $cursor=($cursor+32) -band 224
        if($cursor -ge 128){[Array]::Copy($expectedConsole,32,$expectedConsole,0,96);for($i=96;$i -lt 128;$i++){$expectedConsole[$i]=32};$cursor=96}
        $expectedConsole[$cursor]=46;$cursor++
    }else{$expectedConsole[$cursor]=[int]$key;$cursor++}
}
Check 'Keyboard command history' (Equal-Bytes $keyboard[0x9a00..0x9a7f] $expectedConsole) 'real main_loop echoes typed commands, Enter submits, and prompts scroll over all four rows'
Check 'Keyboard torch workflow' ($keyboard[0x9a80] -eq 14 -and $keyboard[0x9a81] -eq 0) 'E, P R T, U R, E, L executes through production startup and keyboard loop'
Export-MachineImage $keyboard (Join-Path $results 'keyboard-flow.png')
