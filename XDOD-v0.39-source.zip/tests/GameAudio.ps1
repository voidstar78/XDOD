if(-not ('DodSoundTrace' -as [type])){Add-Type -Path (Join-Path $root 'tools/sound/SoundTrace.cs')}
function Audio-CachedPcm($dump,$fixture,$voice,$length){
 $address=0
 Get-Content (Join-Path $results "$fixture/harness.lbl")|ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.audio_pcm_banks$'){$address=[Convert]::ToInt32($matches[1],16)}}
 if(!$address){throw 'Missing PCM cache bank table'}
 $base=40960+8192*$dump[$address+$voice]
 return ,([byte[]]$dump[$base..($base+$length-1)])
}
$traces=@(0..10)+@(11..16)+@(21,22)
$gains=@(223,191,128,96,64,48,32,24,16,8)
$r=Invoke-Machine 'audio-heart-irq' " jmp start`nboot_resume:`n sei`n stz game_preparing`n stz health_dead`n stz display_mode`n stz game_jiffy`n stz aud_heart_edges`n lda #2`n sta health_rate`n sta health_counter`n cli`n@wait:`n lda game_jiffy`n cmp #6`n bcc @wait`n sei`n lda aud_heart_edges`n sta `$0400`n lda #1`n sta game_preparing`n stz game_jiffy`n cli`n@prepare:`n lda game_jiffy`n cmp #6`n bcc @prepare`n sei`n lda aud_heart_edges`n sta `$0401`n" -Boot -Rendered
Check 'Heartbeat follows IRQ cadence and mutes during PREPARE' (Equal-Bytes $r[0x400..0x401] ([byte[]]@(3,3))) 'three edges in six jiffies; no extra edges while preparing'
$wave=[IO.File]::ReadAllBytes((Join-Path $results 'audio-heart-irq/capture.wav'))
$peak=0
for($i=$wave.Length-32000;$i -lt $wave.Length;$i+=2){$peak=[Math]::Max($peak,[Math]::Abs([int][BitConverter]::ToInt16($wave,$i)))}
Check 'Heartbeat is present in captured audio' ($peak -gt 1000) "last 164ms contains the independent PSG output (peak $peak); catches v0.24's near-silent level"
foreach($id in 0..21){foreach($distance in @(0,8)){
 $r=Invoke-Machine "audio-pcm-$id-$distance" " jsr audio_init`n lda #$id`n sta aud_type`n lda #$distance`n sta aud_distance`n jsr aud_expand`n"
 $gain=if($id -le 10){$gains[$distance]}else{255}
 $encoded=if($id -eq 19){$wizard=([DodSoundTrace]::Build(10)).Encode();$wizard[[DodSoundTrace]::IntroExplosionOffset()..($wizard.Length-1)]}elseif($id -eq 20){([DodSoundTrace]::Build(23)).Encode()}elseif($id -eq 21){([DodSoundTrace]::Build(24)).Encode()}else{([DodSoundTrace]::Build($traces[$id])).Encode()};$pcm=[DodSoundTrace]::DecodeGain($encoded,$gain)
 Check "Game PCM voice $id distance $distance" (Equal-Bytes $r[(40960+6*8192)..(40960+6*8192+$pcm.Length-1)] $pcm) 'every coupled PCM sample matches the source trace at the chosen gain'
 if($id -eq 0 -and $distance -eq 0){
  $helper=[IO.File]::ReadAllBytes((Join-Path $root 'src/save_engine.bin'))
  Check 'Runtime save helper installs losslessly' (Equal-Bytes $r[0x8000..(0x8000+$helper.Length-1)] $helper) 'embedded startup code is copied before its source bytes are reused for BANG and THUD'
  $fontSymbols=@{};Get-Content (Join-Path $results 'audio-pcm-0-0/harness.lbl')|ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.(\w+)$'){$fontSymbols[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
  $font=[byte[]]@([regex]::Matches((Get-Content (Join-Path $root 'src/font.inc') -Raw),'\$([0-9A-Fa-f]{2})')|ForEach-Object {[Convert]::ToByte($_.Groups[1].Value,16)})
  Check 'Packed original font installs losslessly' (Equal-Bytes $r[$fontSymbols.font_data..($fontSymbols.font_data+511)] $font) 'all 512 original bytes reconstructed before the first glyph is drawn'
  $raw=[Collections.Generic.List[byte]]::new();foreach($n in ($traces+@(23,24))){$raw.AddRange(([DodSoundTrace]::Build($n)).Encode())}
  Check 'Native sound unpack preserves all traces' (Equal-Bytes $r[(40960+2*8192)..(40960+2*8192+$raw.Count-1)] $raw.ToArray()) 'every byte in the 31,320-byte creature/weapon/impact/defeat/wall payload'
 }
}}
$r=Invoke-Machine 'audio-live-playback' " jmp start`nboot_resume:`n cli`n lda #10`n ldx #4`n jsr game_sound`n sei`n lda #1`n sta `$0400`n lda `$00`n sta `$0401`n" -Boot -Rendered
Check 'Game FIFO plays complete wizard and restores bank' ($r[0x400] -eq 1 -and $r[0x401] -eq 1) 'full long sound through real r49 PCM/FIFO at rate 058; no visible window'
$r=Invoke-Machine 'audio-live-stereo-playback' " jmp start`nboot_resume:`n cli`n stz game_preparing`n stz display_mode`n stz aud_heart_edges`n lda #6`n sta health_rate`n sta health_counter`n jsr cre_first`n lda #10`n ldx #4`n jsr game_sound`n sei`n lda #1`n sta `$0400`n lda `$00`n sta `$0401`n lda aud_heart_edges`n sta `$0402`n" -Boot -Rendered
Check 'Centered FIFO finishes and restores bank' ($r[0x400] -eq 1 -and $r[0x401] -eq 1) 'single-channel PCM plays centered through both speakers'
Check 'Heartbeat continues during wizard PCM playback' ($r[0x402] -ge 10) 'IRQ heartbeat keeps sounding during PCM conversion, FIFO feeding and draining'
$body=@'
 jmp start
boot_resume:
 cli
 stz test_seen_end
demo_cycle_loop:
 jsr health_task
 jsr health_poll
 jsr health_present
 jsr cre_poll
 jsr health_present
 jsr combat_story
 jsr demo_poll
 jsr cre_generation_poll
 lda demo_active
 beq @captured
 lda demo_stage
 bne @corner
 ldx #31
@timers:
 lda cre_delay,x
 sta $0520,x
 dex
 bpl @timers
@corner:
 lda demo_index
 cmp #8
 bne @captured
 lda player_row
 sta $0405
 sec
 sbc #1
 sta maze_nextrow
 lda player_col
 sta $0406
 sta maze_nextcol
 jsr cre_find
 bcc @captured
 ldy #13
 lda (name_ptr),y
 sta $0404
@captured:
 lda health_dead
 bne demo_cycle_done
 lda demo_active
 beq demo_cycle_title
 lda demo_index
 cmp #17
 bcc demo_cycle_loop
 lda #17
 sta test_seen_end
 bra demo_cycle_loop
demo_cycle_title:
 lda test_seen_end
 beq demo_cycle_loop
demo_cycle_done:
 sei
 lda test_seen_end
 sta $0400
 lda display_mode
 sta $0401
 lda health_dead
 sta $0402
 lda intro_kind
 sta $0403
 jmp $ffff
test_seen_end: .byte 0
'@
$r=Invoke-Machine 'audio-full-attract-cycle' $body -Boot -Rendered
Check 'Live demo completes and returns to title with audio' (Equal-Bytes $r[0x400..0x403] ([byte[]]@(17,3,0,0))) 'natural startup, full word waits, real creature scheduling/combat/PCM, then original intro'
$demoSymbols=@{};Get-Content (Join-Path $results 'audio-full-attract-cycle/harness.lbl')|ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.(\w+)$'){$demoSymbols[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
$giants=0;for($i=0;$i -lt 32;$i++){$p=$demoSymbols.creatures+17*$i;if($r[$p+12] -and $r[$p+13] -eq 5){$giants++}}
Check 'Natural demo attack kills its approaching giant' (($r[$demoSymbols.health_power]+256*$r[$demoSymbols.health_power+1]) -eq 6136 -and $r[$demoSymbols.combat_killed] -eq 1 -and $giants -eq 5 -and $r[$demoSymbols.combat_counts+29] -eq 5) 'all 17 original commands; ordinary ATTACK RIGHT and RNG remove one 704-power giant, granting 88 power; no forced placement, hit or zero-health override'
Check 'Player makes the final MOVE to the waiting giant' (Equal-Bytes $r[0x404..0x406] ([byte[]]@(5,10,22))) 'after MOVE number two, player is (10,22) with the giant still in the corner (9,22), before the next MOVE and ATTACK'
Check 'Demo birth countdowns match cartridge trace' (Equal-Bytes $r[0x520..0x536] ([byte[]]@(11,11,11,11,11,3,3,4,4,4,4,4,4,16,16,16,16,16,16,30,31,31,31))) 'source-derived creation budgets and clock phase age each newly inserted creature timer; no per-creature production delay table'





