$lootSetup=$worldSetup+" jsr loot_init`n"
$ram=Invoke-Combat 'loot-distribution' $lootSetup
$dist=@(0x41,0x31,0x31,0x32,0x23,0x23,0x11,0x13,0x16,0x14,0x14,0x16,0x01,0x04,0x08,0x08,0x03,0x04)
$slot=3;$valid=$true
foreach($type in 0..17){$min=$dist[$type] -shr 4;$level=$min
 foreach($n in 1..($dist[$type] -band 15)){
  $p=$combatLabels.objects+14*$slot
  if($ram[$p+9] -ne $type -or $ram[$p+4] -ne $level -or $ram[$p+5] -ne 255){$valid=$false}
  $slot++;$level++;if($level -gt 5){$level=$min}
 }
}
Check 'All 63 original world objects' ($valid -and $slot -eq 66 -and $ram[$combatLabels.object_count] -eq 66) 'OMXTAB counts, original type order, CINI44 level cycling through five inclusive and creature ownership'
$ram=Invoke-Combat 'cre-loot-attachment' ($lootSetup+" jsr maze_generate`n jsr cre_seed_live`n")
$attached=[Collections.Generic.HashSet[int]]::new();$valid=$true
foreach($slot in 0..31){$p=$combatLabels.creatures+17*$slot;$obj=$ram[$p+8]+256*$ram[$p+9];$guard=0
 while($obj -ne 0){if(!$attached.Add($obj) -or $ram[$obj+4] -ne 0 -or $ram[$obj+5] -ne 255 -or ++$guard -gt 66){$valid=$false;break};$obj=$ram[$obj]+256*$ram[$obj+1]}
}
$expected=0;foreach($slot in 3..65){if($ram[$combatLabels.objects+14*$slot+4] -eq 0){$expected++}}
Check 'World loot attaches once to current-level creatures' ($valid -and $attached.Count -eq $expected -and $expected -gt 0) 'NEWLVL sequential live-CCB assignment and linked inventories; no invented loot rolls'
$ram=Invoke-Combat 'cre-loot-kill-drops' ($armed+" jsr loot_init`n jsr maze_generate`n jsr cre_seed_live`n jsr cre_first`n ldy #8`n lda (cre_ptr),y`n sta `$9a00`n iny`n lda (cre_ptr),y`n sta `$9a01`n lda #32`n sta combat_def`n stz combat_def+1`n jsr combat_kill`n")
$obj=$ram[0x9a00]+256*$ram[0x9a01];$valid=($obj -ne 0);$guard=0
while($obj -ne 0){if($ram[$obj+5] -ne 0 -or ++$guard -gt 66){$valid=$false;break};$obj=$ram[$obj]+256*$ram[$obj+1]}
Check 'Killed creature releases its assigned loot' $valid 'all objects in the carried chain become room-owned'
$ram=Invoke-Combat 'intro-death-layout' ($worldSetup+" jsr game_death_scene`n") -Video
Check 'Death message preserves leading CR and space' ((Text-Pixels-Equal $ram (' '*32) 4 184 0) -and (Text-Pixels-Equal $ram ' YET ANOTHER DOES NOT RETURN...' 4 192 0)) 'decoded original HUPDAT string starts on second parser row'
Check 'Death clears the entire inverse status strip' (Text-Pixels-Equal $ram (' '*32) 4 176 17) 'WIZIN clears hand names and heart without removing the inverse bar'
Export-MachineImage $ram (Join-Path $results 'death-v022.png')
$ram=Invoke-Combat 'intro-prepare-layout' ($worldSetup+" jsr intro_prepare`n") -Video
Check 'PREPARE at original EXAMINE cursor' (Text-Pixels-Equal $ram 'PREPARE!' 16 96 0) 'MISC:PREPAX cursor 32*9+12'
$ram=Invoke-Combat 'intro-demo-words' ($worldSetup+" jsr demo_start`n stz demo_timer`n jsr demo_poll`n stz demo_timer`n lda #1`n sta demo_turn`n jsr demo_poll`n stz demo_timer`n lda #1`n sta demo_turn`n jsr demo_poll`n")
Check 'Demo uses full words within original player task' ($ram[$combatLabels.demo_index] -eq 2 -and $ram[$combatLabels.demo_timer] -eq 1 -and $ram[$combatLabels.input_len] -eq 0 -and $ram[$combatLabels.input_buf] -eq [int][char]'P') 'EXAMINE and full PULL RIGHT TORCH execute; word waits stay inside the cooperative player task'
$timing=" jmp start`nboot_resume:`n cli`n jsr `$ffde`n sta `$9a01`n jsr intro_show`n jsr `$ffde`n sec`n sbc `$9a01`n sta `$9a00`n sei`n"
  # Low byte wraps once over the 306-jiffy fade; accepted band is 4.9..5.4 seconds.
$ram=Invoke-Machine 'intro-fade-duration' $timing -Boot -Rendered
Check 'CoCo1 wizard fade duration' ($ram[0x9a00] -ge 80 -and $ram[0x9a00] -le 110) '336..366 jiffies modulo 256, 17 phases with draw time included'
$bw=Invoke-Combat 'crisp-bw-reference' ($litSetup+(Command-Assembly 'COLOR 0')) -Video
$crisp=Invoke-Combat 'crisp-color3' ($litSetup+(Command-Assembly 'COLOR 3')) -Video
$same=$true
foreach($y in 24..175){foreach($x in 32..287){$p=40960+160*$y+[int][Math]::Floor($x/2);$shift=if($x%2){0}else{4};if((($bw[$p] -shr $shift) -band 15) -ne [int]((($crisp[$p] -shr $shift) -band 15) -ne 0)){$same=$false}}}
Check 'COLOR 3 preserves logical pixels' $same 'single-pixel chroma preserves each lit source pixel position'
Check 'COLOR 3 mode selected' ($crisp[$combatLabels.artifact_mode] -eq 3) 'separate crisp single-pixel gold/blue approximation'
Export-MachineImage $crisp (Join-Path $results 'color3-v022.png')

