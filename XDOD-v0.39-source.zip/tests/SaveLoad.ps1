if(-not ('SaveReference' -as [type])){Add-Type -Path (Join-Path $root 'tests/SaveReference.cs')}
function Save-TestSymbols($name){$m=@{};Get-Content (Join-Path $results "$name/harness.lbl")|ForEach-Object {if($_ -match '^al ([0-9A-Fa-f]+) \.(\w+)$'){$m[$matches[2]]=[Convert]::ToInt32($matches[1],16)}};return $m}
function Save-TestFile($name,[byte[]]$bytes){$folder=Join-Path $results $name;New-Item -ItemType Directory -Force -Path $folder|Out-Null;[IO.File]::WriteAllBytes((Join-Path $folder 'XDOD.SAV'),$bytes)}
$commandRoutine=@'
test_command:
 sta str_ptr
 sty str_ptr+1
 ldy #0
@copy:
 lda (str_ptr),y
 sta input_buf,y
 beq @run
 iny
 bra @copy
@run:
 sty input_len
 jmp handle_command
'@
$producer=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 lda #1
 sta maze_level
 jsr maze_generate
 jsr cre_seed_live
 lda #<leftword
 ldy #>leftword
 jsr test_command
 lda #<torchword
 ldy #>torchword
 jsr test_command
 lda #<useword
 ldy #>useword
 jsr test_command
 lda #<examineword
 ldy #>examineword
 jsr test_command
 lda #$86
 sta health_power
 lda #3
 sta health_power+1
 jsr $ffde
 sta $0404
 lda game_jiffy
 sta $0405
 lda #<saveword
 ldy #>saveword
 jsr test_command
 lda save_result
 sta $0400
 jsr $ffde
 sec
 sbc $0404
 sta $0404
 lda game_jiffy
 sec
 sbc $0405
 bpl :+
 clc
 adc #60
:
 sta $0405
 lda #$6f
 sta health_power
 lda #7
 sta health_power+1
 lda #2
 sta player_direction
 lda #37
 sta objects+14+OC_SPECIAL
 lda #5
 sta objects+42+OC_REVEAL
 lda #18
 sta rng_seed
 lda #52
 sta rng_seed+1
 lda #86
 sta rng_seed+2
 lda #<saveword
 ldy #>saveword
 jsr test_command
 sei
 lda save_result
 sta $0401
 lda save_busy
 sta $0402
 lda $00
 sta $0403
 jmp $ffff
leftword: .byte "P L SW",0
torchword: .byte "P R T",0
useword: .byte "U R",0
examineword: .byte "E",0
saveword: .byte "ZSAVE",0
'@
$name='audio-save-overwrite'
Save-TestFile $name ([Text.Encoding]::ASCII.GetBytes('old file which must be overwritten'))
$r=Invoke-Machine $name ($producer+"`n"+$commandRoutine) -Boot -Rendered
$saved=[IO.File]::ReadAllBytes((Join-Path $results "$name/XDOD.SAV"))
Check 'ZSAVE creates and overwrites XDOD.SAV through r49 HostFS' ((Equal-Bytes $r[0x400..0x403] ([byte[]]@(0,0,0,1))) -and $saved.Length -eq [SaveReference]::Size -and [Text.Encoding]::ASCII.GetString($saved,0,4) -eq 'XDOD' -and [SaveReference]::Word($saved,[SaveReference]::Health) -eq 1903) 'two real parser saves replace an existing file; no filename argument; device 8/current directory'
Check 'Native save header and independent CRC16 agree' ($saved[4] -eq 1 -and [SaveReference]::Word($saved,6) -eq 2729 -and [SaveReference]::Word($saved,14) -eq [SaveReference]::Crc($saved)) 'schema 1, 2729-byte payload, CCITT-FALSE checksum with header checksum bytes zeroed'
Check 'ZSAVE plays about three seconds while gameplay is paused' ($r[0x404] -ge 175 -and $r[0x404] -le 240 -and $r[0x405] -le 1) 'real r49 FIFO and KERNAL clock advance while the game jiffy stays paused'
$readCore=@'
 .segment "CODE"
 .byte 0 ; deliberately relocate the game by one byte to exercise pointer rebasing
 .segment "TESTCODE"
 jmp start
boot_resume:
 cli
 lda #1
 sta save_busy
 ldx #14
@filename:
 lda default_filename,x
 sta SAVE_FILENAME,x
 dex
 bpl @filename
 lda #15
 sta SAVE_FILENAME_LEN
 lda #0
 ldx #<save_parameters
 ldy #>save_parameters
 jsr $8000
 sei
 sta $0400
 jmp $ffff
default_filename: .byte "@0:XDOD.SAV,S,R"
'@
$name='audio-load-core-new-process'
$legacyStereo=[byte[]]$saved.Clone()
$legacyStereo[2741]=1
[SaveReference]::Seal($legacyStereo)
Save-TestFile $name $legacyStereo
$r=Invoke-Machine $name $readCore -Boot -Rendered
$sym=Save-TestSymbols $name
$rebased=[SaveReference]::Rebase($saved,$sym.objects)
$fields=@(@('inventory_state',15),@('objects',1008),@('creatures',544),@('maze_map',1024),@('rng_seed',3),@('maze_level',1),@('player_direction',1),@('world_damage',2),@('world_map_flags',1),@('health_power',9),@('heart_state',1),@('burn_ticks',2),@('cre_enabled',49),@('combat_counts',60),@('combat_enabled',1),@('combat_special',1),@('game_jiffy',2),@('artifact_mode',1),@('loot_enabled',1),@('frame_count',2))
$offset=16;$same=$r[0x400] -eq 0
foreach($field in $fields){if($offset -eq 2741){$offset++};$start=$sym[$field[0]];$length=[int]$field[1];$same=$same -and (Equal-Bytes $r[$start..($start+$length-1)] $rebased[$offset..($offset+$length-1)]);$offset+=$length}
Check 'Legacy stereo byte is accepted and new saves write zero' ($same -and $saved[2741] -eq 0) 'schema-1 compatibility without live audio routing state'
Check 'ZLOAD restores every persistent field in a fresh emulator' ($same -and $offset -eq [SaveReference]::Size -and $sym.objects -ne [SaveReference]::Word($saved,8)) 'maze, RNG, both hands/backpack/torch, all OCB/CCB bytes, health, delays, populations, clocks and preferences; object pointers rebase across different link addresses'
$parser=@'
 .segment "CODE"
 .byte 0 ; replay a save from a different object-table address
 .segment "TESTCODE"
 jmp start
boot_resume:
 cli
 jsr intro_exit
 jsr $ffde
 sta $0404
 lda #<loadword
 ldy #>loadword
 jsr test_command
 sei
 jsr $ffde
 sec
 sbc $0404
 sta $0404
 lda save_result
 sta $0400
 lda save_busy
 sta $0401
 lda $00
 sta $0402
 jmp $ffff
loadword: .byte "ZLOAD",0
'@
$name='audio-load-parser-present'
Save-TestFile $name $saved
$r=Invoke-Machine $name ($parser+"`n"+$commandRoutine) -Boot -Rendered
$sym=Save-TestSymbols $name
Check 'ZLOAD parser redraws restored inventory and resumes normal banking' ((Equal-Bytes $r[0x400..0x402] ([byte[]]@(0,0,1))) -and [SaveReference]::Word($r,$sym.health_power) -eq 1903 -and $r[$sym.display_mode] -eq 1 -and $r[$sym.active_torch]+$r[$sym.active_torch+1] -gt 0 -and [Text.Encoding]::ASCII.GetString($r,$sym.console_text,128).Contains('GAME LOADED')) 'actual command restores an equipped sword, active torch and EXAMINE state, clears old queued input and reports success'
Check 'ZLOAD plays about three seconds after a successful read' ($r[0x404] -ge 175 -and $r[0x404] -le 240) 'real parser, save reader and VERA PCM FIFO'
$badLoad=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 lda #$d2
 sta health_power
 lda #4
 sta health_power+1
 lda #9
 sta rng_seed
 lda #8
 sta rng_seed+1
 lda #7
 sta rng_seed+2
 lda #$5a
 sta SAVE_BUFFER+SAVE_SIZE
 lda #<loadword
 ldy #>loadword
 jsr test_command
 sei
 lda save_result
 sta $0400
 lda health_power
 sta $0401
 lda health_power+1
 sta $0402
 lda rng_seed
 sta $0403
 lda rng_seed+1
 sta $0404
 lda rng_seed+2
 sta $0405
 lda SAVE_BUFFER+SAVE_SIZE
 sta $0406
 lda save_busy
 sta $0407
 jmp $ffff
loadword: .byte "ZLOAD",0
'@
$cases=@{}
$b=[byte[]]$saved.Clone();$b[150]=$b[150] -bxor 1;$cases['checksum']=$b
$b=[byte[]]$saved.Clone();$b[4]=99;[SaveReference]::Seal($b);$cases['version']=$b
$cases['truncated']=[byte[]]$saved[0..($saved.Length-65)]
$cases['oversized']=[byte[]]($saved+@(99))
$b=[byte[]]$saved.Clone();[SaveReference]::Put($b,16,0x1234);[SaveReference]::Seal($b);$cases['pointer']=$b
$b=[byte[]]$saved.Clone();[SaveReference]::Put($b,[SaveReference]::Objects,[SaveReference]::Word($b,8));[SaveReference]::Seal($b);$cases['cycle']=$b
$b=[byte[]]$saved.Clone();$b[2627+15]=255;[SaveReference]::Seal($b);$cases['cursor']=$b
foreach($key in @($cases.Keys)+@('missing')){
 $name="audio-load-reject-$key"
 if($key -ne 'missing'){Save-TestFile $name $cases[$key]}else{$folder=Join-Path $results $name;New-Item -ItemType Directory -Force -Path $folder|Out-Null;$path=Join-Path $folder 'XDOD.SAV';if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path}}
 $r=Invoke-Machine $name ($badLoad+"`n"+$commandRoutine) -Boot -Rendered
 Check "Rejected $key save leaves current game intact" ($r[0x400] -ne 0 -and (Equal-Bytes $r[0x401..0x407] ([byte[]]@(0xd2,4,9,8,7,0x5a,0)))) 'staged/bounded input, header/CRC/pointer/cycle validation before commit; buffer canary and live health/RNG survive'
}
$name='audio-save-write-failure';$folder=Join-Path $results $name;New-Item -ItemType Directory -Force -Path (Join-Path $folder 'XDOD.SAV')|Out-Null
$fail=$parser.Replace('"ZLOAD"','"ZSAVE"')
$r=Invoke-Machine $name ($fail+"`n"+$commandRoutine) -Boot -Rendered
Check 'Save I/O failure is reported and gameplay unpauses' ($r[0x400] -ne 0 -and $r[0x401] -eq 0 -and $r[0x402] -eq 1) 'an existing directory named XDOD.SAV cannot be replaced with a file; no false success'
# Stop at the real BANG call and inspect the already-published frame.
$deathScene=$contact+" stz creatures+8`n stz creatures+9`n stz combat_def`n stz combat_def+1`n lda #`$4c`n sta game_sound`n lda #<test_sound`n sta game_sound+1`n lda #>test_sound`n sta game_sound+2`n jsr cre_first`n jsr combat_kill`n jmp `$ffff`ntest_sound:`n cmp #21`n bne :+`n jmp `$ffff`n: rts`n"
$atBang=Invoke-Combat 'cre-removed-before-bang' $deathScene -Video
$expected=Invoke-Combat 'cre-removed-reference' ($contact+" stz creatures+12`n jsr inventory_redraw`n") -Video
Check 'Defeated creature is erased before its explosion' (Equal-Bytes ([WorldReference]::FromDump($atBang,152)) ([WorldReference]::FromDump($expected,152))) 'PATT40 order: retire/drop, publish PUPDAT, then A$EXP0; snapshot taken at sound dispatch'

$shieldBug=@"
 jmp start
boot_resume:
 cli
 jsr intro_exit
 lda #<saveword
 ldy #>saveword
 jsr test_command
 lda save_result
 sta `$0403
 jsr strike
 sta `$0400
 jsr bug
 ldx #13
@off_text:
 lda console_text,x
 sta `$0420,x
 dex
 bpl @off_text
 lda #<loadword
 ldy #>loadword
 jsr test_command
 lda save_result
 sta `$0404
 jsr strike
 sta `$0401
 jsr game_death_scene
 stz demo_timer
 lda intro_death_deadline
 sta game_second
 jsr demo_poll
 lda display_mode
 sta `$0405
 lda intro_kind
 sta `$0406
 jsr intro_exit
 jsr strike
 sta `$0402
 jsr demo_start
 lda #17
 sta demo_index
 lda #1
 sta demo_stage
 sta demo_turn
 stz demo_timer
 jsr demo_poll
 lda display_mode
 sta `$0407
 lda demo_active
 sta `$0408
 jsr intro_exit
 jsr strike
 sta `$0409
 jsr bug
 ldx #12
@on_text:
 lda console_text,x
 sta `$0430,x
 dex
 bpl @on_text
 lda #<loadword
 ldy #>loadword
 jsr test_command
 lda save_result
 sta `$040A
 jsr strike
 sta `$040B
 sei
 jmp `$ffff
bug:
 jsr console_init
 lda #<bugword
 ldy #>bugword
 jmp test_command
strike:
 stz world_damage
 stz world_damage+1
 lda #<leather
 sta hand_ptr
 lda #>leather
 sta hand_ptr+1
 lda #<bronze
 sta hand_ptr+2
 lda #>bronze
 sta hand_ptr+3
$spider
 lda #$hitSeed
 sta rng_seed+2
 jsr cre_first
 jsr combat_creature
 stz hand_ptr
 stz hand_ptr+1
 stz hand_ptr+2
 stz hand_ptr+3
 lda world_damage
 rts
leather: .res OC_SPECIAL,0
 .byte 108,128
 .res OC_CLASS-OC_SPECIAL-2,0
 .byte 3
bronze: .res OC_SPECIAL,0
 .byte 96,128
 .res OC_CLASS-OC_SPECIAL-2,0
 .byte 3
bugword: .byte "BUG",0
saveword: .byte "ZSAVE F",0
loadword: .byte "ZLOAD F",0
"@
$name='audio-shield-bug-session'
$r=Invoke-Machine $name ($shieldBug+"`n"+$commandRoutine) -Boot -Rendered
Check 'BUG defaults to classic and toggles the shield damage axes' (
 $r[0x400] -eq 32 -and $r[0x401] -eq 24 -and $r[0x40b] -eq 32 -and
 [Text.Encoding]::ASCII.GetString($r,0x420,14) -ceq 'SHIELD BUG OFF' -and
 [Text.Encoding]::ASCII.GetString($r,0x430,13) -ceq 'SHIELD BUG ON'
) 'original physical immunity to Leather/Bronze mitigation, then Bronze reduces the same landed attack, then back to classic'
Check 'BUG survives ZLOAD and both routes back to the title' (
 $r[0x403] -eq 0 -and $r[0x404] -eq 0 -and $r[0x40a] -eq 0 -and
 $r[0x405] -eq 3 -and $r[0x406] -eq 0 -and $r[0x407] -eq 3 -and
 $r[0x408] -eq 0 -and $r[0x402] -eq 24 -and $r[0x409] -eq 24
) 'reloads the same save in both modes, returns from defeat and demo, starts a fresh game, and checks combat after each transition'
