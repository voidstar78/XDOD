# Original object-class vectors at near/middle/far scales.
foreach($class in 0..5){foreach($range in @(0,2,5)){
 $ram=Invoke-Combat "floor-vector-$class-$range" ($worldSetup+" stz world_inverse`n jsr world_clear`n lda #$($class+32)`n sta world_shape`n lda #$range`n sta world_range`n lda #20`n sta world_light`n jsr world_draw_shape`n lda #152`n jsr world_publish`n") -Video
 Check "Floor object class $class range $range" (Equal-Bytes ([WorldReference]::FromDump($ram,152)) (($worldModel.Actor(($class+32),$range,20,0))[0..4863])) 'original VOBJ class model and original distance scales'
}}
$ram=Invoke-Combat 'floor-drop-visible' ($litSetup+(Command-Assembly 'P L SW')+(Command-Assembly 'D L')+(Command-Assembly 'L')) -Video
$expected=$worldModel.View($fullMaps[0],16,11,0,7,0,0);$actor=$worldModel.Actor(36,0,7,0)
for($i=0;$i -lt 4864;$i++){$expected[$i]=$expected[$i] -bor $actor[$i]}
Check 'LOOK draws dropped sword in player room' (Equal-Bytes ([WorldReference]::FromDump($ram,152)) $expected[0..4863]) 'floor ownership, level, position and lighting drive the model'
Export-MachineImage $ram (Join-Path $results 'dropped-sword-v023.png')
foreach($power in @(3749,3750)){
 $setup=$worldSetup+" jsr loot_init`n lda #<(objects+5*OC_LEN)`n sta hand_ptr+2`n lda #>(objects+5*OC_LEN)`n sta hand_ptr+3`n lda #$($power -band 255)`n sta health_power`n lda #$($power -shr 8)`n sta health_power+1`n"
 $ram=Invoke-Combat "reveal-elvish-$power" ($setup+(Command-Assembly 'R R'))
 $p=$combatLabels.objects+5*14
 $wanted=if($power -eq 3750){@(0,64,64)}else{@(150,0,16)}
 Check "REVEAL power threshold $power" ($ram[$p+11] -eq $wanted[0] -and $ram[$p+12] -eq $wanted[1] -and $ram[$p+13] -eq $wanted[2]) 'PREVEA: reveal requirement times 25, then OCBFIL restores true properties'
}
$ram=Invoke-Combat 'intro-death-redraw-stays-modal' ($worldSetup+" jsr game_death_scene`n jsr inventory_redraw`n jsr health_present`n") -Video
Check 'Death scene survives redraw and health polling' ($ram[$combatLabels.display_mode] -eq 3 -and (Text-Pixels-Equal $ram ' YET ANOTHER DOES NOT RETURN...' 4 192 0)) 'normal dungeon/status rendering cannot replace the modal death scene'
$sym=@{};Get-Content (Join-Path (Split-Path $Emulator -Parent) 'kernal.sym')|ForEach-Object{if($_ -match '^al ([0-9A-Fa-f]+) \.(keyd|ndx)$'){$sym[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
$body=" jmp start`nboot_resume:`n cli`n stz `$00`n lda #'X'`n sta `$"+('{0:x4}' -f $sym.keyd)+"`n lda #1`n sta `$"+('{0:x4}' -f $sym.ndx)+"`n jsr intro_show`n sei`n lda intro_fade`n sta `$0400`n lda display_mode`n sta `$0401`n lda health_power`n sta `$0402`n"
$ram=Invoke-Machine 'intro-key-during-fade' $body -Boot -Rendered
Check 'Title fade accepts a start key before completion' ($ram[0x400] -gt 0 -and $ram[0x401] -eq 0 -and $ram[0x402] -eq 160) 'real KERNAL keyboard buffer interrupts the fade and starts a fresh first-level game'
$queued="P R T`rU R`r";$body=$worldSetup+" stz input_read`n stz input_write`n stz `$00`n"
foreach($i in 0..($queued.Length-1)){$body+=" lda #$([int][char]$queued[$i])`n sta `$"+('{0:x4}' -f ($sym.keyd+$i))+"`n"}
$body+=" lda #$($queued.Length)`n sta `$"+('{0:x4}' -f $sym.ndx)+"`n jsr intro_exit`n"
foreach($i in 0..($queued.Length-1)){$body+=" jsr game_getin`n sta `$"+('{0:x4}' -f (0x400+$i))+"`n"}
$ram=Invoke-Machine 'intro-prepare-preserves-queued-keys' $body
Check 'PREPARE preserves queued torch commands' (Equal-Bytes $ram[0x400..(0x400+$queued.Length-1)] ([byte[]]@($queued.ToCharArray() | ForEach-Object {[int]$_}))) 'P R T and U R survive the complete fresh-game/PREPARE/generation transition from the KERNAL buffer through the XDOD input queue'
