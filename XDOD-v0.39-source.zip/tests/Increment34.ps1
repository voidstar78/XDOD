# Win text must survive buffered attacks, then a new key returns to title.
$body=@'
 jmp start
boot_resume:
 cli
 stz artifact_mode
 jsr artifact_build
 lda #$d2
 sta health_power
 lda #4
 sta health_power+1
 stz input_read
 lda #1
 sta input_write
 lda #'A'
 sta input_queue
 lda $00
 pha
 stz $00
 lda #'L'
 sta KEYBUFFER
 lda #1
 sta KEYCOUNT
 pla
 sta $00
 jsr command_winner
 jsr game_getin
 sta $0400
 lda $00
 pha
 stz $00
 lda KEYCOUNT
 sta $0401
 pla
 sta $00
 ; Save layout checks before departing the win scene.
 lda console_text+32
 sta $0402
 lda console_text+64+7
 sta $0403
 lda console_text+64+10
 sta $0404
 lda #$4c
 sta intro_show
 lda #<returned_title
 sta intro_show+1
 lda #>returned_title
 sta intro_show+2
 stz input_read
 lda #2
 sta input_write
 lda #'X'
 sta input_queue
 sta input_queue+1
 jsr game_getin
 jmp input_received
returned_title:
 stz cre_enabled ; execute displaced instruction from intro_show
 jsr intro_show+3
 sei
 lda intro_kind
 sta $0405
 lda display_mode
 sta $0406
 lda demo_timer
 sta $0407
 lda input_read
 ora input_write
 sta $0408
 jmp $ffff
'@
$symbols=@{}
Get-Content (Join-Path (Split-Path $Emulator -Parent) 'kernal.sym')|ForEach-Object{if($_ -match '^al ([0-9A-Fa-f]+) \.(keyd|ndx)$'){$symbols[$matches[2]]=[Convert]::ToInt32($matches[1],16)}}
$body=$body.Replace('KEYBUFFER',('$'+('{0:x4}' -f $symbols.keyd))).Replace('KEYCOUNT',('$'+('{0:x4}' -f $symbols.ndx)))
$r=Invoke-Machine 'audio-victory-fresh-key-title' $body -Boot -Rendered -Video
$s=Save-TestSymbols 'audio-victory-fresh-key-title'
Check 'Victory flushes both old input buffers' (Equal-Bytes $r[0x400..0x404] ([byte[]]@(0,0,66,79,65))) 'old private/KERNAL keys cannot dismiss the win text; BEHOLD at row 2, OF starts column 8, A aligns with DESTINY S'
Check 'Fresh victory key returns to title rather than PREPARE' ((Equal-Bytes $r[0x405..0x406] ([byte[]]@(0,3))) -and $r[0x407] -gt 0 -and $r[0x407] -le 162 -and $r[0x408] -eq 0 -and ($r[$s.health_power]+256*$r[$s.health_power+1]) -eq 1234) 'actual input_received path enters the title and arms normal attract playback; remaining keys are flushed and no new game is started'
$video=[byte[]](@($r[0..40959])+@($r[(40960+524288)..($r.Length-1)]))
Check 'Victory return restores normal title text' (Text-Pixels-Equal $video 'I DARE YE ENTER...' 4 192 0) 'ordinary title fade, banner and two-line introduction execute after a fresh key'
Check 'Title leaves a blank first parser row' ((Text-Pixels-Equal $video (' '*32) 4 184 0) -and (Text-Pixels-Equal $video '...THE DUNGEONS OF DAGGORATH!!!' 4 200 0)) 'title lines occupy parser rows two and three beneath the unchanged banner'

$r=Invoke-Combat 'intro-fake-indented-dialog' ($worldSetup+" lda #2`n sta intro_kind`n lda #1`n sta intro_variant`n jsr intro_show_variant`n") -Video
Check 'Level-three wizard dialog has blank row and original indents' ((Text-Pixels-Equal $r (' '*32) 4 184 0) -and (Text-Pixels-Equal $r ' ENOUGH! I TIRE OF THIS PLAY...' 4 192 0) -and (Text-Pixels-Equal $r '  PREPARE TO MEET THY DOOM!!!' 4 200 0)) 'one space before ENOUGH and two before PREPARE; both lines sit below an empty first parser row'
Export-MachineImage $r (Join-Path $results 'wizard-level3-v034.png')

$body=@'
 jmp start
boot_resume:
 cli
 jsr intro_exit
 lda #<(objects+OC_LEN)
 sta active_torch
 lda #>(objects+OC_LEN)
 sta active_torch+1
 lda #2
 sta maze_level
 lda #10
 sta combat_special
 stz $0404
 stz $0405
 stz $0406
 lda #$4c
 sta intro_hide
 lda #<fade_probe
 sta intro_hide+1
 lda #>fade_probe
 sta intro_hide+2
 lda #$4c
 sta world_publish
 lda #<publish_probe
 sta world_publish+1
 lda #>publish_probe
 sta world_publish+2
 jsr combat_story
 sei
 jmp $ffff
fade_probe:
 lda world_inverse
 sta $0400
 lda intro_kind
 sta $0401
 lda cre_enabled
 sta $0402
 lda game_preparing
 sta $0403
 lda #1
 sta $0404
 stz input_read
 lda #2
 sta input_write
 lda #'M'
 sta input_queue
 lda #13
 sta input_queue+1
 lda $00
 pha
 stz $00
 lda #'X'
 sta KEYBUFFER
 lda #1
 sta KEYCOUNT
 pla
 sta $00
 jsr audio_intro_explosion
 jsr intro_hide+3
 stz $0404
 rts
publish_probe:
 pha
 lda $0404
 beq publish_done
 inc $0405
 lda world_inverse
 cmp #255
 bne publish_bad
 lda intro_kind
 cmp #2
 bne publish_bad
 lda cre_enabled
 bne publish_bad
 lda game_preparing
 cmp #1
 beq publish_done
publish_bad:
 inc $0406
publish_done:
 pla
 sta world_height ; displaced first instruction
 jmp world_publish+3
'@
$body=$body.Replace('KEYBUFFER',('$'+('{0:x4}' -f $symbols.keyd))).Replace('KEYCOUNT',('$'+('{0:x4}' -f $symbols.ndx)))
$r=Invoke-Machine 'audio-level3-white-fade-locked-input' $body -Boot -Rendered -Video
$s=Save-TestSymbols 'audio-level3-white-fade-locked-input'
Check 'Level-three wizard fades out on white with input locked' ((Equal-Bytes $r[0x400..0x403] ([byte[]]@(255,2,0,1))) -and $r[0x405] -eq 16 -and $r[0x406] -eq 0 -and $r[$s.intro_abort] -eq 0) 'all sixteen actual r49 fade frames keep white polarity, cinematic kind 2, frozen creatures and PREPARE input/heartbeat guard; injected key cannot abort'
Check 'Level-four revival restores controls and heartbeat' ($r[$s.maze_level] -eq 3 -and $r[$s.display_mode] -eq 0 -and $r[$s.intro_kind] -eq 0 -and $r[$s.game_preparing] -eq 0 -and $r[$s.cre_enabled] -eq 1 -and $r[$s.input_read] -eq 0 -and $r[$s.input_write] -eq 0) 'resume ordinary play only after fade; both buffered move characters are discarded rather than applied on revival'

