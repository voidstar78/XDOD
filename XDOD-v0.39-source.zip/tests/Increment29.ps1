# PCLIMB: only actual vertical features permit a level transition.
foreach($case in @(@(0,0,23,'C D',1,0),@(1,0,23,'C U',0,0),@(0,15,4,'CLIMB DOWN',1,0),@(1,15,4,'C U',1,1),@(0,16,11,'C D',0,1),@(2,2,3,'C D',2,1),@(4,0,31,'C U',4,1),@(0,0,23,'C L',0,1))){
 $level,$row,$col,$command,$expected,$errorResult=$case
 $body=$litSetup+" lda #$level`n sta maze_level`n lda #$row`n sta player_row`n lda #$col`n sta player_col`n lda #3`n sta player_direction`n lda #77`n sta world_damage`n lda #5`n sta combat_counts`n"+(Command-Assembly $command)
 $ram=Invoke-Combat ('cre-climb-'+$level+'-'+$row+'-'+$col+'-'+$command.Replace(' ','-')) $body
 Check "PCLIMB L$($level+1) ($row,$col) $command" ($ram[$combatLabels.maze_level] -eq $expected -and $ram[$combatLabels.command_result] -eq $errorResult -and $ram[$combatLabels.player_row] -eq $row -and $ram[$combatLabels.player_col] -eq $col -and $ram[$combatLabels.player_direction] -eq 3 -and $ram[$combatLabels.world_damage] -eq 77 -and $ram[$combatLabels.combat_counts] -eq 5) 'source ladder/hole rules, persistent position/facing/damage/population; no debug LEVEL shortcut'
}
$body=$litSetup+" jsr loot_init`n lda #5`n sta combat_counts+2`n stz player_row`n lda #23`n sta player_col`n"+(Command-Assembly 'C D')+(Command-Assembly 'C U')
$ram=Invoke-Combat 'cre-climb-persistent-roundtrip' $body
$types=@();for($i=0;$i -lt 32;$i++){$p=$combatLabels.creatures+17*$i;if($ram[$p+12]){$types+=$ram[$p+13]}}
Check 'Climb returns with stored harder population' ($ram[$combatLabels.maze_level] -eq 0 -and $types.Count -eq 25 -and @($types | Where-Object {$_ -eq 2}).Count -eq 5 -and $ram[$combatLabels.object_count] -eq 66 -and $ram[$combatLabels.active_torch] -ne 0) 'down/up recreates real CCBs from the changed matrix rather than restoring initial counts; all objects and active torch survive'
# Reproduce an asynchronous pickup/burn redraw while already unconscious.
# A trampoline counts full scene draws, including transient frames absent from a final screenshot.
foreach($level in @(0,1)){
 $body=$litSetup+" lda #$level`n sta maze_level`n jsr maze_generate`n lda #1`n sta health_fainted`n sta health_visual`n stz `$9a00`n lda #`$4c`n sta world_viewer`n lda #<test_view_hook`n sta world_viewer+1`n lda #>test_view_hook`n sta world_viewer+2`n jsr inventory_redraw`n jmp test_done`ntest_view_hook:`n inc `$9a00`n rts`ntest_done:`n"
 $ram=Invoke-Combat "faint-redraw-level$level" $body -Video
 $blank=New-Object byte[] 4864
 if($level){for($i=0;$i -lt $blank.Length;$i++){$blank[$i]=255}}
 Check "Unconscious redraw avoids flash L$($level+1)" ($ram[0x9a00] -eq 0 -and (Equal-Bytes ([WorldReference]::FromDump($ram,152)) $blank)) 'no lit scene is published before blanking; inverse polarity remains correct'
 # A redraw arriving after HSLOW clears FAINT must run the graded recovery.
 $body=$litSetup+" lda #1`n sta health_visual`n stz health_fainted`n stz `$9a00`n lda #`$4c`n sta world_publish`n lda #<test_publish_hook`n sta world_publish+1`n lda #>test_publish_hook`n sta world_publish+2`n jsr inventory_redraw`n jmp test_done`ntest_publish_hook:`n inc `$9a00`n sta world_height`n jmp world_publish+3`ntest_done:`n"
 $ram=Invoke-Combat "wake-redraw-level$level" ($body.Replace(' lda #1'+"`n"+' sta health_visual'," lda #$level`n sta maze_level`n jsr maze_generate`n lda #1`n sta health_visual"))
 Check "Pending recovery survives redraw L$($level+1)" ($ram[0x9a00] -eq 17 -and $ram[$combatLabels.health_visual] -eq 0) 'all sixteen light levels -8 through +7 are published before the normal final redraw; no recursion'
}
$ram=Invoke-Combat 'color3-brightness' ($worldSetup+" jsr artifact_palette`n") -Video
$palette=40960+131072+256
Check 'Brighter CoCo3 gold and blue' (Equal-Bytes $ram[($palette+6)..($palette+7)] ([byte[]]@(0xc4,15))) 'gold RGB FC4'
Check 'Brighter CoCo3 blue' (Equal-Bytes $ram[($palette+14)..($palette+15)] ([byte[]]@(0x6f,4))) 'blue RGB 46F; CoCo1 palette and phase behavior unchanged'
