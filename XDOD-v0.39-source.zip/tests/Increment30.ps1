$body=$worldSetup+@'
 lda #1
 sta demo_active
 sta cre_enabled
 stz demo_head
 stz demo_tail
 stz demo_turn
 lda #$60
 sta cre_move
 sta demo_reschedule
 lda #255
 sta creatures+3*CC_LEN+12
 sta creatures+CC_LEN+12
 lda #23
 sta creatures+3*CC_LEN+6
 sta creatures+CC_LEN+6
 lda #3
 jsr demo_enqueue
 lda #32
 jsr demo_enqueue
 lda #1
 jsr demo_enqueue
 jsr cre_poll
 lda cre_index
 sta $9a00
 jsr cre_poll
 lda demo_turn
 sta $9a01
 jsr cre_poll
 lda demo_head
 sta $9a02
 stz demo_turn
 jsr cre_poll
 lda cre_index
 sta $9a03
 lda demo_head
 sta $9a04
'@
$r=Invoke-Machine 'cre-demo-ready-fifo' $body
Check 'Demo PLAYER respects the ready FIFO' (Equal-Bytes $r[0x9a00..0x9a04] ([byte[]]@(3,1,2,1,3))) 'CCB 3 runs before PLAYER, later CCB 1 cannot overtake PLAYER, then runs after it; no CCB-index sorting'
