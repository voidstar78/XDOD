# Original initially-ready CREGEN task: consumes RNG and updates only the matrix.
$r=Invoke-Machine 'cre-generation-source' ($worldSetup+" jsr combat_init`n jsr cre_reset`n lda #1`n sta cre_enabled`n stz cre_gen_delay`n stz maze_level`n jsr rng_init_test`n jsr cre_generation_poll`n ldx #11`n@copy:`n lda combat_counts,x`n sta `$9a00,x`n dex`n bpl @copy`n lda rng_seed`n sta `$9a10`n lda rng_seed+1`n sta `$9a11`n lda rng_seed+2`n sta `$9a12`n jsr cre_generation_poll`n lda rng_seed`n sta `$9a13`n lda rng_seed+1`n sta `$9a14`n lda rng_seed+2`n sta `$9a15`n lda cre_gen_delay`n sta `$9a16`n")
$random=[DaggorathReference]::new([byte[]]@(18,52,86));$type=($random.Next() -band 7)+2
$counts=[byte[]]@(9,9,4,2,0,0,0,0,0,0,0,0);$counts[$type]++
Check 'CREGEN increments original matrix from its RNG selection' (Equal-Bytes $r[0x9a00..0x9a0b] $counts) 'one random type 2..9; no immediate extra creature birth'
Check 'CREGEN consumes one RNG call then waits five minute boundaries' ((Equal-Bytes $r[0x9a10..0x9a12] $random.Seed) -and (Equal-Bytes $r[0x9a13..0x9a15] $random.Seed) -and $r[0x9a16] -eq 5) 'same system task applies in live play and demo, without encounter overrides'
$r=Invoke-Machine 'input-audio-mode-commands' ($worldSetup+(Command-Assembly 'SOUND MONO')+" lda command_result`n sta `$0400`n"+(Command-Assembly 'SOUND STEREO')+" lda command_result`n sta `$0401`n")
Check 'SOUND commands are rejected' (Equal-Bytes $r[0x400..0x401] ([byte[]]@(1,1))) 'mono output has no routing command'

