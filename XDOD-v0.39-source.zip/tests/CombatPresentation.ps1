# Positive combat, cached presentation and original autoplay fixtures.
function Invoke-Combat($name,[string]$body,[switch]$Video){
 $dump=Invoke-Machine $name $body -Video:$Video
 $script:combatLabels=@{}
 Get-Content (Join-Path $results "$name/harness.lbl") | ForEach-Object {
  if($_ -match '^al ([0-9A-Fa-f]+) \.(\w+)$'){$script:combatLabels[$matches[2]]=[Convert]::ToInt32($matches[1],16)}
 }
 return ,$dump
}
foreach($case in @(@(0,255),@(160,16),@(65535,255),@(32768,128),@(1000,6),@(6048,192),@(255,1),@(8000,255))){
 $value=$case[0];$factor=$case[1];$expected=([long]$value*$factor -shr 7) -band 65535
 $ram=Invoke-Combat "combat-scale-$value-$factor" ($worldSetup+" lda #$($value -band 255)`n sta combat_value`n lda #$($value -shr 8)`n sta combat_value+1`n lda #$factor`n sta combat_factor`n jsr combat_scale`n lda combat_value`n sta `$9a00`n lda combat_value+1`n sta `$9a01`n")
 Check "Combat SCAL16 $value x $factor" (($ram[0x9a00]+256*$ram[0x9a01]) -eq $expected) 'independent integer multiply/divide oracle, including 16-bit wrap'
}
$spider=@'
 ldx #7
: lda cre_definitions,x
 sta creatures,x
 dex
 bpl :-
 lda #255
 sta creatures+12
 stz creatures+13
 lda player_row
 sta creatures+15
 lda player_col
 sta creatures+16
 stz creatures+10
 stz creatures+11
 jsr rng_init_test
'@
$armed=$litSetup+(Command-Assembly 'P L SW')
$ram=Invoke-Combat 'combat-empty-swing' ($armed+(Command-Assembly 'A L'))
Check 'Empty-room swing exertion' ($ram[$combatLabels.world_damage] -eq 2 -and $ram[$combatLabels.combat_hit] -eq 0 -and $ram[$combatLabels.combat_sound] -eq 16) 'wooden sword costs two damage units and selects WHOOSH without a target'
$ram=Invoke-Combat 'combat-spider-kill' ($armed+$spider+"`n"+(Command-Assembly 'A L'))
Check 'Player sword lands and kills spider' ($ram[$combatLabels.combat_hit] -eq 1 -and $ram[$combatLabels.combat_killed] -eq 1 -and $ram[$combatLabels.creatures+12] -eq 0 -and $ram[$combatLabels.health_power] -eq 164 -and $ram[$combatLabels.combat_counts] -eq 8 -and $ram[$combatLabels.combat_sound] -eq 18) 'source hit roll, 39 damage, CCB retirement, population decrement, power reward and KLINK'
$missSeed=0..255 | Where-Object { $r=[DaggorathReference]::new([byte[]]@(18,52,$_));$r.Next() -lt 7 } | Select-Object -First 1
$ram=Invoke-Combat 'combat-spider-miss' ($armed+$spider+"`n lda #$missSeed`n sta rng_seed+2`n"+(Command-Assembly 'A L'))
Check 'Miss preserves target and incurs exertion' ($ram[$combatLabels.combat_hit] -eq 0 -and $ram[$combatLabels.creatures+12] -eq 255 -and $ram[$combatLabels.creatures+10] -eq 0 -and $ram[$combatLabels.world_damage] -eq 2 -and $ram[$combatLabels.combat_sound] -eq 16) 'source threshold miss selects no impact'
$ram=Invoke-Combat 'cache-stable' ($litSetup+(Command-Assembly 'E')+" jsr render_examine`n lda ui_changed`n sta `$9a00`n lda ui_changed+1`n sta `$9a01`n jsr inventory_status`n lda ui_changed`n sta `$9a02`n lda ui_changed+1`n sta `$9a03`n")
Check 'Stable inventory/status avoid glyph redraws' (Equal-Bytes $ram[0x9a00..0x9a03] ([byte[]]@(0,0,0,0))) 'second identical render changes zero cached glyphs'
$ram=Invoke-Combat 'intro-polished' ($worldSetup+" lda #1`n sta maze_level`n jsr intro_show`n") -Video
Check 'Intro first line alignment' (Text-Pixels-Equal $ram 'I DARE YE ENTER...' 4 192 0) 'first parser row independent of previous level polarity'
Check 'Intro second line alignment' (Text-Pixels-Equal $ram '...THE DUNGEONS OF DAGGORATH!!!' 4 200 0) 'entire second line'
Check 'Intro replacement banner' (Text-Pixels-Equal $ram 'DYNA MICRO MCMLXXXII  X16 MMXXVI' 4 176 17) 'requested inverse status banner'
Export-MachineImage $ram (Join-Path $results 'intro-v021.png')
$ram=Invoke-Combat 'white-faint' ($litSetup+" lda #1`n sta maze_level`n jsr health_blank`n") -Video
$blank=[WorldReference]::FromDump($ram,152)
Check 'White-level faint keeps white background' (@($blank | Where-Object {$_ -ne 255}).Count -eq 0) 'all 4864 framebuffer bytes preserve inverse level'
$ram=Invoke-Combat 'intro-demo-loadout' ($worldSetup+" jsr demo_start`n")
Check 'Original autoplay starting state' ($ram[$combatLabels.demo_active] -eq 1 -and $ram[$combatLabels.maze_level] -eq 2 -and $ram[$combatLabels.player_row] -eq 12 -and $ram[$combatLabels.player_col] -eq 22 -and ($ram[$combatLabels.health_power]+256*$ram[$combatLabels.health_power+1]) -eq 6048 -and $ram[$combatLabels.object_count] -eq 66 -and $ram[$combatLabels.display_mode] -eq 2 -and $ram[$combatLabels.cre_enabled] -eq 0) 'source DEMDAT loadout, 63 world objects, frozen creature queues during map'
$script=" jsr demo_start`n stz demo_timer`n jsr demo_poll`n"
foreach($i in 0..16){$script+="demo_word_$i`:`n stz demo_timer`n lda #1`n sta demo_turn`n jsr demo_poll`n lda demo_index`n cmp #$($i+1)`n bne demo_word_$i`n sta `$9a$('{0:x2}' -f $i)`n"}
$ram=Invoke-Combat 'intro-demo-script' ($worldSetup+$script)
Check 'All 17 autoplay commands execute' (Equal-Bytes $ram[0x9a00..0x9a10] ([byte[]](1..17))) 'AUTTAB examination, torch use, walking, equipment, attack and turns'
$ram=Invoke-Combat 'intro-fresh-game' ($worldSetup+" jsr demo_start`n jsr intro_exit`n")
Check 'Leaving demo resets fresh playable game' ($ram[$combatLabels.demo_active] -eq 0 -and $ram[$combatLabels.maze_level] -eq 0 -and $ram[$combatLabels.health_power] -eq 160 -and $ram[$combatLabels.display_mode] -eq 0 -and $ram[$combatLabels.combat_enabled] -eq 1 -and $ram[$combatLabels.input_len] -eq 0) 'fresh first-level world and clear parser'
$hitSeed=0..255 | Where-Object {$r=[DaggorathReference]::new([byte[]]@(18,52,$_));$r.Next() -ge 202} | Select-Object -First 1
foreach($shield in @(0,1)){
 $body=$worldSetup+$spider+"`n lda #$hitSeed`n sta rng_seed+2`n lda #1`n sta combat_enabled`n"
 if($shield){$body+=" lda #<(objects+2*OC_LEN)`n sta obj_ptr`n sta hand_ptr+2`n lda #>(objects+2*OC_LEN)`n sta obj_ptr+1`n sta hand_ptr+3`n lda #TYPE_SHI1`n jsr inventory_fill`n"}
 $body+=" jsr cre_first`n jsr combat_creature`n"
 $ram=Invoke-Combat "combat-creature-shield-$shield" $body
 $expected=if($shield){16}else{32}
 Check "Creature attack shield=$shield" ($ram[$combatLabels.combat_hit] -eq 1 -and $ram[$combatLabels.world_damage] -eq $expected) 'source spider attack and Mithril shield defense scaling'
}

