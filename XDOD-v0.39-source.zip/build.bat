@echo off
setlocal
pushd "%~dp0"
if not defined CA65 if exist tools\host64\ca65.exe set "CA65=tools\host64\ca65.exe"
if not defined LD65 if exist tools\host64\ld65.exe set "LD65=tools\host64\ld65.exe"
if not defined CA65 set "CA65=ca65"
if not defined LD65 set "LD65=ld65"
if not exist build mkdir build
"%CA65%" -g -I src -o build\save-engine.o src\save_engine.s
if errorlevel 1 goto fail
"%LD65%" -C cfg\save-engine.cfg -o src\save_engine.bin build\save-engine.o
if errorlevel 1 goto fail
powershell.exe -NoProfile -ExecutionPolicy Bypass -File tools\sound\game-assets.ps1
if errorlevel 1 goto fail
"%CA65%" -g -l build\main.lst -o build\main.o src\main.s
if errorlevel 1 goto fail
"%LD65%" -C cfg\x16.cfg -m build\XDOD.map -Ln build\XDOD.lbl -o XDOD.PRG build\main.o
if errorlevel 1 goto fail
echo Built XDOD.PRG
popd
exit /b 0
:fail
popd
exit /b 1
