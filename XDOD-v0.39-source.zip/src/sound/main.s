; DODSOUND v0.4: isolated calibration tester, no XDOD game state.
.setcpu "65C02"
GETIN=$ffe4
CHROUT=$ffd2
AUDIO_CTRL=$9f3b
AUDIO_RATE=$9f3c
AUDIO_DATA=$9f3d
.segment "ZEROPAGE"
src_ptr: .res 2
dst_ptr: .res 2
play_ptr: .res 2
vol_ptr: .res 2
text_ptr: .res 2
.segment "BSS"
selected: .res 1
sound_group: .res 1
coupling: .res 1
filter_dc: .res 2
filter_old: .res 1
filter_old_sign: .res 1
filter_delta: .res 2
sample_sign: .res 1
output_sample: .res 1
play_rate: .res 1
number_temp: .res 1
volume_table: .res 256
volume_gain: .res 1
volume_center: .res 1
volume_multiplier: .res 1
volume_term: .res 2
volume_product: .res 2
distance: .res 1
saved_bank: .res 1
write_bank: .res 1
end_bank: .res 1
end_ptr: .res 2
play_bank: .res 1
playing: .res 1
run_count: .res 2
run_sample: .res 1
sample_count: .res 3
sample_sum: .res 2
sample_xor: .res 1
feed_count: .res 1
.segment "HEADER"
.word $0801
.segment "BASIC"
.word nextline
.word 10
.byte $9e,"2061",0
nextline: .word 0
.segment "CODE"
start:
 cld
 lda $00
 sta saved_bank
 clc
 lda #1 ; KERNAL 80x30 text mode
 jsr $ff5f
 stz selected
 stz sound_group
 lda #1
 sta coupling
 lda #58
 sta play_rate
 stz distance
 stz playing
 jsr audio_stop
 jsr show_menu
main_loop:
 jsr pcm_feed
 jsr GETIN
 beq main_loop
 cmp #'Q'
 beq quit
 jsr tester_key
 bra main_loop
quit:
 jsr audio_stop
 lda saved_bank
 sta $00
 rts
; Input entry is separately testable, and uses actual KERNAL cursor key codes.
tester_key:
 cmp #'0'
 bne :+
 inc sound_group
 lda sound_group
 cmp #3
 bcc @group_set
 stz sound_group
@group_set:
 stz selected
 jsr audio_stop
 jmp show_menu
: cmp #'F'
 bne :+
 lda coupling
 eor #1
 sta coupling
 jmp @replay
: cmp #157
 beq @slower
 cmp #29
 beq @faster
 cmp #'R'
 beq @normal
 cmp #145
 beq @closer
 cmp #17
 beq @farther
 cmp #'X'
 bne :+
 jmp audio_stop
:
 cmp #' '
 beq @replay
 cmp #'1'
 bcs :+
 rts
: cmp #'9'+1
 bcc @digit
 and #$df
 cmp #'A'
 bcs :+
 rts
: cmp #'E'
 bcc :+
 rts
: sec
 sbc #'A'-9
 bra @select
@digit:
 sec
 sbc #'1'
@select:
 ldx sound_group
 cmp group_counts,x
 bcc :+
 rts
: sta selected
 bra @replay
@slower:
 lda play_rate
 cmp #16
 bne :+
 rts
: dec play_rate
 bra @replay
@faster:
 lda play_rate
 cmp #128
 bne :+
 rts
: inc play_rate
 bra @replay
@normal:
 lda #58
 sta play_rate
 bra @replay
@closer:
 lda distance
 bne :+
 rts
: dec distance
 bra @replay
@farther:
 lda distance
 cmp #8
 bcc :+
 rts
: inc distance
@replay:
 jsr audio_stop
 jsr show_menu
 jsr sound_expand
 lda #2
 sta play_bank
 lda #0
 sta play_ptr
 lda #$a0
 sta play_ptr+1
 lda #1
 sta playing
@prefill:
 jsr pcm_feed
 lda playing
 cmp #2
 beq @begin
 bit AUDIO_CTRL
 bpl @prefill
@begin:
 lda play_rate ; default 64 = 24414.0625Hz, 8-bit signed mono
 sta AUDIO_RATE
 rts
@stop:
 jsr audio_stop
@done:
 rts
audio_stop:
 stz AUDIO_RATE
 lda #$8f
 sta AUDIO_CTRL
 stz playing
 rts
next_byte:
 ldy #0
 lda (src_ptr),y
 inc src_ptr
 bne :+
 inc src_ptr+1
: rts
; Expand source sample/time runs into user banks 2 onward. Never writes bank 0.
sound_expand:
 jsr volume_build
 stz sample_count
 stz sample_count+1
 stz sample_count+2
 stz sample_sum
 stz sample_sum+1
 stz sample_xor
 ldx sound_group
 lda group_offsets,x
 clc
 adc selected
 asl
 tax
 lda sound_table,x
 sta src_ptr
 lda sound_table+1,x
 sta src_ptr+1
 lda #<volume_table
 sta vol_ptr
 lda #>volume_table
 sta vol_ptr+1
 ldy #0
 lda (vol_ptr),y
 sta filter_dc+1
 stz filter_dc
 lda #2
 sta write_bank
 sta $00
 stz dst_ptr
 lda #$a0
 sta dst_ptr+1
@event:
 jsr next_byte
 tay
 lda (vol_ptr),y
 sta run_sample
 lda #0
 bit run_sample
 bpl :+
 dec a
: sta sample_sign
 jsr next_byte
 sta run_count
 stz run_count+1
 lda run_count
 bne @run
 jsr next_byte
 sta run_count
 jsr next_byte
 sta run_count+1
 ora run_count
 bne :+
 jmp @complete
:@run:
 ldy #0
 lda coupling
 beq @raw
 lda filter_dc+1
 sta filter_old
 lda #0
 bit filter_old
 bpl :+
 dec a
: sta filter_old_sign
 sec
 lda run_sample
 sbc filter_old
 sta filter_delta
 lda sample_sign
 sbc filter_old_sign
 sta filter_delta+1
 clc
 lda filter_dc
 adc filter_delta
 sta filter_dc
 lda filter_dc+1
 adc filter_delta+1
 sta filter_dc+1
 sec
 lda run_sample
 sbc filter_dc+1
 bvc @output
 lda #127
 ldx sample_sign
 beq @output
 lda #128
 bra @output
@raw:
 lda run_sample
@output:
 sta output_sample
 sta (dst_ptr),y
 clc
 adc sample_sum
 sta sample_sum
 bcc :+
 inc sample_sum+1
: lda output_sample
 eor sample_xor
 sta sample_xor
 inc sample_count
 bne :+
 inc sample_count+1
 bne :+
 inc sample_count+2
: inc dst_ptr
 bne @count
 inc dst_ptr+1
 lda dst_ptr+1
 cmp #$c0
 bne @count
 lda #$a0
 sta dst_ptr+1
 inc write_bank
 lda write_bank
 sta $00
@count:
 lda run_count
 bne :+
 dec run_count+1
: dec run_count
 lda run_count
 ora run_count+1
 beq :+
 jmp @run
: jmp @event
@complete:
 lda dst_ptr
 sta end_ptr
 lda dst_ptr+1
 sta end_ptr+1
 lda write_bank
 sta end_bank
 lda saved_bank
 sta $00
 rts
; Foreground feeder returns every 256 bytes so GETIN stays responsive. This
; same bounded feeder can later run between gameplay tasks, or in AFLOW service.
pcm_feed:
 lda playing
 bne :+
 rts
: cmp #2
 beq @drain
 lda play_bank
 sta $00
 stz feed_count
@byte:
 lda play_bank
 cmp end_bank
 bne @space
 lda play_ptr
 cmp end_ptr
 bne @space
 lda play_ptr+1
 cmp end_ptr+1
 bne @space
 lda #2
 sta playing
 bra @restore
@space:
 bit AUDIO_CTRL
 bmi @restore
 ldy #0
 lda (play_ptr),y
 sta AUDIO_DATA
 inc play_ptr
 bne @next
 inc play_ptr+1
 lda play_ptr+1
 cmp #$c0
 bne @next
 lda #$a0
 sta play_ptr+1
 inc play_bank
 lda play_bank
 sta $00
@next:
 inc feed_count
 bne @byte
@restore:
 lda saved_bank
 sta $00
@done:
 rts
@drain:
 lda AUDIO_CTRL
 and #64
 bne :+
 rts
: stz AUDIO_RATE
 stz playing
 rts
print:
 sta text_ptr
 sty text_ptr+1
 ldy #0
@char:
 lda (text_ptr),y
 bne :+
 rts
: phy
 jsr CHROUT
 ply
 iny
 bne @char
 inc text_ptr+1
 bra @char
@done:
 rts
show_menu:
 lda #147
 jsr CHROUT
 ldx sound_group
 lda group_menu_lo,x
 ldy group_menu_hi,x
 jsr print
 lda selected
 cmp #9
 bcs @letter
 clc
 adc #'1'
 bra @key
@letter:
 clc
 adc #'A'-9
@key:
 jsr CHROUT
 lda #<distance_text
 ldy #>distance_text
 jsr print
 lda distance
 clc
 adc #'0'
 jsr CHROUT
 lda #<rate_text
 ldy #>rate_text
 jsr print
 lda play_rate
 jsr print_number
 lda #<coupling_text
 ldy #>coupling_text
 jsr print
 lda coupling
 beq @off
 lda #<coupling_on
 ldy #>coupling_on
 bra @mode
@off:
 lda #<coupling_off
 ldy #>coupling_off
@mode:
 jsr print
 lda #<footer
 ldy #>footer
 jmp print
print_number:
 sta number_temp
 ldx #'0'
 cmp #100
 bcc :+
 sec
 sbc #100
 sta number_temp
 inx
: txa
 jsr CHROUT
 ldx #'0'
 lda number_temp
@ten:
 cmp #10
 bcc @digits
 sec
 sbc #10
 inx
 bra @ten
@digits:
 sta number_temp
 txa
 jsr CHROUT
 lda number_temp
 clc
 adc #'0'
 jmp CHROUT
.segment "RODATA"
group_counts: .byte 13,9,3
group_offsets: .byte 0,13,22
group_menu_lo: .byte <monsters_menu,<weapons_menu,<heart_menu
group_menu_hi: .byte >monsters_menu,>weapons_menu,>heart_menu
monsters_menu: .byte "DODSOUND V0.4 - MONSTERS",13,13,"1 SPIDER       2 VIPER        3 STONE GIANT 1",13,"4 BLOB         5 KNIGHT 1     6 STONE GIANT 2",13,"7 SCORPION     8 KNIGHT 2     9 WRAITH",13,"A BALROG       B PLAIN WIZARD C CRESCENT WIZARD",13,"D WIZARD ENCOUNTER: TWO CALLS + ATTACK DELAY",13,13,"SELECTED KEY: ",0
weapons_menu: .byte "DODSOUND V0.4 - WEAPONS AND ITEMS",13,13,"1 FLASK        2 RING         3 SCROLL",13,"4 SHIELD       5 SWORD        6 TORCH",13,"7 BARE HAND (SOURCE USES SWORD WHOOSH)",13,"8 HIT CREATURE (KLINK - AFTER A LANDED HIT)",13,"9 HIT PLAYER (CLANK - CREATURE LANDED HIT)",13,13,"SCROLL ATTACK AND USE SHARE WHOOP.",13,"TORCH USE AND ATTACK SHARE CHUCK.",13,13,"SELECTED KEY: ",0
heart_menu: .byte "DODSOUND V0.4 - HEARTBEAT",13,13,"1 RESTING (46 JIFFIES PER EDGE)",13,"2 EXERTION (16 JIFFIES PER EDGE)",13,"3 CRITICAL (3 JIFFIES PER EDGE)",13,13,"SOURCE ONE-BIT TOGGLE WITH OPTIONAL AC COUPLING.",13,13,"SELECTED KEY: ",0
coupling_text: .byte "   AC COUPLING: ",0
coupling_on: .byte "ON",0
coupling_off: .byte "RAW",0
rate_text: .byte "   PCM RATE: ",0
distance_text: .byte "   DISTANCE (0-8): ",0
footer: .byte 13,13,"0: NEXT GROUP   SPACE: REPLAY   X: STOP   Q: QUIT",13,"UP/DOWN: DISTANCE   LEFT/RIGHT: SPEED   R: 058",13,"F: AC COUPLING / RAW COMPARISON",13,13,"SOURCE ARITHMETIC / APPROXIMATE 6809 TIMING",13,"REPORT PITCH, DURATION, ENVELOPE AND TICKS.",13,0
.include "assets.inc"

.segment "CODE"
; Generate the original multiply-high DAC scaling table for current distance.
volume_build:
 lda distance
 asl
 asl
 asl
 asl
 asl
 sec
 sbc distance
 eor #255
 sta volume_gain
 dec a
 and #252
 lsr
 sta volume_center
 ldx #0
@sample:
 stx volume_term
 stz volume_term+1
 stz volume_product
 stz volume_product+1
 lda volume_gain
 sta volume_multiplier
 ldy #8
@bit:
 lsr volume_multiplier
 bcc :+
 clc
 lda volume_product
 adc volume_term
 sta volume_product
 lda volume_product+1
 adc volume_term+1
 sta volume_product+1
: asl volume_term
 rol volume_term+1
 dey
 bne @bit
 lda volume_product+1
 and #252
 sec
 sbc volume_center
 sta volume_table,x
 inx
 bne @sample
 rts