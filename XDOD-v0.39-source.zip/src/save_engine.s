; Standalone runtime helper, installed at $8000 after lossless startup unpack.
; No main-program addresses are embedded: X/Y supply the header/range table.
.setcpu "65C02"
.macro jeq target
 bne :+
 jmp target
:
.endmacro
.macro jne target
 beq :+
 jmp target
:
.endmacro
.macro jcs target
 bcc :+
 jmp target
:
.endmacro
.macro jcc target
 bcs :+
 jmp target
:
.endmacro
.include "save_zp.inc"
.include "save_format.inc"
P=SAVE_PTR
D=SAVE_DESC
G=SAVE_ADDR
MODE=$8f00
RESULT=$8f01
OPENED=$8f02
PARAM=$8f03
TABLE=$8f05
COUNT=$8f07
CRC=$8f09
EXPECTED=$8f0b
BYTE=$8f0d
STATUS=$8f0e
OLD=$8f0f
NEW=$8f11
LIMIT=$8f13
VALUE=$8f15
REM=$8f17
LEFT=$8f19
STRIDE=$8f1a
HEAD=$8f1b
BUDGET=$8f1d
.segment "CODE"
save_engine:
 sta MODE
 stx PARAM
 sty PARAM+1
 stx D
 sty D+1
 stz OPENED
 stz RESULT
 jsr $ffcc
 ldy #16
 lda (D),y
 sta TABLE
 iny
 lda (D),y
 sta TABLE+1
 lda MODE
 jeq read_save
 ldy #15
@header:
 lda (D),y
 sta SAVE_BUFFER,y
 dey
 bpl @header
 jsr copy_fields
 stz SAVE_BUFFER+S_STEREO ; always emit zero for the legacy schema-1 byte
 jsr checksum
 lda CRC
 sta SAVE_BUFFER+14
 lda CRC+1
 sta SAVE_BUFFER+15
 jsr open_file
 jcs io_error
 ldx #2
 jsr $ffc9
 jcs io_error
 jsr buffer_start
@write:
 ldy #0
 lda (P),y
 jsr $ffd2
 jsr $ffb7
 jne io_error
 jsr advance
 bcc @write
 bra success
read_save:
 jsr open_file
 jcs io_error
 ldx #2
 jsr $ffc6
 jcs io_error
 jsr buffer_start
@read:
 jsr $ffcf
 sta BYTE
 jsr $ffb7
 sta STATUS
 and #$bf
 jne io_error
 ldy #0
 lda BYTE
 sta (P),y
 jsr advance
 php
 lda STATUS
 and #64
 bne @eof
 plp
 jcs invalid
 bra @read
@eof:
 plp
 jcc invalid
 jsr validate
 jcs invalid
 jsr copy_fields
success:
 lda #0
 bra finish
io_error:
 lda #1
 bra finish
invalid:
 lda #2
finish:
 sta RESULT
 jsr $ffcc
 lda OPENED
 beq :+
 lda #2
 jsr $ffc3
: jsr $ffcc
 lda RESULT
 rts
open_file:
 lda SAVE_FILENAME_LEN
 ldx #<SAVE_FILENAME
 ldy #>SAVE_FILENAME
 pha
 lda MODE
 bne :+
 pla
 sec
 sbc #3
 ldx #<(SAVE_FILENAME+3)
 bra @filename
: pla
@filename:
 jsr $ffbd
@open:
 lda #2
 ldx #8
 ldy #2
 jsr $ffba
 jsr $ffc0
 bcs @done
 inc OPENED
 clc
@done:
 rts
buffer_start:
 lda #<SAVE_BUFFER
 sta P
 lda #>SAVE_BUFFER
 sta P+1
 rts
advance:
 inc P
 bne :+
 inc P+1
: lda P+1
 cmp #>(SAVE_BUFFER+SAVE_SIZE)
 bne @compare
 lda P
 cmp #<(SAVE_BUFFER+SAVE_SIZE)
@compare:
 rts
; CRC16/CCITT-FALSE over the entire file, with checksum bytes treated as zero.
checksum:
 stz SAVE_BUFFER+14
 stz SAVE_BUFFER+15
 lda #255
 sta CRC
 sta CRC+1
 jsr buffer_start
@byte:
 ldy #0
 lda (P),y
 eor CRC+1
 sta CRC+1
 ldx #8
@bit:
 asl CRC
 rol CRC+1
 bcc :+
 lda CRC
 eor #$21
 sta CRC
 lda CRC+1
 eor #$10
 sta CRC+1
: dex
 bne @bit
 jsr advance
 bcc @byte
 rts
; Same descriptor order for write/read; only persistent game fields are copied.
copy_fields:
 lda TABLE
 sta D
 lda TABLE+1
 sta D+1
 lda #<(SAVE_BUFFER+16)
 sta P
 lda #>(SAVE_BUFFER+16)
 sta P+1
@range:
 ldy #0
 lda (D),y
 sta G
 iny
 lda (D),y
 sta G+1
 ora G
 beq @done
 iny
 lda (D),y
 sta COUNT
 iny
 lda (D),y
 sta COUNT+1
@byte:
 ldy #0
 lda MODE
 beq @restore
 lda (G),y
 sta (P),y
 bra @next
@restore:
 lda (P),y
 sta (G),y
@next:
 inc P
 bne :+
 inc P+1
: inc G
 bne :+
 inc G+1
: lda COUNT
 bne :+
 dec COUNT+1
: dec COUNT
 lda COUNT
 ora COUNT+1
 bne @byte
 clc
 lda D
 adc #4
 sta D
 bcc @range
 inc D+1
 bra @range
@done:
 rts
validate:
 lda PARAM
 sta D
 lda PARAM+1
 sta D+1
 ldy #13
@header:
 cpy #8
 beq @skip
 cpy #9
 beq @skip
 lda (D),y
 cmp SAVE_BUFFER,y
 jne @bad
@skip:
 dey
 bpl @header
 lda SAVE_BUFFER+14
 sta EXPECTED
 lda SAVE_BUFFER+15
 sta EXPECTED+1
 jsr checksum
 lda CRC
 cmp EXPECTED
 jne @bad
 lda CRC+1
 cmp EXPECTED+1
 jne @bad
 lda SAVE_BUFFER+8
 sta OLD
 lda SAVE_BUFFER+9
 sta OLD+1
 ldy #8
 lda (D),y
 sta NEW
 iny
 lda (D),y
 sta NEW+1
 lda SAVE_BUFFER+S_INV+14
 jeq @bad
 cmp #73
 jcs @bad
 tax
 stz LIMIT
 stz LIMIT+1
@limit:
 clc
 lda LIMIT
 adc #14
 sta LIMIT
 bcc :+
 inc LIMIT+1
: dex
 bne @limit
 lda SAVE_BUFFER+S_LEVEL
 cmp #5
 jcs @bad
 lda SAVE_BUFFER+S_DIRECTION
 cmp #4
 jcs @bad
 lda SAVE_BUFFER+S_INV+10
 cmp #32
 jcs @bad
 lda SAVE_BUFFER+S_INV+11
 cmp #32
 jcs @bad
 lda SAVE_BUFFER+S_INV+12
 cmp #3
 jcs @bad
 lda SAVE_BUFFER+S_COLOR
 cmp #7
 jcs @bad
 lda SAVE_BUFFER+S_STEREO
 cmp #2
 jcs @bad
 lda SAVE_BUFFER+S_TIME
 cmp #60
 jcs @bad
 lda SAVE_BUFFER+S_TIME+1
 cmp #60
 jcs @bad
 lda SAVE_BUFFER+S_FRAME
 cmp #30
 jcs @bad
 lda SAVE_BUFFER+S_CRETASK
 cmp #2
 jcs @bad
 lda SAVE_BUFFER+S_CRETASK+1
 cmp #2
 jcs @bad
 lda SAVE_BUFFER+S_CRETASK+3
 cmp #6
 jcs @bad
 lda SAVE_BUFFER+S_CRETASK+15
 cmp #32
 jcs @bad
 lda SAVE_BUFFER+S_CRETASK+16
 cmp #6
 jcs @bad
 lda SAVE_BUFFER+S_HEART
 cmp #2
 jcs @bad
 lda SAVE_BUFFER+S_BURN
 cmp #120
 jcs @bad
 bra @pointers
@bad:
 sec
 rts
@pointers:
 lda #<(SAVE_BUFFER+S_INV)
 sta P
 lda #>(SAVE_BUFFER+S_INV)
 sta P+1
 lda #2
 sta STRIDE
 lda #4
 jsr pointers
 bcs @bad
 lda #<(SAVE_BUFFER+S_OBJECTS)
 sta P
 lda #>(SAVE_BUFFER+S_OBJECTS)
 sta P+1
 lda #14
 sta STRIDE
 lda #72
 jsr pointers
 bcs @bad
 lda #<(SAVE_BUFFER+S_CREATURES+8)
 sta P
 lda #>(SAVE_BUFFER+S_CREATURES+8)
 sta P+1
 lda #17
 sta STRIDE
 lda #32
 jsr pointers
 bcs @bad
 jmp records
pointers:
 sta LEFT
@one:
 jsr convert_pointer
 bcs @done
 jsr stride
 dec LEFT
 bne @one
 clc
@done:
 rts
stride:
 clc
 lda P
 adc STRIDE
 sta P
 bcc :+
 inc P+1
: rts
convert_pointer:
 ldy #0
 lda (P),y
 sta VALUE
 iny
 lda (P),y
 sta VALUE+1
 ora VALUE
 beq @ok
 sec
 lda VALUE
 sbc OLD
 sta VALUE
 sta REM
 lda VALUE+1
 sbc OLD+1
 sta VALUE+1
 sta REM+1
 bcc @bad
 cmp LIMIT+1
 bcc @aligned
 bne @bad
 lda VALUE
 cmp LIMIT
 bcs @bad
@aligned:
 lda REM+1
 bne @subtract
 lda REM
 cmp #14
 bcc @remainder
@subtract:
 sec
 lda REM
 sbc #14
 sta REM
 lda REM+1
 sbc #0
 sta REM+1
 bra @aligned
@remainder:
 cmp #0
 bne @bad
 clc
 lda VALUE
 adc NEW
 ldy #0
 sta (P),y
 lda VALUE+1
 adc NEW+1
 iny
 sta (P),y
@ok:
 clc
 rts
@bad:
 sec
 rts
records:
 lda #<(SAVE_BUFFER+S_OBJECTS)
 sta P
 lda #>(SAVE_BUFFER+S_OBJECTS)
 sta P+1
 lda #14
 sta STRIDE
 lda SAVE_BUFFER+S_INV+14
 sta LEFT
@object:
 ldy #2
 lda (P),y
 cmp #32
 bcs @bad
 iny
 lda (P),y
 cmp #32
 bcs @bad
 iny
 lda (P),y
 cmp #6
 bcs @bad
 ldy #9
 lda (P),y
 cmp #25
 bcs @bad
 iny
 lda (P),y
 cmp #6
 bcs @bad
 jsr stride
 dec LEFT
 bne @object
 lda #<(SAVE_BUFFER+S_CREATURES)
 sta P
 lda #>(SAVE_BUFFER+S_CREATURES)
 sta P+1
 lda #17
 sta STRIDE
 lda #32
 sta LEFT
@creature:
 ldy #12
 lda (P),y
 beq @next
 cmp #255
 bne @bad
 iny
 lda (P),y
 cmp #12
 bcs @bad
 iny
 lda (P),y
 cmp #4
 bcs @bad
 iny
 lda (P),y
 cmp #32
 bcs @bad
 iny
 lda (P),y
 cmp #32
 bcs @bad
@next:
 jsr stride
 dec LEFT
 bne @creature
 jmp acyclic
@bad:
 sec
 rts
; Pointer bounds/alignment are already checked; reject cycles before committing.
acyclic:
 lda #<(SAVE_BUFFER+S_OBJECTS)
 sta HEAD
 lda #>(SAVE_BUFFER+S_OBJECTS)
 sta HEAD+1
 lda SAVE_BUFFER+S_INV+14
 sta LEFT
@head:
 lda HEAD
 sta P
 lda HEAD+1
 sta P+1
 lda SAVE_BUFFER+S_INV+14
 inc a
 sta BUDGET
@link:
 ldy #0
 lda (P),y
 sta VALUE
 iny
 lda (P),y
 sta VALUE+1
 ora VALUE
 beq @next
 dec BUDGET
 beq @bad
 sec
 lda VALUE
 sbc NEW
 sta P
 lda VALUE+1
 sbc NEW+1
 sta P+1
 clc
 lda P
 adc #<(SAVE_BUFFER+S_OBJECTS)
 sta P
 lda P+1
 adc #>(SAVE_BUFFER+S_OBJECTS)
 sta P+1
 bra @link
@next:
 clc
 lda HEAD
 adc #14
 sta HEAD
 bcc :+
 inc HEAD+1
: dec LEFT
 bne @head
 clc
 rts
@bad:
 sec
 rts
.segment "RODATA"
.assert *<=$8f00, error, "Save helper overlaps its workspace"

